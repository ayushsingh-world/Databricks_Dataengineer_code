# Databricks notebook source
# DBTITLE 1,Get Azure AD Token for SPN
def GetAzureADAccessToken(key_Scope, spn_tenant_url_key, spn_clientid_key, spn_secret_key):
    token_url = dbutils.secrets.get(scope = key_Scope, key = spn_tenant_url_key)
    client_id = dbutils.secrets.get(scope = key_Scope, key = spn_clientid_key)
    client_secret = dbutils.secrets.get(scope = key_Scope, key = spn_secret_key)
    myobj = f'grant_type=client_credentials&client_id='+client_id+'&client_secret='+ client_secret+'&scope=2ff814a6-3304-4ab8-85cb-cd0e6f879c1d%2F.default'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    access_token = None
    count = 0
    exceptionCount = 0

    while access_token == None:
        try:
            response = requests.post(token_url, data=myobj, headers=headers )
            #response.raise_for_status()
            decodedData = response.content.decode('utf-8')        
            #convert json strng data to distributed rdd
            dataRDD = sc.parallelize([decodedData])
            df = spark.read.json(dataRDD)    
            access_token = df.select('access_token').collect()[0][0]
        except Exception as e:
            print("".join(traceback.format_exception_only(type(e),e)).strip())        
            exceptionCount += 1
            time.sleep(5)
            if exceptionCount == 10:
                raise("".join(traceback.format_exception_only(type(e),e)).strip())
    return access_token

# COMMAND ----------

# DBTITLE 1,Get List of All Jobs in Databricks Workspace
def get_job_list(databricks_instance, access_token):
    job_endpoint = f"https://{databricks_instance}/api/2.1/jobs/list"
    headers = {'Authorization': 'Bearer '+access_token}
    
    count = 0
    exceptionCount = 0
    df_data = None
    while df_data == None:
        try:
            response = requests.get(job_endpoint, headers=headers)
            # response.raise_for_status()
            decodedData = response.content.decode('utf-8')
            dataRDD = sc.parallelize([decodedData])
            df = spark.read.json(dataRDD)
            df_data = df.select('jobs').collect()[0][0]
            df = df.select(explode('jobs').alias('jobs'))
            df = df.select('jobs.job_id', 'jobs.settings.name')

            return df
        except Exception as e:
            print("".join(traceback.format_exception_only(type(e),e)).strip())
            exceptionCount += 1
            time.sleep(5)
            if exceptionCount == 5:
                raise("".join(traceback.format_exception_only(type(e),e)).strip())
            count += 1

# COMMAND ----------

# DBTITLE 1,Get Current Job Status for JobId
def get_current_job_stats(job_id):
    job_endpoint = f"https://{databricks_instance}/api/2.1/jobs/runs/list"
    headers = {'Authorization': 'Bearer '+access_token}
    try:          
        # Trigger the job
        payload = {"job_id": job_id, "active_only":'true'}
        response = requests.get(job_endpoint, headers=headers, json=payload)
        decodedData = (response.content.decode('utf-8'))
        json_data = json.loads(decodedData) 
        return json_data 
    except Exception as e:
        print("Error occurred while triggering the job:", str(e))    

# COMMAND ----------

# DBTITLE 1,Trigger databricks Job for JobId
def trigger_databricks_job(job_id):
    
    job_endpoint = f"https://{databricks_instance}/api/2.1/jobs/run-now"
    headers = {'Authorization': 'Bearer '+access_token}
    try:          
        # Trigger the job
        payload = {"job_id": job_id}
        response = requests.post(job_endpoint, headers=headers, json=payload)
        decodedData = (response.content.decode('utf-8'))
        json_data = json.loads(decodedData)         
        return json_data
    except Exception as e:
        print("Error occurred while triggering the job:", str(e))