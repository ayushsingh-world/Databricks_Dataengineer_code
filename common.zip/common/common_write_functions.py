# Databricks notebook source
# DBTITLE 1,Write to Delta Lake
def merge_deltalake_table(df, table_name, merge_flag, merge_column=None):
    try:
        # Get DeltaTable object
        deltaTable = DeltaTable.forName(spark, table_name)
        # Define merge condition
        if merge_column:
            merge_condition = f"target.{merge_column} = source.{merge_column}"
        else: 
            merge_condition = None
        if merge_flag == 'Merge':    
            deltaTable.alias('target').merge(df.alias('source'), merge_condition)\
                                                      .whenMatchedUpdateAll()\
                                                      .whenNotMatchedInsertAll()\
                                                      .execute()
            merge_result = deltaTable.history().filter(col("operation") == "MERGE").orderBy(desc("timestamp")).limit(1)
            merge_result = merge_result.select(explode('operationMetrics')).withColumn('table_name', lit(table_name))
            merge_result = merge_result.groupBy("table_name").pivot("key").agg(first("value"))
            merge_result = merge_result.select("table_name", "numTargetRowsInserted","numTargetRowsUpdated","numTargetRowsDeleted")                                                

        elif  merge_flag == 'Insert':
            deltaTable.alias('target').merge(df.alias('source'), merge_condition)\
                                                      .whenNotMatchedInsertAll()\
                                                      .execute()
            merge_result = deltaTable.history().filter(col("operation") == "MERGE").orderBy(desc("timestamp")).limit(1)
            merge_result = merge_result.select(explode('operationMetrics')).withColumn('table_name', lit(table_name))
            merge_result = merge_result.groupBy("table_name").pivot("key").agg(first("value"))
            merge_result = merge_result.select("table_name", "numTargetRowsInserted","numTargetRowsUpdated","numTargetRowsDeleted")                                                         

        elif  merge_flag == 'Update':
            deltaTable.alias('target').merge(df.alias('source'), merge_condition)\
                                                      .whenMatchedUpdateAll()\
                                                      .execute()
            merge_result = deltaTable.history().filter(col("operation") == "MERGE").orderBy(desc("timestamp")).limit(1)
            merge_result = merge_result.select(explode('operationMetrics')).withColumn('table_name', lit(table_name))
            merge_result = merge_result.groupBy("table_name").pivot("key").agg(first("value"))
            merge_result = merge_result.select("table_name", "numTargetRowsInserted","numTargetRowsUpdated","numTargetRowsDeleted")                                                         

        elif  merge_flag == 'Delete':
            deltaTable.alias('target').merge(df.alias('source'), merge_condition)\
                                                      .whenMatchedDelete()\
                                                      .execute()
            merge_result = deltaTable.history().filter(col("operation") == "MERGE").orderBy(desc("timestamp")).limit(1)
            merge_result = merge_result.select(explode('operationMetrics')).withColumn('table_name', lit(table_name))
            merge_result = merge_result.groupBy("table_name").pivot("key").agg(first("value"))
            merge_result = merge_result.select("table_name", "numTargetRowsInserted","numTargetRowsUpdated","numTargetRowsDeleted")                                                           

        elif merge_flag == 'ForceInsert':      
            df.write.format('delta').mode('append').saveAsTable(table_name)
            merge_result = deltaTable.history().filter(col("operation") == "WRITE").orderBy(desc("timestamp")).limit(1)
            merge_result = merge_result.select(explode('operationMetrics')).withColumn('table_name', lit(table_name))
            merge_result = merge_result.groupBy("table_name").pivot("key").agg(first("value"))
            merge_result = merge_result.select("table_name", col("numOutputRows").alias("numTargetRowsInserted")).withColumn("numTargetRowsUpdated", lit('0')).withColumn("numTargetRowsDeleted", lit('0'))   
        elif merge_flag == 'Overwrite': 
            spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")     
            df.write.format('delta').mode('overwrite').saveAsTable(table_name)
            merge_result = deltaTable.history().filter(col("operation") == "CREATE OR REPLACE TABLE AS SELECT").orderBy(desc("timestamp")).limit(1)
            merge_result = merge_result.select(explode('operationMetrics')).withColumn('table_name', lit(table_name))
            merge_result = merge_result.groupBy("table_name").pivot("key").agg(first("value"))
            merge_result = merge_result.select("table_name", col("numOutputRows").alias("numTargetRowsInserted")).withColumn("numTargetRowsUpdated", lit('0')).withColumn("numTargetRowsDeleted", lit('0'))          

        else:
            print("Imvalid mode provided")

        return merge_result
    
    except Exception as e:
        print(f"Error in merging data delta lake table {table_name}: {e}")
        raise