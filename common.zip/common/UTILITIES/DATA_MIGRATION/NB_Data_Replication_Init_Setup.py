# Databricks notebook source
# MAGIC %md 
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_jdbc_connection</h4>
# MAGIC <table><th>connid</th><th>conndesc</th><th>jdbcHostname</th><th>jdbcDatabase</th><th>jdbcPort</th><th>jdbcdriver</th><th>jdbcuser</th><th>jdbcpass</th></table>
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_control</h4>
# MAGIC <table><th>connid</th><th>srcschema</th><th>srctable</th><th>tgtschema</th><th>tgttable</th><th>srckeys</th><th>insertkey</th><th>updatekey</th><th>customqueryind</th><th>customquery</th></table>
# MAGIC
# MAGIC Note: If 'customquery' is True, then data_replication_bookmark table would not be used to refer to the 'bookmarkts' or update the 'bookmarkts'. Replication will be based on the 'customquery'
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_bookmark</h4>
# MAGIC <table><th>srcschema</th><th>srctable</th><th>bookmarkts</th><th>replicationts</th><th>srcrecords</th><th>tgtrecords</th><th>tgtinsrecords</th><th>tgtupdrecords</th></table>
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create table IF NOT EXISTS itda_io_dev.io_de_central.data_replication_jdbc_connection
# MAGIC (
# MAGIC   connid string,
# MAGIC   conndesc string,
# MAGIC   jdbcHostname string,
# MAGIC   jdbcDatabase string,
# MAGIC   jdbcPort string,
# MAGIC   jdbcdriver string,
# MAGIC   jdbcuser string,
# MAGIC   jdbcpass string
# MAGIC )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-de-central-stc@gmfcusdevitdaioslv01sa.dfs.core.windows.net/itda_io_dev/io_de_central/data_replication_jdbc_connection';

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from itda_io_dev.io_de_central.data_replication_jdbc_connection;
# MAGIC insert into itda_io_dev.io_de_central.data_replication_jdbc_connection values('1','CRT2UAT_Tejus_Connection','usbntlmicrtdb-scan.io.ad.gmfinancial.com','CRT2UAT','1521','oracle.jdbc.driver.OracleDriver','zxyhyr','Gmfinancial.2024');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_jdbc_connection values('2','BITUAT_Tejus_Connection','usbntlmcbitdb01.corp.ad.gmfinancial.com','BITUAT','1531','oracle.jdbc.driver.OracleDriver','zxyhyr','Gmfinancial.2024');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_jdbc_connection values('3','BITSIT_Uma_Connection','usbntlqcbitdb01.corp.ad.gmfinancial.com','BITSIT','1531','oracle.jdbc.driver.OracleDriver','ax39nr','GMFINANCIAL.08Aug2020');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create table IF NOT EXISTS itda_io_dev.io_de_central.data_replication_control
# MAGIC (
# MAGIC   activeind boolean,
# MAGIC   connid string,	
# MAGIC   srcschema string,	
# MAGIC   srctable	string,
# MAGIC   tgtschema	string,
# MAGIC   tgttable	string,
# MAGIC   srckeys string,
# MAGIC   insertkey string,
# MAGIC   updatekey string,
# MAGIC   customqueryind boolean,
# MAGIC   customquery string
# MAGIC )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-de-central-stc@gmfcusdevitdaioslv01sa.dfs.core.windows.net/itda_io_dev/io_de_central/data_replication_control';

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from itda_io_dev.io_de_central.data_replication_control;
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'1','T1_OS_ADMIN','OSUSR_1BW_BASEAPP3','itda_io_dev.io_org_brz','rep_osusr_1bw_baseapp3','id','createdon','updatedon',0,null);
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'1','T1_OS_ADMIN','OSUSR_D69_APPLICA5','itda_io_dev.io_org_brz','rep_osusr_d69_applica5','id','','',1,'select * from T1_OS_ADMIN.OSUSR_D69_APPLICA5');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'1','T1_OS_ADMIN','OSUSR_D69_GMFDECI3','itda_io_dev.io_org_brz','rep_osusr_d69_gmfdeci3','id','updatedon','updatedon',0,null);
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'1','T1_OS_ADMIN','OSUSR_D69_GMFDECIS','itda_io_dev.io_org_brz','rep_osusr_d69_gmfdecis','id','updatedon','updatedon',0,null);
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'1','T1_OS_ADMIN','OSUSR_D69_GMFVEHI2','itda_io_dev.io_org_brz','rep_osusr_d69_gmfvehi2','id','updatedon','updatedon',0,null);
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'2','ODS','VAP','itda_io_dev.io_rtl_brz','slv_vap','BRANCH_NBR|COUNTRY_CD|ACCOUNT_NBR|VAP_ID','insert_timstm','update_timstm',0,null);
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(0,'3','iocdm','measurement_period','itda_io_dev.io_cml_brz','measurement_period_gt','measurement_period_id','','',1,'select * from iocdm.measurement_period');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(1,'3','iocdm','payment_method','itda_io_dev.io_cml_brz','payment_method_gt','payment_method_id','','',1,'select * from iocdm.payment_method');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(1,'3','iocdm','plan','itda_io_dev.io_cml_brz','plan_gt','plan_id','','',1,'select * from iocdm.plan');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(1,'3','iocdm','supplier_plant','itda_io_dev.io_cml_brz','supplier_plant_gt','supplier_plant_id','','',1,'select * from iocdm.supplier_plant');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(1,'3','iocbdw','event_type','itda_io_dev.io_cml_brz','event_type_gt','event_type_id','','',1,'select * from iocbdw.event_type');
# MAGIC insert into itda_io_dev.io_de_central.data_replication_control values(1,'3','iocbdw','activity_reason_type','itda_io_dev.io_cml_brz','activity_reason_type_gt','activity_reason_type_id','','',1,'select * from iocbdw.activity_reason_type');

# COMMAND ----------

# MAGIC %sql
# MAGIC create table IF NOT EXISTS itda_io_dev.io_de_central.data_replication_bookmark
# MAGIC (
# MAGIC   srcschema string,	
# MAGIC   srctable	string,
# MAGIC   bookmarkts timestamp,
# MAGIC   replicationts timestamp,
# MAGIC   srcrecords int,
# MAGIC   tgtrecords int,
# MAGIC   tgtinsrecords int,
# MAGIC   tgtupdrecords int
# MAGIC )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-de-central-stc@gmfcusdevitdaioslv01sa.dfs.core.windows.net/itda_io_dev/io_de_central/data_replication_bookmark';