# Databricks notebook source
# MAGIC %md
# MAGIC #Data Replication

# COMMAND ----------

# MAGIC %md
# MAGIC #### Control Tables
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_jdbc_connection</h4>
# MAGIC <table><th>connid</th><th>conndesc</th><th>jdbcHostname</th><th>jdbcDatabase</th><th>jdbcPort</th><th>jdbcdriver</th><th>jdbcuser</th><th>jdbcpass</th></table>
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_control</h4>
# MAGIC <table><th>activeind</th><th>connid</th><th>srcschema</th><th>srctable</th><th>tgtschema</th><th>tgttable</th><th>srckeys</th><th>insertkey</th><th>updatekey</th><th>customqueryind</th><th>customquery</th></table>
# MAGIC
# MAGIC Note: If 'customquery' is True, then data_replication_bookmark table would not be used to refer to the 'bookmarkts' or update the 'bookmarkts'. Replication will be based on the 'customquery'
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_bookmark</h4>
# MAGIC <table><th>srcschema</th><th>srctable</th><th>bookmarkts</th><th>replicationts</th><th>srcrecords</th><th>tgtrecords</th><th>tgtinsrecords</th><th>tgtupdrecords</th></table>

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_de_central.data_replication_jdbc_connection;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_de_central.data_replication_control-- where activeind=true;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_de_central.data_replication_bookmark;

# COMMAND ----------

def data_updates_since_last_bookmark(connid,srcschema,srctable,insertkey,updatekey,customqueryind,customquery):
    jdbc_conn_df=spark.sql(f"select * from itda_io_dev.io_de_central.data_replication_jdbc_connection where connid='{connid}'")
    row=jdbc_conn_df.collect()[0]

    #For now hardcoding
    jdbcHostname = row['jdbcHostname']
    jdbcDatabase = row['jdbcDatabase']
    jdbcPort = row['jdbcPort']
    jdbcdriver = row['jdbcdriver']
    jdbcuser = row['jdbcuser']
    jdbcpass = row['jdbcpass']
    jdbcUrl = "jdbc:oracle:thin:@//{0}:{1}/{2}".format(jdbcHostname, jdbcPort, jdbcDatabase)
    if (customqueryind):
        data_pushdown_query=customquery
    else:
        df_bookmarkts=spark.sql("select max(bookmarkts) from itda_io_dev.io_de_central.data_replication_bookmark where srcschema='{0}' and srctable='{1}'".format(srcschema,srctable))
        if (df_bookmarkts.rdd.collect()[0][0] is None):
            bookmarkts='1900-01-01 00:00:00'
        else:
            bookmarkts=df_bookmarkts.rdd.collect()[0][0]
            bookmarkts=bookmarkts.strftime("%Y-%m-%d %H:%M:%S.%f") #explicit conversion to time format
            print("Last recorded Bookmark Timestamp is "+bookmarkts)
        data_pushdown_query = "SELECT * FROM {0}.{1} where NVL({3}, {4})>to_timestamp('{2}','yyyy-mm-dd HH24:MI:SS.FF6')".format(srcschema,srctable,bookmarkts,updatekey,insertkey)
    print("Using below pushdown sql statement:\n"+data_pushdown_query)
    sourceDF=spark.read \
    .format("jdbc") \
    .option("url", jdbcUrl) \
    .option("query", data_pushdown_query) \
    .option("user",jdbcuser) \
    .option("password",jdbcpass) \
    .option("driver",jdbcdriver) \
    .load()
    return sourceDF

# COMMAND ----------

def onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery):
    print("Replication initializing for OnPrem: {0}.{1} and Lakehouse: {2}.{3}".format(srcschema,srctable,tgtschema,tgttable))
    sourceDF=data_updates_since_last_bookmark(connid,srcschema,srctable,insertkey,updatekey,customqueryind,customquery)
    srcrecords=sourceDF.count()
    condition=[]
    for key in srckeys.split("|"):
        condition.append("source."+key+"=target."+key)
    delim = " and "
    merge_condition = reduce(lambda x, y: str(x) + delim + str(y), condition)
    print("Merge condition is: "+merge_condition)
    sourceDF.show()
    sourceDF.createOrReplaceTempView('source')
    #Merge
    spark.sql(
               """MERGE INTO {0}.{1} target
               USING source
               ON {2}
               WHEN MATCHED THEN
               UPDATE SET *
               WHEN NOT MATCHED THEN
               INSERT *""".format(tgtschema,tgttable,merge_condition)
            )
    #Merge Metrics
    df_hist=spark.sql("describe history {0}.{1}".format(tgtschema,tgttable))
    df_hist_latest_version=df_hist.filter(F.col('version')==df_hist.select(max('version')).collect()[0][0])
    operationmetrics_dict=df_hist_latest_version.select('operationMetrics').collect()[0][0]
    tgtrecords=operationmetrics_dict['numSourceRows']
    tgtinsrecords=operationmetrics_dict['numTargetRowsInserted']
    tgtupdrecords=operationmetrics_dict['numTargetRowsUpdated']
    print("Target Records: "+tgtrecords)
    print("Target Inserts: "+tgtinsrecords)
    print("Target Updates: "+tgtupdrecords)
    #update bookmark table
    if (not customqueryind):
        df_bookmarkts=spark.sql(f"select max(nvl({updatekey},{insertkey})) from {tgtschema}.{tgttable}")
        if (df_bookmarkts.rdd.collect()[0][0] is None):
            bookmarkts='1900-01-01 00:00:00'
        else:
            bookmarkts=df_bookmarkts.rdd.collect()[0][0]
            bookmarkts=bookmarkts.strftime("%Y-%m-%d %H:%M:%S.%f")
        print("New Bookmark Timestamp is "+bookmarkts) 
        replicationts=datetime.datetime.now()
        replicationts=replicationts.strftime("%Y-%m-%d %H:%M:%S.%f") 
        print("New Replication Timestamp is "+replicationts)  
        spark.sql("insert into itda_io_dev.io_de_central.data_replication_bookmark values('{0}','{1}','{2}','{3}',{4},{5},{6},{7})".format(srcschema,srctable,bookmarkts,replicationts,srcrecords,tgtrecords,tgtinsrecords,tgtupdrecords))

# COMMAND ----------

# MAGIC %md ### Individual Run

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE itda_io_dev.io_org_brz.rep_osusr_d69_gmfstage (
# MAGIC      ID BIGINT NOT NULL,
# MAGIC     QUOTEDATE TIMESTAMP,
# MAGIC     WITHRECOURSE TINYINT,
# MAGIC     FLEET TINYINT,
# MAGIC     FIXEDRATE TINYINT,
# MAGIC     DIRECTDEBIT TINYINT,
# MAGIC     PRODUCTTYPE INT,
# MAGIC     TERM INT,
# MAGIC     PLANCATEGORY STRING,
# MAGIC     PLANTYPE STRING,
# MAGIC     SPECIALPLAN TINYINT,
# MAGIC     SUBVENTEDPLAN TINYINT,
# MAGIC     VAPSDEFERREDPLAN TINYINT,
# MAGIC     CASHSELLINGPRICE DECIMAL(37,8),
# MAGIC     DOWNPAYMENTAMOUNT DECIMAL(37,8),
# MAGIC     DOWNPAYMENTPCT DECIMAL(37,8),
# MAGIC     DOWNPAYMENTTYPE STRING,
# MAGIC     SECURITYDEPOSITQUANTITY DECIMAL(37,8),
# MAGIC     SECURITYDEPOSITAMOUNT DECIMAL(37,8),
# MAGIC     FIRSTEXTRAORDINARYPAYMENTPCT DECIMAL(37,8),
# MAGIC     FIRSTEXTRAORDINARYPAYMENTAMO DECIMAL(37,8),
# MAGIC     CUSTOMERRATE DECIMAL(37,8),
# MAGIC     SMECREDITLINEREQUESTED DECIMAL(37,8),
# MAGIC     SMEFIRSTFLEETOPERATION TINYINT,
# MAGIC     MORETHANONECAR TINYINT,
# MAGIC     AMOUNTOFCARS INT,
# MAGIC     CARINSURANCEAMOUNT DECIMAL(37,8),
# MAGIC     YEARSOFFREECARINSURANCE INT,
# MAGIC     MONTHSOFFREECARINSURANCE INT,
# MAGIC     CARINSURANCEINITIALNETPREMIU DECIMAL(37,8),
# MAGIC     ADDITIONALCOVERAGE DECIMAL(37,8),
# MAGIC     INSURANCECOMPANYFREECAR STRING,
# MAGIC     POLICYNUMBERFREECAR STRING,
# MAGIC     OTHERCARINSURANCECOMPANY STRING,
# MAGIC     CARINSURANCEFINANCETYPE STRING,
# MAGIC     CARINSURANCEDEDUCTIBLE DECIMAL(37,8),
# MAGIC     INSURANCETERM INT,
# MAGIC     PRODUCT STRING,
# MAGIC     PREMIUMINSURANCECONTRACTUF DECIMAL(37,8),
# MAGIC     LIFEINSURANCEAMOUNT DECIMAL(37,8),
# MAGIC     CUSTOMERFINANCEDLIFEINSURANC TINYINT,
# MAGIC     LIFEINSURANCECOMPANY STRING,
# MAGIC     OTHERCOMPANYLIFEINSURANCE STRING,
# MAGIC     LIFEINSURANCETRIPLEPROTECTIO DECIMAL(37,8),
# MAGIC     CIRCULATEPERMISSIONAMOUNT DECIMAL(37,8),
# MAGIC     UNEMPLOYMENTINSURANCEAMOUNT DECIMAL(37,8),
# MAGIC     UNEMPLOYMENTINSURANCEPLANTY STRING,
# MAGIC     NOTDIRECTDEBITFEEAMOUNT DECIMAL(37,8),
# MAGIC     GAPAMOUNT DECIMAL(37,8),
# MAGIC     GAPCOMPANYNAME STRING,
# MAGIC     EXTENDEDWARRANTYAMOUNT DECIMAL(37,8),
# MAGIC     EXTENDEDWARRANTYCOMPANYNAME STRING,
# MAGIC     TYPEOFEXTENDEDWARRANTY STRING,
# MAGIC     PARTSANDACCESSORIESAMOUNT DECIMAL(37,8),
# MAGIC     ONSTARAMOUNT DECIMAL(37,8),
# MAGIC     ADDITIONALAMOUNTFINANCED DECIMAL(37,8),
# MAGIC     OPENINGFEEAMOUNT DECIMAL(37,8),
# MAGIC     PROMISSORYNOTETAXAMOUNT DECIMAL(37,8),
# MAGIC     MANDATORYINSURANCEAMOUNT DECIMAL(37,8),
# MAGIC     TRANSFERTAXAMOUNT DECIMAL(37,8),
# MAGIC     LIENFEEAMOUNT DECIMAL(37,8),
# MAGIC     GREENTAXAMOUNT DECIMAL(37,8),
# MAGIC     DEALERPROCESSINGFEE DECIMAL(37,8),
# MAGIC     SPREAD DECIMAL(37,8),
# MAGIC     VEHICLEREGISTRATIONFEE DECIMAL(37,8),
# MAGIC     PREPAIDMAINTENANCETYPE STRING,
# MAGIC     PREPAIDMAINTENANCEAMOUNT DECIMAL(37,8),
# MAGIC     CHEVISTARTYPE STRING,
# MAGIC     CHEVISTARAMOUNT DECIMAL(37,8),
# MAGIC     TOTALAMOUNTFINANCED DECIMAL(37,8),
# MAGIC     FIRSTPAYMENTDATE TIMESTAMP,
# MAGIC     MONTHLYREGULARPAYMENT DECIMAL(37,8),
# MAGIC     MONTHLYREGULARRENT DECIMAL(37,8),
# MAGIC     SUBSIDYAMOUNT DECIMAL(37,8),
# MAGIC     SUBSIDYPCT DECIMAL(37,8),
# MAGIC     DEALERCOMMISSION DECIMAL(37,8),
# MAGIC     MAXMONTHLYPAYMENTEXPECTED DECIMAL(37,8),
# MAGIC     MILEAGEODOMETER INT,
# MAGIC     FIRSTPAYMENTDATE_MANUAL TIMESTAMP,
# MAGIC     ADDITIONALPAYMENTAMOUNT DECIMAL(37,8),
# MAGIC     FIRSTEXTRAPAYMENTDATE TIMESTAMP,
# MAGIC     DEFERRALMONTHS INT,
# MAGIC     RESIDUALAMOUNT DECIMAL(37,8),
# MAGIC     EFFECTIVERATE DECIMAL(37,8),
# MAGIC     CALCULATEDDATA BIGINT,
# MAGIC     UPDATEDBY INT,
# MAGIC     UPDATEDON TIMESTAMP,
# MAGIC     CARINSURANCECOMPANY STRING,
# MAGIC     CONVERSIONRATE DECIMAL(37,2),
# MAGIC     TOTALEXPENSES DECIMAL(37,8),
# MAGIC     PLAN STRING,
# MAGIC     CARINSURANCEAMOUNTFINANCED TINYINT,
# MAGIC     LIFEINSURANCEAMOUNTFINANCED TINYINT,
# MAGIC     UNEMPLOYMENTINSURANCEAMOUNTF TINYINT,
# MAGIC     GAPAMOUNTFINANCED TINYINT,
# MAGIC     EXTENDEDWARRANTYAMOUNTFINANC TINYINT,
# MAGIC     PARTSANDACCESSORIESAMOUNTFIN TINYINT,
# MAGIC     ONSTARAMOUNTFINANCED TINYINT,
# MAGIC     OTHERAMOUNT DECIMAL(37,8),
# MAGIC     OTHERAMOUNTFINANCED TINYINT,
# MAGIC     OPENINGFEEAMOUNTFINANCED TINYINT,
# MAGIC     NOTDIRECTDEBITFEEAMOUNTFINAN TINYINT,
# MAGIC     MONTHLYCARINSURANCEAMOUNT DECIMAL(37,8),
# MAGIC     MONTHLYVEHICLEANDVAPSAMOUNT DECIMAL(37,8),
# MAGIC     ONSTARMONTHLYAMOUNT DECIMAL(37,8),
# MAGIC     UPSALELIFEINSURANCEAMOUNT DECIMAL(37,8),
# MAGIC     UPSALELIFEINSURANCEMONTHAMT DECIMAL(37,8),
# MAGIC     UPSALELIFEINSURANCEPCT DECIMAL(37,8),
# MAGIC     LIFEINSURANCEMONTHLYAMOUNT DECIMAL(37,8),
# MAGIC     UNEMPLOYMENTINSURANCEMONAMT DECIMAL(37,8),
# MAGIC     EXTENDEDWARRANTYMONTHLYAMT DECIMAL(37,8),
# MAGIC     PREPAIDMAINTENANCEMONTHLYAMT DECIMAL(37,8),
# MAGIC     CHEVISTARMONTHLYAMOUNT DECIMAL(37,8),
# MAGIC     VEHICLEREGISTRATIONFEEMONAMT DECIMAL(37,8),
# MAGIC     REGISTRATIONFORHOLDINGAMOUNT DECIMAL(37,8),
# MAGIC     UPRISINGFORHOLDINGAMOUNT DECIMAL(37,8),
# MAGIC     NETCASHSELLINGPRICE DECIMAL(37,8),
# MAGIC     ADAPTATIONAMOUNT DECIMAL(37,8),
# MAGIC     ADAPTATIONAMOUNTFINANCED TINYINT,
# MAGIC     SPECIALEQUIPMENTAMOUNT DECIMAL(37,8),
# MAGIC     SPECIALEQUIPMENTAMOUNTFINANC TINYINT,
# MAGIC     CIVILLIABILITYINSURANCEAMT DECIMAL(37,8),
# MAGIC     DAMAGECOVERAGEAMOUNT DECIMAL(37,8)
# MAGIC   )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-org-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_org_brz/rep_osusr_d69_gmfstage'

# COMMAND ----------

from pyspark.sql.functions import col,max
import json
from pyspark.sql import functions as F
from functools import reduce
from delta.tables import *
import datetime
connid='1'
srcschema='T1_OS_ADMIN'
srctable='OSUSR_D69_GMFSTAGE'
tgtschema='itda_io_dev.io_org_brz'
tgttable='rep_osusr_d69_gmfstage'
srckeys='ID'
insertkey=''
updatekey=''
customqueryind=True
customquery="select * from T1_OS_ADMIN.OSUSR_D69_GMFSTAGE where ID>=10000"
onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE itda_io_dev.io_org_brz.rep_osusr_d69_gmfstag2 (
# MAGIC id INT NOT NULL,
# MAGIC TOTALAMOUNTFINANCED	DECIMAL(37,8),
# MAGIC ACCESSORIESTOTALAMOUNT	DECIMAL(37,8),
# MAGIC ADDITIONALAMOUNTFINANCED	DECIMAL(37,8),
# MAGIC PRINCIPALAMOUNTFINANCED	DECIMAL(37,8),
# MAGIC OPENINGBALANCE	DECIMAL(37,8),
# MAGIC INTERESTEXPENSE	DECIMAL(37,8),
# MAGIC FIRSTPAYMENTDATE_AUTOMATIC	TIMESTAMP,
# MAGIC MONTHLYPAYMENTAMOUNT	DECIMAL(37,8),
# MAGIC MONTHLYREGULARRENT	DECIMAL(37,8),
# MAGIC RESIDUALAMOUNT	DECIMAL(37,8),
# MAGIC CUSTOMERRATE	DECIMAL(37,8),
# MAGIC EXTRADAYS	DECIMAL(37,8),
# MAGIC DEALERSUBSIDYAMOUNT	DECIMAL(37,8),
# MAGIC DEALERSUBSIDYPCT	DECIMAL(37,8),
# MAGIC DEALERCOMMISSION	DECIMAL(37,8),
# MAGIC DOWNPAYMENTAMOUNT	DECIMAL(37,8),
# MAGIC DOWNPAYMENTPCT	DECIMAL(37,8),
# MAGIC CAT	DECIMAL(37,8),
# MAGIC UFCLIENTVALUE	DECIMAL(37,8),
# MAGIC APR	DECIMAL(37,8),
# MAGIC INSURANCERATE	DECIMAL(37,8),
# MAGIC REALPLANRATE	DECIMAL(37,8),
# MAGIC SUBSIDYMANUFACTURE	DECIMAL(37,8),
# MAGIC SECURITYINTERESTAMOUNT	DECIMAL(37,8),
# MAGIC UPDATEDBY	DECIMAL(10,0),
# MAGIC UPDATEDON	TIMESTAMP,
# MAGIC LIFEINSURANCEMONTHLYAMOUNT	DECIMAL(37,8),
# MAGIC ACCESSORIESMONTHLYAMOUNT	DECIMAL(37,8),
# MAGIC NETDOWNPAYMENTAMOUNT	DECIMAL(37,8)
# MAGIC   )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-org-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_org_brz/rep_osusr_d69_gmfstag2'

# COMMAND ----------

# REPLICATION PROGRAM STARTS HERE
from pyspark.sql.functions import col,max
import json
from pyspark.sql import functions as F
from functools import reduce
from delta.tables import *
import datetime
connid='1'
srcschema='T1_OS_ADMIN'
srctable='OSUSR_D69_GMFSTAG2'
tgtschema='itda_io_dev.io_org_brz'
tgttable='rep_osusr_d69_gmfstag2'
srckeys='ID'
insertkey=''
updatekey=''
customqueryind=True
customquery="select * from T1_OS_ADMIN.OSUSR_D69_GMFSTAG2"
onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE itda_io_dev.io_org_brz.osusr_d69_gmfbusi4 (
# MAGIC   id BIGINT NOT NULL,
# MAGIC   partytype INT,
# MAGIC   updatedby INT,
# MAGIC   updatedon TIMESTAMP,
# MAGIC   role INT,
# MAGIC   gmfcompanydataid BIGINT,
# MAGIC   registrationyear INT,
# MAGIC   numberofemployees INT,
# MAGIC   validitydate TIMESTAMP,
# MAGIC   accountantname STRING,
# MAGIC   whichcorporations STRING,
# MAGIC   whichcountry STRING,
# MAGIC   grosssales DECIMAL(10,0),
# MAGIC   incorporationdate TIMESTAMP,
# MAGIC   accountanttaxid STRING,
# MAGIC   gmfpepdata BIGINT,
# MAGIC   annualsales DECIMAL(10,0),
# MAGIC   registrytype STRING,
# MAGIC   registrynumber STRING,
# MAGIC   registrydate TIMESTAMP,
# MAGIC   baseapplicationid INT,
# MAGIC   gmfcommercialrefdataid BIGINT,
# MAGIC   gmfrealownerdataid INT,
# MAGIC   gmfindustrygroup INT,
# MAGIC   gmfsocietytype INT,
# MAGIC   countryregistration INT,
# MAGIC   cityregistration INT,
# MAGIC   economicactivity INT,
# MAGIC   baseapplicantid INT,
# MAGIC   customertype INT,
# MAGIC   companybelongstoanygroup INT,
# MAGIC   affiliatedtocorporations INT,
# MAGIC   foreignfunds INT,
# MAGIC   chamberofcommerce INT,
# MAGIC   taxfolder INT,
# MAGIC   partysubtype INT,
# MAGIC   gmfcompanytype INT,
# MAGIC   internalfraudflagbusiness INT,
# MAGIC   dfeapplicantid INT,
# MAGIC   applicantrelationshipidfield INT,
# MAGIC   sharepercentage DECIMAL(10,0),
# MAGIC   shareholdertype STRING,
# MAGIC   shareholderinanotherrole STRING,
# MAGIC   dissolution INT,
# MAGIC   dissolutiondate TIMESTAMP,
# MAGIC   smescoreadjustment INT,
# MAGIC   fraudseverity STRING,
# MAGIC   fraudphoneverification STRING,
# MAGIC   fraudphoneverificationstatus STRING,
# MAGIC   idphoneverification STRING,
# MAGIC   idphoneverificationstatus STRING,
# MAGIC   documentverification STRING,
# MAGIC   documentverificationstatus STRING,
# MAGIC   residentialverification STRING,
# MAGIC   residentialverificationstat STRING,
# MAGIC   facetofaceverification STRING,
# MAGIC   facetofaceverificationstatus STRING,
# MAGIC   originofresources STRING,
# MAGIC   bridgerdisposition STRING,
# MAGIC   compliancepoints STRING,
# MAGIC   gmfexperienceflag INT,
# MAGIC   uwmarkashighrisk INT,
# MAGIC   internalfraudmatchdetailsid BIGINT,
# MAGIC   skipfraudwatch INT
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-org-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_org_brz/osusr_d69_gmfbusi4'

# COMMAND ----------

# REPLICATION PROGRAM STARTS HERE
from pyspark.sql.functions import col,max
import json
from pyspark.sql import functions as F
from functools import reduce
from delta.tables import *
import datetime
connid='1'
srcschema='T1_OS_ADMIN'
srctable='OSUSR_D69_GMFBUSI4'
tgtschema='itda_io_dev.io_org_brz'
tgttable='osusr_d69_gmfbusi4'
srckeys='ID'
insertkey=''
updatekey=''
customqueryind=True
customquery="select * from T1_OS_ADMIN.OSUSR_D69_GMFBUSI4"
onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE itda_io_dev.io_org_brz.rep_ossys_user (
# MAGIC   id INT NOT NULL,
# MAGIC   tenant_id INT,
# MAGIC   is_active INT,
# MAGIC   creation_date TIMESTAMP,
# MAGIC   last_login TIMESTAMP,
# MAGIC   name STRING,
# MAGIC   mobilephone STRING,
# MAGIC   email STRING,
# MAGIC   username STRING,
# MAGIC   password STRING,
# MAGIC   external_id STRING
# MAGIC )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-org-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_org_brz/rep_ossys_user'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE itda_io_dev.io_rtl_brz.slv_retail_fiance_plan (
# MAGIC BRANCH_NBR	INT	NOT NULL,
# MAGIC COUNTRY_CD	VARCHAR(3)	NOT NULL,
# MAGIC PLAN_ID	DECIMAL(38,0)	NOT NULL,
# MAGIC PRODUCT_CD	VARCHAR(10)	NOT NULL,
# MAGIC PROMOTION_ID	DECIMAL(10,0)	NOT NULL,
# MAGIC BUCKET_ID	DECIMAL(10,0)	NOT NULL,
# MAGIC PLAN_CD	DECIMAL(38,0)	NOT NULL,
# MAGIC PLAN_DESC	VARCHAR(35)	NOT NULL,
# MAGIC APPROVED_DT	DATE	NOT NULL,
# MAGIC APPROVER_USER_ID	VARCHAR(8)	NOT NULL,
# MAGIC ASSET_FROM_AGE	DECIMAL(38,0)	NOT NULL,
# MAGIC ASSET_TO_AGE	DECIMAL(38,0)	NOT NULL,
# MAGIC BALLOON_FROM_PCT	INT	NOT NULL,
# MAGIC BALLOON_TO_PCT	INT	NOT NULL,
# MAGIC BUCKET_RATE_CD	VARCHAR(20)	NOT NULL,
# MAGIC CAMPAIGN_CD	VARCHAR(20),
# MAGIC CAMPAIGN_IND	INT	NOT NULL,
# MAGIC CAMPAIGN_RATE	DECIMAL(10,7),
# MAGIC CREATED_DT	DATE	NOT NULL,
# MAGIC CREATED_USED_ID	VARCHAR(8)	NOT NULL,
# MAGIC CUSTOMER_CATEGORY_CD	VARCHAR(3)	NOT NULL,
# MAGIC CUSTOMER_RATE	INT	NOT NULL,
# MAGIC DEALER_CATEGORY_CD	VARCHAR(1)	NOT NULL,
# MAGIC DEALER_SUBSIDY_PCT	DECIMAL(10,7)	NOT NULL,
# MAGIC DOWN_PAYMENT_FROM_PCT	DECIMAL(10,7)	NOT NULL,
# MAGIC DOWN_PAYMENT_TO_PCT	DECIMAL(10,7)	NOT NULL,
# MAGIC EFFECTIVE_RATE	INT	NOT NULL,
# MAGIC END_DT	DATE	NOT NULL,
# MAGIC FINANCE_FROM_AMT	DECIMAL(16,2)	NOT NULL,
# MAGIC FINANCE_TO_AMT	DECIMAL(16,2)	NOT NULL,
# MAGIC GM_SUBSIDY_PCT	INT	NOT NULL,
# MAGIC LATE_CHARGE_RATE	INT,
# MAGIC MAXIMUM_DEALER_COMM_AMT	DECIMAL(16,2)	NOT NULL,
# MAGIC MILEAGE_FROM_CNT	DECIMAL(38,0)	NOT NULL,
# MAGIC MILEAGE_TO_CNT	DECIMAL(38,0)	NOT NULL,
# MAGIC PLAN_RATE	INT	NOT NULL,
# MAGIC PLAN_START_DT	DATE	NOT NULL,
# MAGIC PRODUCT_DESC	VARCHAR(50)	NOT NULL,
# MAGIC PROMOTION_NM	VARCHAR(50),
# MAGIC TERM_MINIMUM	DECIMAL(38,0)	NOT NULL,
# MAGIC TERM_MAXIMUM	DECIMAL(38,0)	NOT NULL,
# MAGIC VAP_POINTS_FROM	DECIMAL(38,0)	NOT NULL,
# MAGIC VAP_POINTS_TO	DECIMAL(38,0)	NOT NULL,
# MAGIC TOTAL_SUBSIDY_PCT	INT	NOT NULL,
# MAGIC INSERT_CYCLE_ID	INT	NOT NULL,
# MAGIC INSERT_TIMSTM	TIMESTAMP	NOT NULL,
# MAGIC UPDATE_CYCLE_ID	INT,
# MAGIC UPDATE_TIMSTM	TIMESTAMP,
# MAGIC CAP_TERM_AMT	DECIMAL(16,2),
# MAGIC DEALER_COMMISSION_FIXED_AMT	DECIMAL(16,2),
# MAGIC DEALER_COMMISSION_MIN_AMT	DECIMAL(16,2),
# MAGIC DEALER_COMMISSION_OVRD_IND	INT,
# MAGIC RECOURSE_CD	VARCHAR(10),
# MAGIC SECURITY_DEPOSIT_INSTLMT_CNT	INT,
# MAGIC VEHICLE_INS_FREE_MONTHS_CNT	INT,
# MAGIC VEHICLE_INSURANCE_TYPE_CD	VARCHAR(1),
# MAGIC PLAN_SALESMAN_COMM_PCT	INT,
# MAGIC PLAN_TYPE_CD	VARCHAR(1),
# MAGIC MRSP_CSP_SUBSIDY_CD	VARCHAR(1),
# MAGIC DEALER_SUBVENTION_RATE	INT,
# MAGIC DEALER_VEHICLE_INSURANCE_PCT	INT,
# MAGIC GMF_SUBSIDY_PCT	INT,
# MAGIC CUSTOMER_ACQUISITION_FEE_PCT	INT,
# MAGIC DEALER_ACQUISITION_FEE_PCT	INT,
# MAGIC DEALER_COMMISSION_PCT	INT,
# MAGIC GM_ACQUISITION_FEE_PCT	INT,
# MAGIC INTERNAL_ACQUISITION_FEE_PCT	INT,
# MAGIC DEALER_COMM_DIC_PCT	DECIMAL(10,7),
# MAGIC DEALER_COMM_FACTOR_RATE	DECIMAL(10,7),
# MAGIC DEALER_COMM_MAX_RATE	DECIMAL(10,7),
# MAGIC FINANCE_PLAN_TYPE_CD	VARCHAR(8),
# MAGIC PLAN_SPREAD_RATE	DECIMAL(10,7),
# MAGIC CURRENT_DTF_RATE	DECIMAL(10,7),
# MAGIC VAP_SPREAD_RATE	DECIMAL(10,7),
# MAGIC VAP_NOMINAL_RATE	DECIMAL(10,7),
# MAGIC BASE_RATE_DEF_CD	VARCHAR(1),
# MAGIC ASSET_TYPE_CD	VARCHAR(8),
# MAGIC DEALER_INS_COMM_PENTRTN_IND	INT	NOT NULL,
# MAGIC VEHICLE_INS_COMM_PENTRTN_IND	INT	NOT NULL,
# MAGIC ONSTAR_INS_COMM_PENTRTN_IND	INT	NOT NULL,
# MAGIC GAP_INS_COMM_PENTRTN_IND	INT	NOT NULL,
# MAGIC PLAN_FROM_TENURE	INT,
# MAGIC PLAN_TO_TENURE	INT,
# MAGIC BASE_RATE	DECIMAL(10,7),
# MAGIC PROMOTION_BONUS_APPLIED_IND	INT	NOT NULL,
# MAGIC PROMOTION_BONUS_FROM_DT	DATE,
# MAGIC PROMOTION_BONUS_TO_DT	DATE,
# MAGIC RATE_TABLE_AUTHN_DT	DATE,
# MAGIC PLAN_END_DT	DATE,
# MAGIC MFR_SUPPORT_RATE	DECIMAL(10,7),
# MAGIC DEALER_SUPPORT_RATE	DECIMAL(10,7),
# MAGIC PLAN_INTEREST_RATE	INT,
# MAGIC MINIMUM_INTEREST_RATE	INT,
# MAGIC TENURE	INT,
# MAGIC INSTALLMENT_CNT	INT,
# MAGIC SCHEME_START_DT	DATE,
# MAGIC SMART_BUY_IND	VARCHAR(1),
# MAGIC MORATORIUM_PERIOD	INT,
# MAGIC GMF_SHARE_PCT	INT,
# MAGIC GM_SHARE_PCT	INT,
# MAGIC DEALER_SHARE_PCT	INT,
# MAGIC ONSTAR_DEALER_COMM_PCT	INT,
# MAGIC GAP_DEALER_COMM_PCT	INT,
# MAGIC FLOATING_RATE_IND	VARCHAR(1),
# MAGIC VAP_FLOATING_RATE_IND	VARCHAR(1),
# MAGIC DEALER_COMM_CALC_LEVEL_CD	VARCHAR(1),
# MAGIC EXTRA_DAYS_IND	VARCHAR(1),
# MAGIC CUSTOMER_TYPE_CD	VARCHAR(1),
# MAGIC PLAN_SIMULATION_VALID_DT	DATE,
# MAGIC PLR_TYPE_CD	VARCHAR(8),
# MAGIC PLR_RATE_TYPE_CD	VARCHAR(8),
# MAGIC PLR_EFFECTIVE_RATE	DECIMAL(10,7),
# MAGIC SPREAD_RATE	DECIMAL(10,7),
# MAGIC PLR_RATE_CD	VARCHAR(1),
# MAGIC SPREAD_RATE_CD	VARCHAR(1),
# MAGIC SPREAD_IRR_CD	VARCHAR(1),
# MAGIC VAP_PLR_RATE_CD	VARCHAR(1),
# MAGIC VAP_PLR_TYPE_CD	VARCHAR(8),
# MAGIC VAP_EFFECTIVE_RATE	DECIMAL(10,7),
# MAGIC WHSL_FINANCE_IND	VARCHAR(1)
# MAGIC )
# MAGIC USING delta
# MAGIC LOCATION 'abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/slv_retail_fiance_plan'

# COMMAND ----------

# REPLICATION PROGRAM STARTS HERE
from pyspark.sql.functions import col,max
import json
from pyspark.sql import functions as F
from functools import reduce
from delta.tables import *
import datetime
connid='2'
srcschema='ODS'
srctable='RETAIL_FINANCE_PLAN'
tgtschema='itda_io_dev.io_rtl_brz'
tgttable='slv_retail_fiance_plan'
srckeys='BRANCH_NBR|COUNTRY_CD|PLAN_ID|PRODUCT_CD|PROMOTION_ID|BUCKET_ID'
insertkey=''
updatekey=''
customqueryind=True
customquery="select * from ODS.RETAIL_FINANCE_PLAN where country_cd='MX'"
onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

connid='1'
srcschema='T1_OS_ADMIN'
srctable='OSSYS_USER'
tgtschema='itda_io_dev.io_org_brz'
tgttable='rep_ossys_user'
srckeys='id'
insertkey=''
updatekey=''
customqueryind=True
customquery='select * from T1_OS_ADMIN.OSSYS_USER'
onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

# MAGIC %md ### Run the below for replicating everything as per data_replication_control table

# COMMAND ----------

# REPLICATION PROGRAM STARTS HERE
from pyspark.sql.functions import col,max
import json
from pyspark.sql import functions as F
from functools import reduce
from delta.tables import *
import datetime
df_DRC=spark.sql("select * from itda_io_dev.io_de_central.data_replication_control where activeind=true")
for row in df_DRC.rdd.toLocalIterator():
    connid=row['connid']
    srcschema=row['srcschema']
    srctable=row['srctable']
    tgtschema=row['tgtschema']
    tgttable=row['tgttable']
    srckeys=row['srckeys']
    insertkey=row['insertkey']
    updatekey=row['updatekey']
    customqueryind=row['customqueryind']
    customquery=row['customquery']
    onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table itda_io_dev.io_org_brz.rep_osusr_d69_gmfstage;

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table itda_io_dev.io_org_slv.osusr_d69_gmffrau1;

# COMMAND ----------

# MAGIC %md
# MAGIC ### End of Program. Other debug commands below