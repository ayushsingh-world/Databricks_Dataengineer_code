# Databricks notebook source
# MAGIC %md
# MAGIC #Data Replication

# COMMAND ----------

# MAGIC %md
# MAGIC #### Control Tables
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_jdbc_connection</h4>
# MAGIC <table><th>connid</th><th>conndesc</th><th>jdbcHostname</th><th>jdbcDatabase</th><th>jdbcPort</th><th>jdbcdriver</th><th>jdbcuser</th><th>jdbcpass</th></table>
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_control</h4>
# MAGIC <table><th>activeind</th><th>connid</th><th>srcschema</th><th>srctable</th><th>tgtschema</th><th>tgttable</th><th>srckeys</th><th>insertkey</th><th>updatekey</th><th>customqueryind</th><th>customquery</th></table>
# MAGIC
# MAGIC Note: If 'customquery' is True, then data_replication_bookmark table would not be used to refer to the 'bookmarkts' or update the 'bookmarkts'. Replication will be based on the 'customquery'
# MAGIC
# MAGIC <h4>itda_io_dev.io_de_central.data_replication_bookmark</h4>
# MAGIC <table><th>srcschema</th><th>srctable</th><th>bookmarkts</th><th>replicationts</th><th>srcrecords</th><th>tgtrecords</th><th>tgtinsrecords</th><th>tgtupdrecords</th></table>

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_de_central.data_replication_jdbc_connection;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_de_central.data_replication_control-- where activeind=true;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_de_central.data_replication_bookmark;

# COMMAND ----------

def data_updates_since_last_bookmark(connid,srcschema,srctable,insertkey,updatekey,customqueryind,customquery):
    jdbc_conn_df=spark.sql(f"select * from itda_io_dev.io_de_central.data_replication_jdbc_connection where connid='{connid}'")
    row=jdbc_conn_df.collect()[0]

    #For now hardcoding
    jdbcHostname = row['jdbcHostname']
    jdbcDatabase = row['jdbcDatabase']
    jdbcPort = row['jdbcPort']
    jdbcdriver = row['jdbcdriver']
    jdbcuser = row['jdbcuser']
    jdbcpass = row['jdbcpass']
    jdbcUrl = "jdbc:oracle:thin:@//{0}:{1}/{2}".format(jdbcHostname, jdbcPort, jdbcDatabase)
    if (customqueryind):
        data_pushdown_query=customquery
    else:
        df_bookmarkts=spark.sql("select max(bookmarkts) from itda_io_dev.io_de_central.data_replication_bookmark where srcschema='{0}' and srctable='{1}'".format(srcschema,srctable))
        if (df_bookmarkts.rdd.collect()[0][0] is None):
            bookmarkts='1900-01-01 00:00:00'
        else:
            bookmarkts=df_bookmarkts.rdd.collect()[0][0]
            bookmarkts=bookmarkts.strftime("%Y-%m-%d %H:%M:%S.%f") #explicit conversion to time format
            print("Last recorded Bookmark Timestamp is "+bookmarkts)
        data_pushdown_query = "SELECT * FROM {0}.{1} where NVL({3}, {4})>to_timestamp('{2}','yyyy-mm-dd HH24:MI:SS.FF6')".format(srcschema,srctable,bookmarkts,updatekey,insertkey)
    print("Using below pushdown sql statement:\n"+data_pushdown_query)
    sourceDF=spark.read \
    .format("jdbc") \
    .option("url", jdbcUrl) \
    .option("query", data_pushdown_query) \
    .option("user",jdbcuser) \
    .option("password",jdbcpass) \
    .option("driver",jdbcdriver) \
    .load()
    return sourceDF

# COMMAND ----------

def onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery):
    print("Replication initializing for OnPrem: {0}.{1} and Lakehouse: {2}.{3}".format(srcschema,srctable,tgtschema,tgttable))
    sourceDF=data_updates_since_last_bookmark(connid,srcschema,srctable,insertkey,updatekey,customqueryind,customquery)
    srcrecords=sourceDF.count()
    condition=[]
    for key in srckeys.split("|"):
        condition.append("source."+key+"=target."+key)
    delim = " and "
    merge_condition = reduce(lambda x, y: str(x) + delim + str(y), condition)
    print("Merge condition is: "+merge_condition)
    sourceDF.show()
    sourceDF.createOrReplaceTempView('source')
    #Merge
    spark.sql(
               """MERGE INTO {0}.{1} target
               USING source
               ON {2}
               WHEN MATCHED THEN
               UPDATE SET *
               WHEN NOT MATCHED THEN
               INSERT *""".format(tgtschema,tgttable,merge_condition)
            )
    #Merge Metrics
    df_hist=spark.sql("describe history {0}.{1}".format(tgtschema,tgttable))
    df_hist_latest_version=df_hist.filter(F.col('version')==df_hist.select(max('version')).collect()[0][0])
    operationmetrics_dict=df_hist_latest_version.select('operationMetrics').collect()[0][0]
    tgtrecords=operationmetrics_dict['numSourceRows']
    tgtinsrecords=operationmetrics_dict['numTargetRowsInserted']
    tgtupdrecords=operationmetrics_dict['numTargetRowsUpdated']
    print("Target Records: "+tgtrecords)
    print("Target Inserts: "+tgtinsrecords)
    print("Target Updates: "+tgtupdrecords)
    #update bookmark table
    if (not customqueryind):
        df_bookmarkts=spark.sql(f"select max(nvl({updatekey},{insertkey})) from {tgtschema}.{tgttable}")
        if (df_bookmarkts.rdd.collect()[0][0] is None):
            bookmarkts='1900-01-01 00:00:00'
        else:
            bookmarkts=df_bookmarkts.rdd.collect()[0][0]
            bookmarkts=bookmarkts.strftime("%Y-%m-%d %H:%M:%S.%f")
        print("New Bookmark Timestamp is "+bookmarkts) 
        replicationts=datetime.datetime.now()
        replicationts=replicationts.strftime("%Y-%m-%d %H:%M:%S.%f") 
        print("New Replication Timestamp is "+replicationts)  
        spark.sql("insert into itda_io_dev.io_de_central.data_replication_bookmark values('{0}','{1}','{2}','{3}',{4},{5},{6},{7})".format(srcschema,srctable,bookmarkts,replicationts,srcrecords,tgtrecords,tgtinsrecords,tgtupdrecords))

# COMMAND ----------

# MAGIC %md ### Individual Run

# COMMAND ----------

# REPLICATION PROGRAM STARTS HERE
from pyspark.sql.functions import col,max
import json
from pyspark.sql import functions as F
from functools import reduce
from delta.tables import *
import datetime
connid='1'
srcschema='T1_OS_ADMIN'
srctable='OSSYS_USER'
tgtschema='itda_io_dev.io_org_slv'
tgttable='ossys_user'
srckeys='ID'
insertkey=''
updatekey=''
customqueryind=True
customquery="select * from T1_OS_ADMIN.OSSYS_USER"
onprem_to_lakehouse_replicate(connid,srcschema,srctable,tgtschema,tgttable,srckeys,insertkey,updatekey,customqueryind,customquery)

# COMMAND ----------

# MAGIC %md
# MAGIC ### End of Program. Other debug commands below