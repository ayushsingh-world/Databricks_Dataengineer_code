# Databricks notebook source
# DBTITLE 1,Add entry to process log tables
def bronze_process_log_entry(process_log_table_name, config_table, config_rec_id, workflow_name, workflow_scheduler_group, notebook_path, src_obj_name, target_name, start_time, records_inserted, records_updated, records_deleted, end_time, status, last_process_message,src_records_cnt=0 ):
    try:
        last_process_message = last_process_message.replace("'", "")
        if isinstance(src_obj_name, str):
            # src_obj_name is a string
            src_obj_name = src_obj_name
        else:
            # src_obj_name is a list
            src_obj_name = ','.join(src_obj_name)
        query = f"""insert into {process_log_table_name} (config_table, config_rec_id, workflow_name, workflow_scheduler_group, notebook_path, src_obj_name, target_name, start_time, records_inserted, records_updated, records_deleted, end_time, status, last_process_message, src_records_cnt) values ('{config_table}', {config_rec_id}, '{workflow_name}',{workflow_scheduler_group}, '{notebook_path}',  '{src_obj_name}', '{target_name}', '{start_time}', {records_inserted}, {records_updated}, {records_deleted}, '{end_time}', '{status}', '{last_process_message}', {src_records_cnt})"""
        spark.sql(query)
    except Exception as e:
        print(f'Error in function bronze_process_log_entry:', str(e))
        raise

# COMMAND ----------

# DBTITLE 1,Add entry to Incident Management table
def bronze_process_incident_mgmt_entry(process_incident_mgmt_table_name, config_table, config_rec_id, workflow_name, src_obj_name, error_msg_type, error_msg, process_dt):
    try:
        query = f"""insert into {process_incident_mgmt_table_name} values ('{config_table}', {config_rec_id}, '{workflow_name}', '{src_obj_name}', '{error_msg_type}', '{error_msg}', '{process_dt}', null, null, null, null)"""
        spark.sql(query)
    except Exception as e:
        print(f'Error in function bronze_process_incident_mgmt_entry:', str(e))
        raise