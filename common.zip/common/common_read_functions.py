# Databricks notebook source
# DBTITLE 1,Read Delimited files
def read_delimited_file(file_with_header, read_format, file_delimiter, file_path, mode='PERMISSIVE', file_encoding='UTF-8', header_schema=None):
    try:
        if file_with_header == 'yes':
            options = {"header": "true", "delimiter": file_delimiter, "mode": mode, "encoding": file_encoding, "columnNameOfCorruptRecord": "_corrupt_record", 'multiLine':True}
        else:
            options = {"header": "false", "delimiter": file_delimiter, "mode": mode, "encoding": file_encoding, "columnNameOfCorruptRecord": "_corrupt_record", 'multiLine': True}

        if header_schema:
            df = spark.read.format(read_format).options(**options).schema(header_schema).load(file_path)
        else:
            df = spark.read.format(read_format).options(**options).load(file_path)

        return df
    
    except Exception as e:
        print(f"An error occurred while reading delimited file: {file_path}")
        print(f"Error message: {str(e)}")
        raise

# COMMAND ----------

# DBTITLE 1,Read Fixed Width File
def read_fixed_width_file(file_path, starting_points, col_list, mode='PERMISSIVE', file_encoding='UTF-8'):
    try:
        options = {"mode": mode, "encoding": file_encoding, "columnNameOfCorruptRecord": "_corrupt_record", 'multiLine': True}
        schema = col_list
        raw_df = spark.read.format("text").options(**options).load(file_path)
        column_expr = [substring(raw_df.value, starting_points[i-1]+1, starting_points[i]-starting_points[i-1]).alias(schema[i-1])
                       for i in range(1,len(starting_points))]
        #print(column_expr)
        df = raw_df.select(column_expr).select([col for col in schema])
        df = df.withColumn("file_nm", substring_index(input_file_name(), "/", -1))
        for col in df.columns:
            df = df.withColumn(col, ltrim(rtrim(df[col])))

        return df
    
    except Exception as e:
        print(f"An error occurred while reading the fixed width file: {str(e)}")
        raise

# COMMAND ----------

# DBTITLE 1,Read XML Files
def read_xml_file(file_path, rowTag, file_encoding='UTF-8', infer_schema=False):
    try:
        df = spark.read.format('xml'). \
            options(rowTag= rowTag, nullValue='', emptyValue='', valueTag='Value', excludeAttribute=False, encoding=file_encoding, inferSchema=infer_schema). \
            load(file_path)
        return df
    except Exception as e:
        print('Error while reading XML file:', str(e))
        raise

# COMMAND ----------

# DBTITLE 1,Get Oracle Data for Query
def get_data_from_oracle_query(keyscope, srcconnectionstring, driver, src_query, fetch_size=10000, additional_params=None, partition_col=None, num_partitions=None, lower_bound=None, upper_bound=None):
    try:
        jdbc_format = "jdbc"
        url = dbutils.secrets.get(scope = keyscope, key = srcconnectionstring)
        if additional_params:
            df = spark.read.format(jdbc_format) \
                 .option("url", url) \
                 .option("driver", driver) \
                 .option("query", src_query) \
                 .option("partitionColumn", partition_col) \
                 .option("numPartitions", num_partitions) \
                 .option("fetchsize", fetch_size) \
                 .option("lowerBound", lower_bound) \
                 .option("upperBound", upper_bound) \
                 .load()            
        else:
                df = spark.read.format(jdbc_format).option("url", url).option("driver", driver).option("query", src_query).option("fetchsize", fetch_size).load()
        return df
    except Exception as e:
        print('Error in get_data_from_oracle_query while reading data:', str(e))
        raise