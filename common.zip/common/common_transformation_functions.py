# Databricks notebook source
# DBTITLE 1,Parse any dictionary
def parse_dictionary(df):
    try:
        struct_array_fields = dict([(field.name, field.dataType)
                                    for field in df.schema.fields
                                    if (type(field.dataType) == ArrayType or  type(field.dataType) == StructType or type(field.dataType) == MapType)])

        while len(struct_array_fields) != 0:
            col_name = list(struct_array_fields.keys())[0]

            if type(struct_array_fields[col_name]) == StructType:
                expanded = [col(col_name+'.'+"`"+k+"`").alias(col_name+'/'+k.replace(".", "/")) for k in [ n.name for n in  struct_array_fields[col_name]]]
                df = df.select("*", *expanded).drop(col_name)

            if type(struct_array_fields[col_name]) == MapType:
                df1 = df.select(explode_outer(col_name).alias("Keys", "values"))
                list_map = df1.select('Keys').distinct().collect()
                expanded = [col(col_name+'.'+"`"+k+"`").alias(col_name+'/'+k.replace(".", "/")) for k in [ n[0] for n in list_map]]
                # expanded = [col(col_name+'.'+"`"+k+"`").alias(col_name+'/'+k.replace(".", "/")) for k in [ n.name for n in  struct_array_fields[col_name]]]
                df = df.select("*", *expanded).drop(col_name)

            elif type(struct_array_fields[col_name]) == ArrayType:    
                df = df.withColumn(col_name, explode_outer(col_name))

            struct_array_fields = dict([(field.name, field.dataType)
                                        for field in df.schema.fields
                                        if (type(field.dataType) == ArrayType or  type(field.dataType) == StructType) or type(field.dataType) == MapType])    
        return df
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        raise

# COMMAND ----------

# DBTITLE 1,Convert dataframe column to List
def dataframe_column_to_list(df, column_name):
    return df.select(column_name).rdd.flatMap(lambda x: x).collect()

# COMMAND ----------

# DBTITLE 1,Validate Dataframe with Target DataType
def validate_schema_with_target(tbl_df, final_df):
    try:
        schema = tbl_df.schema
        validated_df = final_df.select([col(c).cast(schema[c].dataType).alias(c) for c in schema.fieldNames()])
        return validated_df
    except Exception as e:          
        print(f"Error Occured while validating schema with the target: {e}")
        raise