# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

schema = StructType([
    StructField("Product_Plan_Code", StringType(), True),
    StructField("Vehicle_Type_Cd", StringType(), True),
    StructField("Dealer_Number", StringType(), True),
    StructField("MNR_CD", StringType(), True),
    StructField("DLR_TP_CD", StringType(), True),
    StructField("MFG_TP_CD", StringType(), True),
    StructField("VERSION_NUMBER", StringType(), True),
    StructField("PRODUCT_PLAN_TYPE_CD", StringType(), True),
    StructField("Vin", StringType(), True),
    StructField("Branch_Number", StringType(), True),
    StructField("ARANGMNT_RESOURCE_ITEM_TYPE_CD", StringType(), True),
    StructField("Paid_In_Full_Date", StringType(), True),
    StructField("RELEASE_DT", StringType(), True),
    StructField("NEW_FLAG", StringType(), True),
    StructField("ARANGMNT_TERM", StringType(), True),
    StructField("Maturity_Dt", StringType(), True),
    StructField("ORIG_MATURITY_DT", StringType(), True),
    StructField("MILEAGE_AMT", StringType(), True),
    StructField("GL_DT", StringType(), True),
    StructField("SUPPORT_END_DT", StringType(), True),
    StructField("MATURITY_DT_EXT_CNT", StringType(), True),
    StructField("ORIG_SUPPORT_END_DT", StringType(), True),
    StructField("SECURITIZATION_POOL_NBR", StringType(), True),
    StructField("SECURITIZATION_DT", StringType(), True),
    StructField("GUARANTEE_SUPPORT_END_DT", StringType(), True),
    StructField("Insurance_Start_Date", StringType(), True),
    StructField("INTEREST_START_DT", StringType(), True),
    StructField("TITLE_DOCUMENT_LOC_CD", StringType(), True),
    StructField("VIPS_NBR", StringType(), True),
    StructField("VIN_REFERENCE_NBR", StringType(), True),
    StructField("FACTORY_ORDER_NBR", StringType(), True),
    StructField("COMMENT_TXT", StringType(), True),
    StructField("COLLATERAL_RELEASE_DT", StringType(), True),
    StructField("SLIM_IND", StringType(), True),
    StructField("SUPPLIER_PLANT_CD", StringType(), True),
    StructField("SECURITIZED_RETURN_IND", StringType(), True),
    StructField("file_date", StringType(), True)
])


# COMMAND ----------

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE

# COMMAND ----------


TBL_NAME='GSW_ARANGMNT_RESOURCE_ITEM_EXTRACT_BT' ## Changes for a new table
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
FIL_NAME='Gsw_Arangmnt_Resource_Item_Extract' ## Changes for a new table

# COMMAND ----------

# In Bronze Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
FIL_LAYT="""
Product_Plan_Code string,
Vehicle_Type_Cd string,
Dealer_Number string,
MNR_CD string,
DLR_TP_CD string,
MFG_TP_CD string,
VERSION_NUMBER string,
PRODUCT_PLAN_TYPE_CD string,
Vin string,
Branch_Number string,
ARANGMNT_RESOURCE_ITEM_TYPE_CD string,
Paid_In_Full_Date string,
RELEASE_DT string,
NEW_FLAG string,
ARANGMNT_TERM string,
Maturity_Dt string,
ORIG_MATURITY_DT string,
SOLD_DT string,
MILEAGE_AMT string,
GL_DT string,
SUPPORT_END_DT string,
MATURITY_DT_EXT_CNT string,
ORIG_SUPPORT_END_DT string,
SECURITIZATION_POOL_NBR string,
SECURITIZATION_DT string,
GUARANTEE_SUPPORT_END_DT string,
Insurance_Start_Date string,
INTEREST_START_DT string,
TITLE_DOCUMENT_LOC_CD string,
VIPS_NBR string,
VIN_REFERENCE_NBR string,
MIDI_CD string,
FACTORY_ORDER_NBR string,
COMMENT_TXT string,
COLLATERAL_RELEASE_DT string,
SLIM_IND string,
SUPPLIER_PLANT_CD string,
SECURITIZED_IND string,
SECURITIZED_RETURN_IND string
"""

# COMMAND ----------

# MAGIC %md ##### Generic From Below (No Changes to do)

# COMMAND ----------

# MAGIC %md ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "csv") \
    .option("delimiter", "|") \
    .option("header", "false") \
    .option("cloudFiles.inferColumnTypes", "false") \
    .option("cloudFiles.partitionColumns", "file_date") \
    .option("cloudFiles.schemaLocation", SCM_PATH) \
    .schema(schema) \
    .load(ATL_PATH + "/*" + FIL_NAME + "*.txt")

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

col_nmbr=0
for line in FIL_LAYT.split('\n'):
    if line:
        col_name=line.split(" ")[0]
        df=df.withColumnRenamed("_c"+str(col_nmbr),col_name)
        col_nmbr=col_nmbr+1

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("mergeSchema", "true")\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.gsw_arangmnt_resource_item_extract_bt;