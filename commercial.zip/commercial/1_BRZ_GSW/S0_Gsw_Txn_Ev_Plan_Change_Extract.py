# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

schema = StructType([
    StructField("ORGANIZATION_UNIT_NBR", StringType(), True),
    StructField("VIN", StringType(), True),
    StructField("PLAN_TRANSFER_DT", StringType(), True),
    StructField("PLAN_CHANGE_REASON_CD", StringType(), True),
    StructField("NEW_DLR_NO", StringType(), True),
    StructField("NEW_PLAN_CD", StringType(), True),
    StructField("OLD_DLR_NO", StringType(), True),
    StructField("OLD_PLN_CD", StringType(), True),
    StructField("OLD_PLAN_START_DT", StringType(), True),
    StructField("OLD_FLAT_CHARGE_START_DT", StringType(), True),
    StructField("OLD_INTEREST_START_DT", StringType(), True),
    StructField("OLD_SUPPORT_END_DT", StringType(), True),
    StructField("NEW_PRELIMINARY_FIANANCE_IND", StringType(), True),
    StructField("TRANSFER_GL_DT", StringType(), True),
    StructField("OLD_FLAT_CHARGE_END_DT", StringType(), True),
    StructField("OLD_FLAT_CHARGE_PNT_DT", StringType(), True),
    StructField("OLD_SPT_END_DT1", StringType(), True),
    StructField("OLD_SPT_END_DT2", StringType(), True),
    StructField("OLD_VOLUME_TYPE_CD", StringType(), True),
    StructField("OLD_IB_FLAT_CHARGE_DT", StringType(), True),
    StructField("OLD_SUPPLIER_PLANT_CD", StringType(), True),
    StructField("OUTSTANDING_BALANCE_AMT", StringType(), True),
    StructField("file_date", StringType(), True)
])

# COMMAND ----------

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-05-31") #FILE_DATE

# COMMAND ----------


TBL_NAME='GSW_TXN_EV_PLAN_CHANGE_EXTRACT_BT' ## Changes for a new table
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
FIL_NAME='Gsw_Txn_Ev_Plan_Change_Extract' ## Changes for a new table

# COMMAND ----------

# In Bronze Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
FIL_LAYT="""
ORGANIZATION_UNIT_NBR string,
VIN string,
PLAN_TRANSFER_DT string,
PLAN_CHANGE_REASON_CD string,
NEW_DLR_NO string,
NEW_PLAN_CD string,
OLD_DLR_NO string,
OLD_PLN_CD string,
OLD_PLAN_START_DT string,
OLD_FLAT_CHARGE_START_DT string,
OLD_INTEREST_START_DT string,
OLD_SUPPORT_END_DT string,
NEW_PRELIMINARY_FIANANCE_IND string,
TRANSFER_GL_DT string,
OLD_FLAT_CHARGE_END_DT string,
OLD_FLAT_CHARGE_PNT_DT string,
OLD_SPT_END_DT1 string,
OLD_SPT_END_DT2 string,
OLD_VOLUME_TYPE_CD string,
OLD_IB_FLAT_CHARGE_DT string,
OLD_SUPPLIER_PLANT_CD string,
OUTSTANDING_BALANCE_AMT string
"""

# COMMAND ----------

# MAGIC %md ##### Generic From Below (No Changes to do)

# COMMAND ----------

# MAGIC %md ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "csv") \
    .option("delimiter", "|") \
    .option("header", "false") \
    .option("cloudFiles.inferColumnTypes", "false") \
    .option("cloudFiles.partitionColumns", "file_date") \
    .option("cloudFiles.schemaLocation", SCM_PATH) \
    .schema(schema) \
    .load(ATL_PATH + "/*" + FIL_NAME + "*.txt")

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

col_nmbr=0
for line in FIL_LAYT.split('\n'):
    if line:
        col_name=line.split(" ")[0]
        df=df.withColumnRenamed("_c"+str(col_nmbr),col_name)
        col_nmbr=col_nmbr+1

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("mergeSchema", "true")\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME)

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from itda_io_dev.io_cml_brz.GSW_TXN_EV_PLAN_CHANGE_EXTRACT_BT;

# COMMAND ----------

