# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

schema = StructType([
    StructField("BRN_ID_NO", StringType(), True),
    StructField("COL_ID", StringType(), True),
    StructField("TRANSACTION_TP_CD", StringType(), True),
    StructField("TRANSACTION_REASON_TP_CD", StringType(), True),
    StructField("TRANSACTION_DUE_DT", StringType(), True),
    StructField("TRANSACTION_BOOK_DT", StringType(), True)
    StructField("TRANSACTION_VALUE_DT", StringType(), True),
    StructField("TRANSACTION_AMT", StringType(), True),
    StructField("TRANSACTION_SEQUENCE_NBR", StringType(), True),
    StructField("EVENT_TYPE_CD", StringType(), True),
    StructField("EVENT_LIFE_CYCLE_STATUS_CD", StringType(), True),
    StructField("RESOURCE_ITEM_EVENT_TYPE_CD", StringType(), True)
    StructField("VEHICLE_TYPE_CD", StringType(), True),
    StructField("ACTIVITY_TYPE", StringType(), True),
    StructField("PAYMENT_METHOD_CD", StringType(), True),
    StructField("SOURCE_SYSTEM_REFERENCE_ID", StringType(), True),
    StructField("DLR_ID_NO", StringType(), True),
    StructField("Involved_Part_Event_TypeCode", StringType(), True),
    StructField("PAYMENT_SOURCE_TYPE", StringType(), True),
    StructField("PAYMENT_TYPE", StringType(), True),
    StructField("PLAN_CODE", StringType(), True),
    StructField("PAYMENT_DESCRIPTION", StringType(), True),
    StructField("BANK_NM", StringType(), True),
    StructField("BANK_SUBBLOCK_CD", StringType(), True),
    StructField("TRANSACTION_GL_DT", StringType(), True),
    StructField("file_date", StringType(), True)
])

# COMMAND ----------

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE

# COMMAND ----------


TBL_NAME='GSW_TXN_EV_RSRC_ITEMS_EXTRACT_BT' ## Changes for a new table
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
FIL_NAME='Gsw_Txn_Ev_Rsrc_Items_Extract' ## Changes for a new table

# COMMAND ----------

# In Bronze Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
FIL_LAYT="""
BRN_ID_NO string,
COL_ID string,
TRANSACTION_TP_CD string,
TRANSACTION_REASON_TP_CD string,
TRANSACTION_DUE_DT string,
TRANSACTION_BOOK_DT string,
TRANSACTION_VALUE_DT string,
TRANSACTION_AMT string,
TRANSACTION_SEQUENCE_NBR string,
EVENT_TYPE_CD string,
EVENT_LIFE_CYCLE_STATUS_CD string,
RESOURCE_ITEM_EVENT_TYPE_CD string,
VEHICLE_TYPE_CD string,
ACTIVITY_TYPE string,
PAYMENT_METHOD_CD string,
SOURCE_SYSTEM_REFERENCE_ID string,
DLR_ID_NO string,
Involved_Part_Event_TypeCode string,
PAYMENT_SOURCE_TYPE string,
PAYMENT_TYPE string,
PLAN_CODE string,
PAYMENT_DESCRIPTION string,
BANK_NM string,
BANK_SUBBLOCK_CD string,
TRANSACTION_GL_DT string
"""

# COMMAND ----------

# MAGIC %md ##### Generic From Below (No Changes to do)

# COMMAND ----------

# MAGIC %md ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "csv") \
    .option("delimiter", "|") \
    .option("header", "false") \
    .option("cloudFiles.inferColumnTypes", "false") \
    .option("cloudFiles.partitionColumns", "file_date") \
    .option("cloudFiles.schemaLocation", SCM_PATH) \
    .schema(schema) \
    .load(ATL_PATH + "/*" + FIL_NAME + "*.txt")

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

col_nmbr=0
for line in FIL_LAYT.split('\n'):
    if line:
        col_name=line.split(" ")[0]
        df=df.withColumnRenamed("_c"+str(col_nmbr),col_name)
        col_nmbr=col_nmbr+1

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("mergeSchema", "true")\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.gsw_txn_ev_rsrc_items_extract_bt;