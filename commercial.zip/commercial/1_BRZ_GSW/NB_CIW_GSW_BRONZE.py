# Databricks notebook source
# MAGIC %md ### Functions

# COMMAND ----------

def GenerateStageSchema(stage_cols_list):
    from pyspark.sql.types import _parse_datatype_string# Create new Schema for data
    schema_str = ' string,'.join(stage_cols_list)
    schema_str=schema_str+' string'
    schema = _parse_datatype_string(schema_str)
    return(schema)

# COMMAND ----------

# MAGIC %md ### Widgets and Initialization

# COMMAND ----------

#to clear widgets
#dbutils.widgets.removeAll()

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.functions import *

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-06-10") #FILE_DATE
dbutils.widgets.text('FIL_NAME',"Gsw_Product_Rate_Type_Extract") #FILE_NAME without extension

# COMMAND ----------

FIL_NAME=dbutils.widgets.get('FIL_NAME')
TBL_NAME=FIL_NAME.upper() 
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"

# COMMAND ----------

df_cols=spark.sql(f"select column_name from itda_io_dev.information_schema.columns where table_schema='io_cml_brz' and lower(table_name) =CONCAT(lower('{TBL_NAME}'),'_bt') and column_name not in ('file_date','_rescued_data') order by table_name,ordinal_position")

# COMMAND ----------


col_list=[item[0] for item in df_cols.collect()]

col_list.append('file_date')
col_list.append('_rescued_data')


# COMMAND ----------

schema=GenerateStageSchema(col_list)

# COMMAND ----------

print(schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Generic From Below (No Changes to do)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles").schema(schema)\
.option("cloudFiles.format", "csv")\
.option("delimiter","|")\
.option("header","false")\
.option("cloudFiles.inferColumnTypes", "false")\
.option("cloudFiles.partitionColumns","file_date")\
.option("cloudFiles.schemaLocation",SCM_PATH)\
.load(ATL_PATH+"/*"+FIL_NAME+"*.txt") #changes for a new file name

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

##display(df)

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME+"_bt")


# COMMAND ----------

spark.sql(f"""select * from itda_io_dev.io_cml_brz.{TBL_NAME}_bt where file_date='{FIL_DATE}'""").display()
##sql_str = (f"""select * from itda_io_dev.io_cml_brz.{TBL_NAME}_bt where file_date='{FIL_DATE}'""")
##print(sql_str)