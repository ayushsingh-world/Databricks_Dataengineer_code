# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

schema = StructType([
    StructField("GSWID", StringType(), True),
    StructField("BRANCHNUMBER", StringType(), True),
    StructField("WATCHLIST_REVIEW_STATUS_CD", StringType(), True),
    StructField("WATCHLIST_RISK_STATUS_CD", StringType(), True),
    StructField("IMPAIRMENT_STATUS_CD", StringType(), True),
    StructField("ACTIVATIONDATE", StringType(), True),
    StructField("REMOVALDATE", StringType(), True),
    StructField("TARGETDATE", StringType(), True),
    StructField("COMMENTS", StringType(), True),
    StructField("AUDITDATE", StringType(), True),
    StructField("RELEASECOUNT", StringType(), True),
    StructField("DELAYCOUNT", StringType(), True),
    StructField("WATCHLISTID", StringType(), True),
    StructField("INVOLVED_PARTY_TYPE_CD", StringType(), True),
    StructField("NON_ACCURAL_FLAG", StringType(), True),
    StructField("NON_ACCURAL_START_DT", StringType(), True),
    StructField("NON_ACCURAL_END_DT", StringType(), True),
    StructField("STRATEGY_TYPE_CD", StringType(), True),
    StructField("STRATEGY_TYPE_DESC", StringType(), True),
    StructField("file_date", StringType(), True)
])

# COMMAND ----------

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE

# COMMAND ----------

TBL_NAME='Crs_Involved_Party_Watchlist_Extract_BT' ## Changes for a new table
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
FIL_NAME='Crs_Involved_Party_Watchlist_Extract' ## Changes for a new table

# COMMAND ----------

# In Bronze Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
FIL_LAYT="""
GSWID string,
BRANCHNUMBER string,
WATCHLIST_REVIEW_STATUS_CD string,
WATCHLIST_RISK_STATUS_CD string,
IMPAIRMENT_STATUS_CD string,
ACTIVATIONDATE string,
REMOVALDATE string,
TARGETDATE string,
COMMENTS string,
AUDITDATE string,
RELEASECOUNT string,
DELAYCOUNT string,
WATCHLISTID   string,
INVOLVED_PARTY_TYPE_CD   string,
NON_ACCURAL_FLAG     string,
NON_ACCURAL_START_DT      string,
NON_ACCURAL_END_DT     string,
STRATEGY_TYPE_CD     string,
STRATEGY_TYPE_DESC     string
"""

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "csv") \
    .option("delimiter", "|") \
    .option("header", "false") \
    .option("cloudFiles.inferColumnTypes", "false") \
    .option("cloudFiles.partitionColumns", "file_date") \
    .option("cloudFiles.schemaLocation", SCM_PATH) \
    .schema(schema) \
    .load(ATL_PATH + "/*" + FIL_NAME + "*.txt")

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

col_nmbr=0
for line in FIL_LAYT.split('\n'):
    if line:
        col_name=line.split(" ")[0]
        df=df.withColumnRenamed("_c"+str(col_nmbr),col_name)
        col_nmbr=col_nmbr+1

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("mergeSchema", "true")\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.Crs_Involved_Party_Watchlist_Extract_BT;