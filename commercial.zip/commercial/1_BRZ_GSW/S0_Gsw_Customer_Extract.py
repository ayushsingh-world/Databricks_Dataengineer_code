# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

schema = StructType([
    StructField("DealerNumber", StringType(), True),
    StructField("CityName", StringType(), True),
    StructField("StateName", StringType(), True),
    StructField("Tax_Id", StringType(), True),
	StructField("CODE", StringType(), True),
    StructField("EMAIL_ADDRESS_DESC", StringType(), True),
    StructField("INDUSTRY_CLASSIFICATION_CD", StringType(), True),
    StructField("CountyName", StringType(), True),
	StructField("CountryName", StringType(), True),
    StructField("UnionCountryName", StringType(), True),
    StructField("TypeCode", StringType(), True),
    StructField("EFF_CUSTOMER_DT", StringType(), True),
	StructField("END_CUSTOMER_DT", StringType(), True),
    StructField("LIQUIDATION_IND", StringType(), True),
    StructField("TAX_CODE_ID", StringType(), True),
    StructField("THIRD_PARTY_TYPE_ID", StringType(), True),
	StructField("COMPANY_NM", StringType(), True),
    StructField("EMPLOYEE_CNT", StringType(), True),
    StructField("REGISTERED_PLACE_NM", StringType(), True),
    StructField("REFERENCE_NBR", StringType(), True),
	StructField("FISCAL_CD", StringType(), True),
    StructField("VAT_NBR", StringType(), True),
    StructField("Branch_Number", StringType(), True),
    StructField("ACTIVE_DEALER_FLAG", StringType(), True),
	StructField("DOING_BUSINESS_AS_NM", StringType(), True),
    StructField("RELEASE_PRIVILEGE_EFF_DT", StringType(), True),
    StructField("RELEASE_PRIVILEGE_DAYS_NBR", StringType(), True),
	StructField("FLAT_CHARGE_CATEGORY_EFF_DT", StringType(), True),
    StructField("FLAT_CHARGE_CATEGORY_ID", StringType(), True),
    StructField("PRIMARY_PHONE_NBR", StringType(), True),
    StructField("file_date", StringType(), True)
])

# COMMAND ----------

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE

# COMMAND ----------


TBL_NAME='GSW_CUSTOMER_EXTRACT_BT' ## Changes for a new table
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
FIL_NAME='Gsw_Customer_Extract' ## Changes for a new table

# COMMAND ----------

# In Bronze Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
FIL_LAYT="""
DealerNumber string,
CityName string,
StateName string,
Tax_Id string,
CODE string,
EMAIL_ADDRESS_DESC string,
INDUSTRY_CLASSIFICATION_CD string,
CountyName string,
CountryName string,
UnionCountryName string,
TypeCode string,
EFF_CUSTOMER_DT string,
END_CUSTOMER_DT string,
LIQUIDATION_IND string,
TAX_CODE_ID string,
THIRD_PARTY_TYPE_ID string,
COMPANY_NM string,
EMPLOYEE_CNT string,
REGISTERED_PLACE_NM string,
REFERENCE_NBR string,
FISCAL_CD string,
VAT_NBR string,
Branch_Number string,
ACTIVE_DEALER_FLAG string,
DOING_BUSINESS_AS_NM string,
RELEASE_PRIVILEGE_EFF_DT string,
RELEASE_PRIVILEGE_DAYS_NBR string,
FLAT_CHARGE_CATEGORY_EFF_DT string,
FLAT_CHARGE_CATEGORY_ID string,
PRIMARY_PHONE_NBR string
"""

# COMMAND ----------

# MAGIC %md ##### Generic From Below (No Changes to do)

# COMMAND ----------

# MAGIC %md ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "csv") \
    .option("delimiter", "|") \
    .option("header", "false") \
    .option("cloudFiles.inferColumnTypes", "false") \
    .option("cloudFiles.partitionColumns", "file_date") \
    .option("cloudFiles.schemaLocation", SCM_PATH) \
    .schema(schema) \
    .load(ATL_PATH + "/*" + FIL_NAME + "*.txt")

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

col_nmbr=0
for line in FIL_LAYT.split('\n'):
    if line:
        col_name=line.split(" ")[0]
        df=df.withColumnRenamed("_c"+str(col_nmbr),col_name)
        col_nmbr=col_nmbr+1

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("mergeSchema", "true")\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.gsw_customer_extract_bt 

# COMMAND ----------

