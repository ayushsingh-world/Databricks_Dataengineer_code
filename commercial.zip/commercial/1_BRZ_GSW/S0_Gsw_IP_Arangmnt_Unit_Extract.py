# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

schema = StructType([
    StructField("DealerNumber", StringType(), True),
    StructField("IP_ARANGMNT_UNIT_TP_CD", StringType(), True),
    StructField("ARANGMNT_UNIT_TYPE_CD", StringType(), True),
    StructField("INVOLVED_PARTY_TYPE_CD", StringType(), True),
    StructField("BranchNumber", StringType(), True),
    StructField("file_date", StringType(), True)
])

# COMMAND ----------

dbutils.widgets.text('ATL_PATH',"dbfs:/FileStore/data/lakehouse/CIW/Ingest") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-05-31") #FILE_DATE

# COMMAND ----------


TBL_NAME='GSW_IP_ARANGMNT_UNIT_EXTRACT_BT' ## Changes for a new table
ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
FIL_NAME='Gsw_IP_Arangmnt_Unit_Extract' ## Changes for a new table

# COMMAND ----------

# In Bronze Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
FIL_LAYT="""
DealerNumber string,
IP_ARANGMNT_UNIT_TP_CD string,
ARANGMNT_UNIT_TYPE_CD string,
INVOLVED_PARTY_TYPE_CD string,
BranchNumber string
"""

# COMMAND ----------

# MAGIC %md ##### Generic From Below (No Changes to do)

# COMMAND ----------

# MAGIC %md ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE)
!perl -p -i -e 's/\r\n$/\n/g' /dbfs/FileStore/data/lakehouse/CIW/Landing/*.txt
dbutils.fs.mv('/FileStore/data/lakehouse/CIW/Landing/'+FIL_NAME+".txt",ATL_PATH+"/"+FIL_NAME+"/file_date="+FIL_DATE+"/")

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "csv") \
    .option("delimiter", "|") \
    .option("header", "false") \
    .option("cloudFiles.inferColumnTypes", "false") \
    .option("cloudFiles.partitionColumns", "file_date") \
    .option("cloudFiles.schemaLocation", SCM_PATH) \
    .schema(schema) \
    .load(ATL_PATH + "/*" + FIL_NAME + "*.txt")

#df=df.withColumn("file_date", col("file_date").cast("date"))

# COMMAND ----------

col_nmbr=0
for line in FIL_LAYT.split('\n'):
    if line:
        col_name=line.split(" ")[0]
        df=df.withColumnRenamed("_c"+str(col_nmbr),col_name)
        col_nmbr=col_nmbr+1

# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd"))

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy('file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("mergeSchema", "true")\
    .option("append","false")\
    .table("itda_io_dev.io_cml_brz."+TBL_NAME)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  itda_io_dev.io_cml_brz.GSW_IP_ARANGMNT_UNIT_EXTRACT_BT