# Databricks notebook source
# MAGIC %sql
# MAGIC drop table if exists itda_io_dev.io_cml_brz.ws_involved_party_risk_rating_bt;

# COMMAND ----------

dbutils.widgets.text('LND_PATH', "", label="Astra Source Path") #LANDING PATH
dbutils.widgets.text('FIL_NAME', "", label="Astra Source File") #ASTRA SOURCE FILE


# COMMAND ----------

LND_PATH=dbutils.widgets.get('LND_PATH')
FIL_NAME=dbutils.widgets.get('FIL_NAME')

ASTRA_SRC_FILE = LND_PATH+FIL_NAME

# COMMAND ----------

df = spark.read.option('multiline',True).json(ASTRA_SRC_FILE)

# COMMAND ----------

from pathlib import Path
file_name = Path(ASTRA_SRC_FILE).stem
TABLE_NAME = file_name.upper()

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import * 

def flatten(df):

    complex_fields = dict([(field.name, field.dataType)
                           for field in df.schema.fields
                           if type(field.dataType) == ArrayType or type(field.dataType) == StructType])
    counter = len(complex_fields)
    while counter > 0:
        col_name=list(complex_fields.keys())[0]
        print ("Processing :"+col_name+" Type : "+str(type(complex_fields[col_name])))

        if (type(complex_fields[col_name]) == ArrayType):
            df=df.withColumn(col_name,explode_outer(col_name))

        elif (type(complex_fields[col_name]) == StructType):
            expanded = [col (col_name+ '.'+k).alias(col_name+'_'+k) for k in [ n.name for n in complex_fields[col_name]]]
            df=df.select("*", *expanded).drop(col_name)

        complex_fields = dict([(field.name, field.dataType)
                               for field in df.schema.fields
                               if type(field.dataType) == ArrayType or type(field.dataType) == StructType])
        counter = len(complex_fields)
      
    return df

# COMMAND ----------

df = flatten(df)
df = df.drop("count")

# COMMAND ----------

total_columns=df.columns
for i in range(len(total_columns)):
    df=df.withColumnRenamed(total_columns[i], total_columns[i].replace('data_',''))
    df=df.withColumnRenamed(total_columns[i], total_columns[i].replace('\n',''))
    df=df.withColumnRenamed(total_columns[i], total_columns[i].replace(' ',''))

    df = df.withColumn("file_date", current_date())


# COMMAND ----------

df.write.format("delta")\
  .option('path', f"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/ws_{TABLE_NAME}_bt")\
  .partitionBy('file_date')\
  .mode("append")\
  .saveAsTable(f"itda_io_dev.io_cml_brz.ws_{TABLE_NAME}_bt")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_Involved_Party_Risk_Rating_bt;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_involved_party_risk_rating_bt;