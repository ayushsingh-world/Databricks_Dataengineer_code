# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_arangmnt_unit_balance_dlrothrcrg_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("DEALERNUMBER", when(df.DealerNumber.isNull(),"NA") \
    .when(df.DealerNumber=="","NA") \
    .otherwise(df.DealerNumber))
df=df.withColumn("BRANCHNUMBER", when(df.BranchNumber.isNull(),"NA") \
    .when(df.BranchNumber=="","NA") \
    .otherwise(df.BranchNumber))
df=df.withColumn("ARANGMNT_UNIT_BALANCE_TYPE_CD", when(df.ARANGMNT_UNIT_BALANCE_TYPE_CD.isNull(),"NA") \
    .when(df.ARANGMNT_UNIT_BALANCE_TYPE_CD=="","NA") \
    .otherwise(df.ARANGMNT_UNIT_BALANCE_TYPE_CD))
df=df.withColumn("ARANGMNT_UNIT_TYPE_CD", when(df.ARANGMNT_UNIT_TYPE_CD.isNull(),"NA") \
    .when(df.ARANGMNT_UNIT_TYPE_CD=="","NA") \
    .otherwise(df.ARANGMNT_UNIT_TYPE_CD))
df=df.withColumn("IP_ARANGMNT_UNIT_TP_CD", when(df.IP_ARANGMNT_UNIT_TP_CD.isNull(),"NA") \
    .when(df.IP_ARANGMNT_UNIT_TP_CD=="","NA") \
    .otherwise(df.IP_ARANGMNT_UNIT_TP_CD))    
df=df.withColumn("AMOUNT", when(df.Amount.isNull(),"NA") \
    .when(df.Amount=="","NA") \
    .otherwise(df.Amount))

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType
from pyspark.sql.types import IntegerType

# COMMAND ----------

df = df.withColumn("AMOUNT", df["AMOUNT"].cast(DecimalType(38,2)))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_UNIT_BALANCE_DLROTHRCRG_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""   
DEALERNUMBER				     VARCHAR(20) NOT NULL,
BRANCH_NBR                       VARCHAR(20) NOT NULL,
ARANGMNT_UNIT_BALANCE_TYPE_CD    VARCHAR(255) NOT NULL,
ARANGMNT_UNIT_TYPE_CD           VARCHAR(255) NOT NULL,\
IP_ARANGMNT_UNIT_TP_CD           VARCHAR(50) NOT NULL,
AMOUNT                           DECIMAL(38) NOT NULL,
INSERT_TIMSTM                    TIMESTAMP,
UPDATE_TIMSTM                    TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARANGMNT_UNIT_BALANCE_DLROTHRCRG_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ARANGMNT_UNIT_BALANCE_DLROTHRCRG_ST as TGT USING TEMP_ARANGMNT_UNIT_BALANCE_DLROTHRCRG_SIL as SRS ON 
# MAGIC TGT.DEALERNUMBER = SRS.DEALERNUMBER AND
# MAGIC TGT.BRANCH_NBR = SRS.BRANCHNUMBER AND
# MAGIC TGT.ARANGMNT_UNIT_BALANCE_TYPE_CD = SRS.ARANGMNT_UNIT_BALANCE_TYPE_CD AND
# MAGIC TGT.ARANGMNT_UNIT_TYPE_CD = SRS.ARANGMNT_UNIT_TYPE_CD AND
# MAGIC TGT.IP_ARANGMNT_UNIT_TP_CD = SRS.IP_ARANGMNT_UNIT_TP_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET    
# MAGIC TGT.AMOUNT = SRS.AMOUNT,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (DEALERNUMBER,BRANCH_NBR,ARANGMNT_UNIT_BALANCE_TYPE_CD,ARANGMNT_UNIT_TYPE_CD,AMOUNT,IP_ARANGMNT_UNIT_TP_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRS.DEALERNUMBER,SRS.BRANCHNUMBER,SRS.ARANGMNT_UNIT_BALANCE_TYPE_CD,SRS.ARANGMNT_UNIT_TYPE_CD,SRS.AMOUNT,
# MAGIC SRS.IP_ARANGMNT_UNIT_TP_CD,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ARANGMNT_UNIT_BALANCE_DLROTHRCRG_ST;