# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-12'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_ownership_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df=df.withColumn("owner_middle_nm",when(df.owner_middle_nm.isNull(),"NA")
     .when(df.owner_middle_nm=="","NA")
     .otherwise(df.owner_middle_nm))
df=df.withColumn("owner_last_nm",when(df.owner_last_nm.isNull(),"NA")
     .when(df.owner_last_nm=="","NA")
     .otherwise(df.owner_last_nm))
df=df.withColumn("owner_sec_last_nm",when(df.owner_sec_last_nm.isNull(),"NA")
     .when(df.owner_sec_last_nm=="","NA")
     .otherwise(df.owner_sec_last_nm))
df = df.withColumn("birth_country_nm", when(df.birth_country_nm.isNull(), 'NA')
     .otherwise(df.birth_country_nm))
df = df.withColumn("date_of_birth", 
                   when((df.date_of_birth.isNotNull()) & (df.date_of_birth != ""), df.date_of_birth)
                   .otherwise('1900-01-01'))
df = df.withColumn("client_id_owner", df["client_id_owner"].cast(DecimalType(38, 0)))

# COMMAND ----------

df.withColumnRenamed("client_id_owner","OBLIGOR_ID")\
  .withColumnRenamed("owner_nm","FULL_NM")\
  .withColumnRenamed("owner_first_nm","FIRST_NM")\
  .withColumnRenamed("owner_middle_nm","MIDDLE_NM")\
  .withColumnRenamed("owner_last_nm","LAST_NM")\
  .withColumnRenamed("owner_sec_last_nm","SEC_LAST_NM")\
  .withColumnRenamed("owner_legal_nm","LEGAL_NM")\
  .withColumnRenamed("owner_trading_nm","TRADING_NM")\
  .withColumnRenamed("date_of_birth","BIRTH_DATE")\
  .withColumnRenamed("birth_country_nm","BIRTH_COUNTRY_NM")\
  .withColumnRenamed("tax_id","TAX_ID")

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType

# COMMAND ----------

df.createOrReplaceTempView("TEMP_OWNER_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BIRTH_COUNTRY_NM	VARCHAR(255),
BRANCH_NUMBER VARCHAR(255),
CITY VARCHAR(255),
OBLIGOR_ID DECIMAL,
COUNTRY_NAME VARCHAR(255),
COUNTY_NAME VARCHAR(255),
BIRTH_DATE	DATE,
EMAIL_ADDRESS VARCHAR(255),
ESTABLISHEDON VARCHAR(255),
INDUSTRY_CLASSIFICATION_CD VARCHAR(255),
INVOLVED_PARTY_INV_PTY_TP_CD VARCHAR(255),
IP_TYPE_CD VARCHAR(255),
FULL_NM	VARCHAR(255),
FIRST_NM	VARCHAR(255),
MIDDLE_NM	VARCHAR(255),
LAST_NM	VARCHAR(255),
SEC_LAST_NM	VARCHAR(255),
LEGAL_NM	VARCHAR(255),
TRADING_NM	VARCHAR(255),
STATE VARCHAR(255),
TAX_ID	VARCHAR(20),
THIRD_PARTY_TYPE_CD VARCHAR(255),
UNION_COUNTRY_NAME VARCHAR(255),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='OWNER_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.OWNER_ST AS TGT USING TEMP_OWNER_SIL AS SRC ON
# MAGIC TGT.OBLIGOR_ID = SRC.CLIENT_ID_OWNER AND
# MAGIC TGT.BIRTH_COUNTRY_NM = SRC.BIRTH_COUNTRY_NM AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER_OWNER
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC TGT.BIRTH_COUNTRY_NM = SRC.BIRTH_COUNTRY_NM,
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER_OWNER,
# MAGIC TGT.CITY = SRC.CITY,
# MAGIC TGT.OBLIGOR_ID = SRC.CLIENT_ID_OWNER,
# MAGIC TGT.COUNTRY_NAME = SRC.COUNTRY_NM,
# MAGIC TGT.COUNTY_NAME = SRC.COUNTY_NM,
# MAGIC TGT.BIRTH_DATE = SRC.DATE_OF_BIRTH,
# MAGIC TGT.EMAIL_ADDRESS = SRC.EMAIL_ADDRESS,
# MAGIC TGT.ESTABLISHEDON = SRC.ESTABLISHEDON,
# MAGIC TGT.INDUSTRY_CLASSIFICATION_CD = SRC.INDUSTRY_CLASSIFICATION_CD,
# MAGIC TGT.INVOLVED_PARTY_INV_PTY_TP_CD = SRC.INVOLVED_PARTY_INV_PTY_TP_CD,
# MAGIC TGT.IP_TYPE_CD = SRC.IP_TYPE_CD,
# MAGIC TGT.FULL_NM	= SRC.OWNER_NM,
# MAGIC TGT.FIRST_NM = SRC.OWNER_FIRST_NM,
# MAGIC TGT.MIDDLE_NM = SRC.OWNER_MIDDLE_NM,
# MAGIC TGT.LAST_NM = SRC.OWNER_LAST_NM,
# MAGIC TGT.SEC_LAST_NM = SRC.OWNER_SEC_LAST_NM,
# MAGIC TGT.LEGAL_NM = SRC.OWNER_LEGAL_NM,
# MAGIC TGT.TRADING_NM = SRC.OWNER_TRADING_NM,
# MAGIC TGT.STATE = SRC.STATE,
# MAGIC TGT.TAX_ID = SRC.TAX_ID,
# MAGIC TGT.THIRD_PARTY_TYPE_CD = SRC.THIRD_PARTY_TYPE_CD,
# MAGIC TGT.UNION_COUNTRY_NAME = SRC.UNION_COUNTRY_NM,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.BIRTH_COUNTRY_NM,TGT.BRANCH_NUMBER,TGT.CITY,TGT.OBLIGOR_ID,TGT.COUNTRY_NAME,TGT.COUNTY_NAME,TGT.BIRTH_DATE,TGT.EMAIL_ADDRESS,TGT.ESTABLISHEDON,TGT.INDUSTRY_CLASSIFICATION_CD,TGT.INVOLVED_PARTY_INV_PTY_TP_CD,
# MAGIC TGT.IP_TYPE_CD,TGT.FULL_NM,TGT.FIRST_NM,TGT.MIDDLE_NM,TGT.LAST_NM,TGT.SEC_LAST_NM,TGT.LEGAL_NM,TGT.TRADING_NM,TGT.STATE,TGT.TAX_ID,TGT.THIRD_PARTY_TYPE_CD,TGT.UNION_COUNTRY_NAME,TGT.INSERT_TIMSTM)
# MAGIC   VALUES (SRC.BIRTH_COUNTRY_NM, SRC.BRANCH_NUMBER_OWNER, SRC.CITY, SRC.CLIENT_ID_OWNER, SRC.COUNTRY_NM, SRC.COUNTY_NM, SRC.DATE_OF_BIRTH, SRC.EMAIL_ADDRESS, SRC.ESTABLISHEDON, SRC.INDUSTRY_CLASSIFICATION_CD, SRC.INVOLVED_PARTY_INV_PTY_TP_CD,SRC.IP_TYPE_CD,SRC.OWNER_NM,SRC.OWNER_FIRST_NM,SRC.OWNER_MIDDLE_NM,SRC.OWNER_LAST_NM,SRC.OWNER_SEC_LAST_NM,SRC.OWNER_LEGAL_NM,SRC.OWNER_TRADING_NM,SRC.STATE,SRC.TAX_ID,SRC.THIRD_PARTY_TYPE_CD,SRC.UNION_COUNTRY_NM,CURRENT_TIMESTAMP());