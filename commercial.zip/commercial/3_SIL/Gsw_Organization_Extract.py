# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_ORGANIZATION_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.functions import *
from pyspark.sql.functions import when


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.withColumn("StateName", when(df.StateName.isNull(),"NA") \
    .when(df.StateName=="","NA") \
    .otherwise(df.StateName))
df=df.withColumn("IndustryGroupCode", when(df.IndustryGroupCode.isNull(),"NA") \
    .when(df.IndustryGroupCode=="","NA") \
    .otherwise(df.IndustryGroupCode))
df=df.withColumn("COUNTY_NM", when(df.COUNTY_NM.isNull(),"NA") \
    .when(df.COUNTY_NM=="","NA") \
    .otherwise(df.COUNTY_NM))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ORGANIZATION_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
CITY_NM                 VARCHAR(50),
STATE_NM                VARCHAR(50),
DEALER_TAX_ID           VARCHAR(50),
DEALER_NBR              VARCHAR(255) NOT NULL,
DEALER_NM               VARCHAR(255),
INDUSTRY_GROUP_CODE     VARCHAR(50),
INVOLVED_PARTY_TYPE_CD  VARCHAR(50) NOT NULL,
COUNTY_NM               VARCHAR(255),
COUNTRY_NM              VARCHAR(255),
UNION_COUNTRY_NM        VARCHAR(255),
TYPE_CODE               VARCHAR(50) NOT NULL,
BRANCH_NBR              VARCHAR(20) NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/") #SILVER PATH

# COMMAND ----------

TBL_NAME='ORGANIZATION' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ORGANIZATION as TGT USING TEMP_ORGANIZATION_SIL as SRC ON 
# MAGIC TGT.CITY_NM = SRC.CITYNAME AND
# MAGIC TGT.STATE_NM = SRC.STATENAME AND
# MAGIC TGT.DEALER_TAX_ID = SRC.TAXID AND
# MAGIC TGT.DEALER_NBR = SRC.CUSTOMER AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.CODE AND
# MAGIC TGT.COUNTY_NM = SRC.COUNTY_NM AND
# MAGIC TGT.COUNTRY_NM = SRC.COUNTRY_NAME AND
# MAGIC TGT.UNION_COUNTRY_NM = SRC.UNION_COUNTRY_NAME AND
# MAGIC TGT.BRANCH_NBR = SRC.BRANCH_NUMBER 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.DEALER_NM = SRC.NAME ,
# MAGIC TGT.INDUSTRY_GROUP_CODE = SRC.INDUSTRYGROUPCODE ,
# MAGIC TGT.TYPE_CODE = SRC.TYPECODE ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (CITY_NM,STATE_NM ,DEALER_TAX_ID,DEALER_NBR,DEALER_NM,INDUSTRY_GROUP_CODE,INVOLVED_PARTY_TYPE_CD,COUNTY_NM,COUNTRY_NM,
# MAGIC UNION_COUNTRY_NM,TYPE_CODE,BRANCH_NBR,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.CITYNAME,SRC.STATENAME,SRC.TAXID,SRC.CUSTOMER,NAME,
# MAGIC SRC.INDUSTRYGROUPCODE,SRC.CODE,SRC.COUNTY_NM,
# MAGIC SRC.COUNTRY_NAME,SRC.UNION_COUNTRY_NAME,SRC.TYPECODE,SRC.BRANCH_NUMBER,current_timestamp)

# COMMAND ----------

