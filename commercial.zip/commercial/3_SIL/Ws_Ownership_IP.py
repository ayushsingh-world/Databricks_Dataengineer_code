# Databricks notebook source
# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.WS_OWNERSHIP_INVOLVED_PARTY_ST

# COMMAND ----------

dbutils.fs.rm("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_OWNERSHIP_INVOLVED_PARTY_ST/",True)

# COMMAND ----------

from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-10'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_owner_ip_bt  where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format

# COMMAND ----------

df.withColumnRenamed("branch_number_owner","BRANCH_NUMBER_OWNER")\
  .withColumnRenamed("involved_party_type","INVOLVED_PARTY_TYPE")\
  .withColumnRenamed("client_id_owner","CLIENT_ID_OWNER")\
  .withColumnRenamed("branch_number_subject","BRANCH_NUMBER_SUBJECT")\
  .withColumnRenamed("involved_party_involved_party_type","INVOLVED_PARTY_INVOLVED_PARTY_TYPE")\
  .withColumnRenamed("involved_party_type_client","INVOLVED_PARTY_TYPE_SUB")\
  .withColumnRenamed("client_id_subject","CLIENT_ID_SUBJECT")\
  .withColumnRenamed("ownership_number","OWNERSHIP_NBR")\
  .withColumnRenamed("owner_pct","OWNERSHIP_PCT")\
  .withColumnRenamed("ownership_active_ind","OWNERSHIP_ACTIVE_IND")\
  .withColumnRenamed("group_cross_guarantee_ind","GROUP_CROSS_GUARANTEE_IND")\
  .withColumnRenamed("owner_pct","OWNER_PCT")\
  .withColumnRenamed("owner_is_guarantor","GUARANTEE_IND")

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType

# COMMAND ----------

df = df.withColumn("owner_is_guarantor", df["owner_is_guarantor"].cast(DecimalType(38, 0)))
df = df.withColumn("ownership_active_ind", df["ownership_active_ind"].cast(DecimalType(38, 0)))
df = df.withColumn("owner_pct", df["owner_pct"].cast(DecimalType(38, 0)))
df = df.withColumn("ownership_number", df["ownership_number"].cast(DecimalType(38, 0)))

# COMMAND ----------

df=df.withColumn("", when(df.branch_number_owner.isNull(),"NA") \
    .when(df.branch_number_owner=="","NA") \
    .otherwise(df.branch_number_owner))

# COMMAND ----------

df.createOrReplaceTempView("TEMP_OWNER_IP_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT = """
BRANCH_NUMBER DECIMAL,
BRANCH_NUMBER_SUBJECT DECIMAL,
CLIENT_ID_OWNER DECIMAL,
CLIENT_ID_SUBJECT DECIMAL,
GROUP_CROSS_GUARANTEE_IND DECIMAL,
INVOLVED_PARTY_INVOLVED_PARTY_TYPE VARCHAR(255),
INVOLVED_PARTY_TYPE VARCHAR(255) ,
INVOLVED_PARTY_TYPE_SUB VARCHAR(255),
GUARANTEE_IND DECIMAL,
OWNERSHIP_PCT DECIMAL(10,2),
OWNERSHIP_ACTIVE_IND DECIMAL,
OWNERSHIP_NBR DECIMAL,
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_OWNERSHIP_INVOLVED_PARTY_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_OWNERSHIP_INVOLVED_PARTY_ST AS TGT USING TEMP_OWNER_IP_SIL AS SRC ON
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER_OWNER AND
# MAGIC TGT.BRANCH_NUMBER_SUBJECT = SRC.BRANCH_NUMBER_SUBJECT AND
# MAGIC TGT.CLIENT_ID_OWNER = SRC.CLIENT_ID_OWNER AND
# MAGIC TGT.OWNERSHIP_NBR = SRC.OWNERSHIP_NUMBER
# MAGIC WHEN MATCHED THEN UPDATE SET    
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER_OWNER,
# MAGIC TGT.BRANCH_NUMBER_SUBJECT = SRC.BRANCH_NUMBER_SUBJECT,
# MAGIC TGT.CLIENT_ID_OWNER = SRC.CLIENT_ID_OWNER,
# MAGIC TGT.CLIENT_ID_SUBJECT = SRC.CLIENT_ID_SUBJECT,
# MAGIC TGT.GROUP_CROSS_GUARANTEE_IND = SRC.GROUP_CROSS_GUARANTEE_IND,
# MAGIC TGT.INVOLVED_PARTY_INVOLVED_PARTY_TYPE = SRC.INVOLVED_PARTY_INVOLVED_PARTY_TYPE,
# MAGIC TGT.INVOLVED_PARTY_TYPE = SRC.INVOLVED_PARTY_TYPE,
# MAGIC TGT.INVOLVED_PARTY_TYPE_SUB = SRC.INVOLVED_PARTY_TYPE_CLIENT,
# MAGIC TGT.GUARANTEE_IND = SRC.OWNER_IS_GUARANTOR,
# MAGIC TGT.OWNERSHIP_PCT = SRC.OWNER_PCT,
# MAGIC TGT.OWNERSHIP_ACTIVE_IND = SRC.OWNERSHIP_ACTIVE_IND,
# MAGIC TGT.OWNERSHIP_NBR = SRC.OWNERSHIP_NUMBER,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC WHEN NOT MATCHED  THEN INSERT
# MAGIC (TGT.BRANCH_NUMBER,TGT.BRANCH_NUMBER_SUBJECT,TGT.CLIENT_ID_OWNER,TGT.CLIENT_ID_SUBJECT,TGT.GROUP_CROSS_GUARANTEE_IND,
# MAGIC TGT.INVOLVED_PARTY_INVOLVED_PARTY_TYPE,TGT.INVOLVED_PARTY_TYPE,TGT.INVOLVED_PARTY_TYPE_SUB,TGT.GUARANTEE_IND,TGT.OWNERSHIP_PCT,TGT.OWNERSHIP_ACTIVE_IND,TGT.OWNERSHIP_NBR,TGT.INSERT_TIMSTM)
# MAGIC VALUES  
# MAGIC (SRC.BRANCH_NUMBER_OWNER,SRC.BRANCH_NUMBER_SUBJECT,SRC.CLIENT_ID_OWNER,SRC.CLIENT_ID_SUBJECT,SRC.GROUP_CROSS_GUARANTEE_IND,SRC.INVOLVED_PARTY_INVOLVED_PARTY_TYPE,SRC.INVOLVED_PARTY_TYPE,SRC.INVOLVED_PARTY_TYPE_CLIENT,SRC.OWNER_IS_GUARANTOR,SRC.OWNER_PCT,SRC.OWNERSHIP_ACTIVE_IND,SRC.OWNERSHIP_NUMBER,current_timestamp());