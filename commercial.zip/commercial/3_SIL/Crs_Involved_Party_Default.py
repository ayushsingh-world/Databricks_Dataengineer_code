# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.Crs_Involved_Party_Default_Extract_Bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df = df.withColumn("GSWID", trim(df.GSWID)) \
       .withColumn("BRANCHNUMBER", trim(df.BRANCHNUMBER)) \
       .withColumn("DEFAULTDATE", when(df.DEFAULTDATE.isNotNull() & (trim(df.DEFAULTDATE) != ''), df.DEFAULTDATE).otherwise("1900-01-01")) \
       .withColumn("DECLAREDDATE", when(df.DECLAREDDATE.isNotNull() & (trim(df.DECLAREDDATE) != ''), df.DECLAREDDATE).otherwise("1900-01-01")) \
       .withColumn("DISCOVEREDDATE", when(df.DISCOVEREDDATE.isNotNull() & (trim(df.DISCOVEREDDATE) != ''), df.DISCOVEREDDATE).otherwise("1900-01-01")) \
       .withColumn("RESOLVEDDATE", when(df.RESOLVEDDATE.isNotNull() & (trim(df.RESOLVEDDATE) != ''), df.RESOLVEDDATE).otherwise("1900-01-01")) \
       .withColumn("DEFAULTNOTICEDATE", when(df.DEFAULTNOTICEDATE.isNotNull() & (trim(df.DEFAULTNOTICEDATE) != ''), df.DEFAULTNOTICEDATE).otherwise("1900-01-01")) \
       .withColumn("DEFAULTID", trim(df.DEFAULTID))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TMP_CRS_INVOLVED_PARTY_DEFAULT_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
GSWID VARCHAR(255),
BRANCHNUMBER VARCHAR(255),
DEFAULTDATE Date,
DEFAULT_STATUS_CD VARCHAR(255),
DECLAREDATE Date,
DISCOVEREDDATE Date,
RESOLVEDDATE Date,
DEFAULTNOTICEDATE Date,
DEFAULTAMOUNT DECIMAL,
DEFAULTID VARCHAR(255),
INVOLVED_PARTY_TYPE_CD VARCHAR(255),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='CRS_INVOLVED_PARTY_DEFAULT_EXTRACT_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.CRS_INVOLVED_PARTY_DEFAULT_EXTRACT_ST AS TGT USING TMP_CRS_INVOLVED_PARTY_DEFAULT_SIL AS SRC ON
# MAGIC TGT.DEFAULT_STATUS_CD = SRC.DEFAULT_STATUS_CD AND
# MAGIC TGT.GSWID = SRC.GSWID AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.INVOLVED_PARTY_TYPE_CD AND
# MAGIC TGT.BRANCHNUMBER = SRC.BRANCHNUMBER
# MAGIC WHEN MATCHED THEN UPDATE SET    
# MAGIC TGT.GSWID = SRC.GSWID,
# MAGIC TGT.BRANCHNUMBER = SRC.BRANCHNUMBER,
# MAGIC TGT.DEFAULTDATE = SRC.DEFAULTDATE,
# MAGIC TGT.DEFAULT_STATUS_CD = SRC.DEFAULT_STATUS_CD,
# MAGIC TGT.DECLAREDATE = SRC.DECLAREDDATE,
# MAGIC TGT.DISCOVEREDDATE = SRC.DISCOVEREDDATE,
# MAGIC TGT.RESOLVEDDATE = SRC.RESOLVEDDATE,
# MAGIC TGT.DEFAULTNOTICEDATE = SRC.DEFAULTNOTICEDATE,
# MAGIC TGT.DEFAULTAMOUNT = SRC.DEFAULTAMOUNT,
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.INVOLVED_PARTY_TYPE_CD,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED  THEN INSERT
# MAGIC (TGT.GSWID,TGT.BRANCHNUMBER,TGT.DEFAULTDATE,TGT.DEFAULT_STATUS_CD,TGT.DECLAREDATE,
# MAGIC TGT.DISCOVEREDDATE,TGT.RESOLVEDDATE,TGT.DEFAULTNOTICEDATE,TGT.DEFAULTAMOUNT,TGT.INVOLVED_PARTY_TYPE_CD,TGT.INSERT_TIMSTM)
# MAGIC VALUES  
# MAGIC (SRC.GSWID,SRC.BRANCHNUMBER,SRC.DEFAULTDATE,SRC.DEFAULT_STATUS_CD,SRC.DECLAREDDATE,SRC.DISCOVEREDDATE,SRC.RESOLVEDDATE,SRC.DEFAULTNOTICEDATE,SRC.DEFAULTAMOUNT,SRC.INVOLVED_PARTY_TYPE_CD,current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.crs_involved_party_default_extract_st;