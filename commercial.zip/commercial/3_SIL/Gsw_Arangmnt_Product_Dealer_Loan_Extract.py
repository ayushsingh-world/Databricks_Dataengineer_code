# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_ARANGMNT_PRODUCT_DEALER_LOAN_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_PRODUCT_DEALER_LOAN_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ACC_NO VARCHAR(20) NOT NULL,
VERSION_NUMBER DECIMAL(38,0) NOT NULL,
PRODUCT_PLAN_CD VARCHAR(50) NOT NULL,
BRN_ID_NO VARCHAR(20) NOT NULL,
PRODUCT_PLAN_TYPE_CD VARCHAR(20) NOT NULL,
INSERT_TIMSTM                 TIMESTAMP,
UPDATE_TIMSTM                 TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARANGMNT_PRODUCT_DEALER_LOAN_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into itda_io_dev.io_cml_brz.ARANGMNT_PRODUCT_DEALER_LOAN_ST as TGT
# MAGIC using TEMP_ARANGMNT_PRODUCT_DEALER_LOAN_SIL as SRC
# MAGIC on 
# MAGIC TGT.ACC_NO = SRC.ACC_NO AND
# MAGIC TGT.BRN_ID_NO = SRC.BRN_ID_NO
# MAGIC when matched then update set 
# MAGIC TGT.VERSION_NUMBER = SRC.VERSION_NUMBER,
# MAGIC TGT.PRODUCT_PLAN_CD = SRC.PRODUCT_PLAN_CD,
# MAGIC TGT.PRODUCT_PLAN_TYPE_CD = SRC.PRODUCT_PLAN_TYPE_CD,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC when not matched then insert 
# MAGIC  (ACC_NO,VERSION_NUMBER ,PRODUCT_PLAN_CD,BRN_ID_NO,PRODUCT_PLAN_TYPE_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.ACC_NO,SRC.VERSION_NUMBER,SRC.PRODUCT_PLAN_CD,SRC.BRN_ID_NO,SRC.PRODUCT_PLAN_TYPE_CD,current_timestamp())