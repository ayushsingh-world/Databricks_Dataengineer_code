# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_arangmnt_resource_item_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
  df= df.withColumn(colname, trim(colname))	
    

# COMMAND ----------

from pyspark.sql.functions import when
df=df.withColumn("Paid_In_Full_Date", when(df.Paid_In_Full_Date.isNull(),"1900-01-01") \
    .when(df.Paid_In_Full_Date=="","1900-01-01") \
    .otherwise(df.Paid_In_Full_Date))
df=df.withColumn("MNR_CD", when(df.MNR_CD.isNull(),"NA") \
    .when(df.MNR_CD=="","NA") \
    .otherwise(df.MNR_CD))
df=df.withColumn("RELEASE_DT", when(df.RELEASE_DT.isNull(),"1900-01-01") \
    .when(df.RELEASE_DT=="","1900-01-01") \
    .otherwise(df.RELEASE_DT))
df=df.withColumn("NEW_FLAG", when(df.NEW_FLAG.isNull(),"NA") \
    .when(df.NEW_FLAG=="","NA") \
    .otherwise(df.NEW_FLAG))
df=df.withColumn("ARANGMNT_TERM ", when(df.ARANGMNT_TERM .isNull(),"NA") \
    .when(df.ARANGMNT_TERM =="","NA") \
    .otherwise(df.ARANGMNT_TERM))
df=df.withColumn("Maturity_Dt", when(df.Maturity_Dt.isNull(),"1900-01-01") \
    .when(df.Maturity_Dt=="","1900-01-01") \
    .otherwise(df.Maturity_Dt))
df=df.withColumn("ORIG_MATURITY_DT", when(df.ORIG_MATURITY_DT.isNull(),"1900-01-01") \
    .when(df.ORIG_MATURITY_DT=="","1900-01-01") \
    .otherwise(df.ORIG_MATURITY_DT))
df=df.withColumn("SOLD_DT", when(df.SOLD_DT.isNull(),"1900-01-01") \
    .when(df.SOLD_DT=="","1900-01-01") \
    .otherwise(df.SOLD_DT))
df=df.withColumn("GL_DT", when(df.GL_DT.isNull(),"1900-01-01") \
    .when(df.GL_DT=="","1900-01-01") \
    .otherwise(df.GL_DT))
df=df.withColumn("SUPPORT_END_DT", when(df.SUPPORT_END_DT.isNull(),"1900-01-01") \
    .when(df.SUPPORT_END_DT=="","1900-01-01") \
    .otherwise(df.SUPPORT_END_DT))
df=df.withColumn("ORIG_SUPPORT_END_DT", when(df.ORIG_SUPPORT_END_DT.isNull(),"1900-01-01") \
    .when(df.ORIG_SUPPORT_END_DT=="","1900-01-01") \
    .otherwise(df.ORIG_SUPPORT_END_DT))
df=df.withColumn("SECURITIZATION_POOL_NBR", when(df.SECURITIZATION_POOL_NBR.isNull(),"NA") \
    .when(df.SECURITIZATION_POOL_NBR=="","NA") \
    .otherwise(df.SECURITIZATION_POOL_NBR))
df=df.withColumn("SECURITIZATION_DT", when(df.SECURITIZATION_DT.isNull(),"1900-01-01") \
    .when(df.SECURITIZATION_DT=="","1900-01-01") \
    .otherwise(df.SECURITIZATION_DT))
df=df.withColumn("GUARANTEE_SUPPORT_END_DT", when(df.GUARANTEE_SUPPORT_END_DT.isNull(),"1900-01-01") \
    .when(df.GUARANTEE_SUPPORT_END_DT=="","1900-01-01") \
    .otherwise(df.GUARANTEE_SUPPORT_END_DT))
df=df.withColumn("Insurance_Start_Date", when(df.Insurance_Start_Date.isNull(),"1900-01-01") \
    .when(df.Insurance_Start_Date=="","NA") \
    .otherwise(df.Insurance_Start_Date))
df=df.withColumn("INTEREST_START_DT", when(df.INTEREST_START_DT.isNull(),"NA") \
    .when(df.INTEREST_START_DT=="","1900-01-01") \
    .otherwise(df.INTEREST_START_DT))
df=df.withColumn("MIDI_CD", when(df.MIDI_CD.isNull(),"NA") \
    .when(df.MIDI_CD=="","NA") \
    .otherwise(df.MIDI_CD))
df=df.withColumn("FACTORY_ORDER_NBR", when(df.FACTORY_ORDER_NBR.isNull(),"NA") \
    .when(df.FACTORY_ORDER_NBR=="","NA") \
    .otherwise(df.FACTORY_ORDER_NBR))
df=df.withColumn("COMMENT_TXT", when(df.COMMENT_TXT.isNull(),"NA") \
    .when(df.COMMENT_TXT=="","NA") \
    .otherwise(df.COMMENT_TXT))
df=df.withColumn("COLLATERAL_RELEASE_DT", when(df.COLLATERAL_RELEASE_DT.isNull(),"1900-01-01") \
    .when(df.COLLATERAL_RELEASE_DT=="","1900-01-01") \
    .otherwise(df.COLLATERAL_RELEASE_DT))

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format
df = df.withColumn("Paid_In_Full_Date", to_timestamp(col("Paid_In_Full_Date"),"yyyy-MM-dd")) \
       .withColumn("RELEASE_DT",to_date(col("RELEASE_DT"),"yyyy-MM-dd")) \
       .withColumn("Maturity_Dt",to_date(col("Maturity_Dt"),"yyyy-MM-dd")) \
       .withColumn("ORIG_MATURITY_DT",to_date(col("ORIG_MATURITY_DT"),"yyyy-MM-dd")) \
       .withColumn("SOLD_DT",to_timestamp(col("SOLD_DT"),"yyyy-MM-dd")) \
       .withColumn("GL_DT",to_timestamp(col("GL_DT"),"yyyy-MM-dd")) \
       .withColumn("SUPPORT_END_DT",to_date(col("SUPPORT_END_DT"),"yyyy-MM-dd")) \
       .withColumn("ORIG_SUPPORT_END_DT",to_date(col("ORIG_SUPPORT_END_DT"),"yyyy-MM-dd")) \
       .withColumn("SECURITIZATION_DT",to_date(col("SECURITIZATION_DT"),"yyyy-MM-dd")) \
       .withColumn("GUARANTEE_SUPPORT_END_DT",to_date(col("GUARANTEE_SUPPORT_END_DT"),"yyyy-MM-dd")) \
       .withColumn("Insurance_Start_Date",to_date(col("Insurance_Start_Date"),"yyyy-MM-dd")) \
       .withColumn("INTEREST_START_DT",to_date(col("INTEREST_START_DT"),"yyyy-MM-dd")) \
       .withColumn("COLLATERAL_RELEASE_DT",to_date(col("COLLATERAL_RELEASE_DT"),"yyyy-MM-dd"))

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType
from pyspark.sql.types import IntegerType


# COMMAND ----------

df = df.withColumn("VERSION_NUMBER", df["VERSION_NUMBER"].cast(DecimalType(38,2))) \
        .withColumn("NEW_FLAG", df["NEW_FLAG"].cast(DecimalType(38,2))) \
        .withColumn("ARANGMNT_TERM", df["ARANGMNT_TERM"].cast(DecimalType(38,2))) \
        .withColumn("MILEAGE_AMT", df["MILEAGE_AMT"].cast(DecimalType(38,2))) \
        .withColumn("MATURITY_DT_EXT_CNT", df["MATURITY_DT_EXT_CNT"].cast(DecimalType(38,2))) \
        .withColumn("SECURITIZATION_POOL_NBR", df["SECURITIZATION_POOL_NBR"].cast(DecimalType(38,2)))

# COMMAND ----------

df.withColumn("SLIM_IND",df.SLIM_IND.cast(IntegerType())) \
    .withColumn("SECURITIZED_IND",df.SECURITIZED_IND.cast(IntegerType())) \
        .withColumn("SECURITIZED_RETURN_IND",df.SECURITIZED_RETURN_IND.cast(IntegerType()))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_RESOURCE_ITEM_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
PRODUCT_PLAN_CODE VARCHAR(20) NOT NULL,
VEHICLE_TYPE_CD VARCHAR(50) NOT NULL,
DEALER_NBR VARCHAR(20) NOT NULL,
MNR_CD VARCHAR(20),
DLR_TP_CD VARCHAR(50) NOT NULL,
MFG_TP_CD VARCHAR(50) NOT NULL,
VERSION_NUMBER DECIMAL(38) NOT NULL,
PRODUCT_PLAN_TYPE_CD VARCHAR(20) NOT NULL,
VIN VARCHAR(20) NOT NULL,
BRANCH_NBR VARCHAR(20) NOT NULL,
ARANGMNT_RESOURCE_ITEM_TYPE_CD VARCHAR(50) NOT NULL,
PAID_IN_FULL_DATE TIMESTAMP,
RELEASE_DT DATE,
NEW_FLAG DECIMAL(38) NOT NULL,
ARANGMNT_TERM DECIMAL(38),
MATURITY_DT DATE,
ORIG_MATURITY_DT DATE,
SOLD_DT TIMESTAMP,
MILEAGE_AMT DECIMAL(38),
GL_DT DATE,
SUPPORT_END_DT DATE,
MATURITY_DT_EXT_CNT DECIMAL(38),
ORIG_SUPPORT_END_DT DATE,
SECURITIZATION_POOL_NBR DECIMAL(38),
SECURITIZATION_DT DATE,
GUARANTEE_SUPPORT_END_DT DATE,
INSURANCE_START_DATE DATE,
INTEREST_START_DT DATE,
TITLE_DOCUMENT_LOC_CD VARCHAR(50),
VIPS_NBR VARCHAR(50),
VIN_REFERENCE_NBR VARCHAR(50),
MIDI_CD VARCHAR(50),
FACTORY_ORDER_NBR VARCHAR(50),
COMMENT_TXT VARCHAR(255),
COLLATERAL_RELEASE_DT DATE,
SLIM_IND INT,
SUPPLIER_PLANT_CD VARCHAR(20) NOT NULL,
SECURITIZED_IND INT NOT NULL,
SECURITIZED_RETURN_IND INT NOT NULL,
SNAPSHOT_DT DATE,
INSERT_TIMSTM              TIMESTAMP,
UPDATE_TIMSTM              TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARANGMNT_RESOURCE_ITEM_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ARANGMNT_RESOURCE_ITEM_ST as TGT USING TEMP_ARANGMNT_RESOURCE_ITEM_SIL as SRC ON 
# MAGIC TGT.DEALER_NBR = SRC.Dealer_Number AND
# MAGIC TGT.MNR_CD = SRC.MNR_CD AND
# MAGIC TGT.BRANCH_NBR = SRC.Branch_Number AND
# MAGIC TGT.DLR_TP_CD = SRC.DLR_TP_CD AND
# MAGIC TGT.MFG_TP_CD = SRC.MFG_TP_CD AND
# MAGIC TGT.PRODUCT_PLAN_CODE = SRC.Product_Plan_Code AND
# MAGIC TGT.PRODUCT_PLAN_TYPE_CD = SRC.PRODUCT_PLAN_TYPE_CD AND
# MAGIC TGT.VERSION_NUMBER = SRC.VERSION_NUMBER AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD AND
# MAGIC TGT.VEHICLE_TYPE_CD=SRC.VEHICLE_TYPE_CD AND
# MAGIC TGT.DLR_TP_CD=SRC.DLR_TP_CD AND
# MAGIC TGT.VIN=SRC.VIN
# MAGIC WHEN MATCHED THEN UPDATE SET   
# MAGIC TGT.ARANGMNT_RESOURCE_ITEM_TYPE_CD=SRC.ARANGMNT_RESOURCE_ITEM_TYPE_CD,
# MAGIC TGT.PAID_IN_FULL_DATE = SRC.Paid_In_Full_Date ,
# MAGIC TGT.RELEASE_DT = SRC.RELEASE_DT ,
# MAGIC TGT.NEW_FLAG = SRC.NEW_FLAG ,
# MAGIC TGT.ARANGMNT_TERM = SRC.ARANGMNT_TERM ,
# MAGIC TGT.MATURITY_DT = SRC.Maturity_Dt ,
# MAGIC TGT.ORIG_MATURITY_DT = SRC.ORIG_MATURITY_DT ,
# MAGIC TGT.SOLD_DT = SRC.SOLD_DT ,
# MAGIC TGT.MILEAGE_AMT = SRC.MILEAGE_AMT ,
# MAGIC TGT.GL_DT = SRC.GL_DT ,
# MAGIC TGT.SUPPORT_END_DT = SRC.SUPPORT_END_DT ,
# MAGIC TGT.MATURITY_DT_EXT_CNT = SRC.MATURITY_DT_EXT_CNT ,
# MAGIC TGT.ORIG_SUPPORT_END_DT = SRC.ORIG_SUPPORT_END_DT ,
# MAGIC TGT.SECURITIZATION_POOL_NBR = SRC.SECURITIZATION_POOL_NBR ,
# MAGIC TGT.SECURITIZATION_DT = SRC.SECURITIZATION_DT ,
# MAGIC TGT.GUARANTEE_SUPPORT_END_DT = SRC.GUARANTEE_SUPPORT_END_DT ,
# MAGIC TGT.INSURANCE_START_DATE = SRC.Insurance_Start_Date ,
# MAGIC TGT.INTEREST_START_DT = SRC.INTEREST_START_DT ,
# MAGIC TGT.TITLE_DOCUMENT_LOC_CD = SRC.TITLE_DOCUMENT_LOC_CD ,
# MAGIC TGT.VIPS_NBR = SRC.VIPS_NBR ,
# MAGIC TGT.VIN_REFERENCE_NBR = SRC.VIN_REFERENCE_NBR ,
# MAGIC TGT.MIDI_CD = SRC.MIDI_CD ,
# MAGIC TGT.FACTORY_ORDER_NBR = SRC.FACTORY_ORDER_NBR ,
# MAGIC TGT.COMMENT_TXT = SRC.COMMENT_TXT ,
# MAGIC TGT.COLLATERAL_RELEASE_DT = SRC.COLLATERAL_RELEASE_DT ,
# MAGIC TGT.SNAPSHOT_DT = SRC.file_date,
# MAGIC TGT.SLIM_IND = SRC.SLIM_IND ,
# MAGIC TGT.SECURITIZED_IND = SRC.SECURITIZED_IND ,
# MAGIC TGT.SECURITIZED_RETURN_IND = SRC.SECURITIZED_RETURN_IND ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC (PRODUCT_PLAN_CODE,VEHICLE_TYPE_CD,DEALER_NBR,MNR_CD,DLR_TP_CD,MFG_TP_CD,VERSION_NUMBER,PRODUCT_PLAN_TYPE_CD,VIN,BRANCH_NBR,ARANGMNT_RESOURCE_ITEM_TYPE_CD,PAID_IN_FULL_DATE,RELEASE_DT,NEW_FLAG,ARANGMNT_TERM,MATURITY_DT,ORIG_MATURITY_DT,SOLD_DT,MILEAGE_AMT,GL_DT,SUPPORT_END_DT,MATURITY_DT_EXT_CNT,ORIG_SUPPORT_END_DT,SECURITIZATION_POOL_NBR,SECURITIZATION_DT,GUARANTEE_SUPPORT_END_DT,INSURANCE_START_DATE,INTEREST_START_DT,TITLE_DOCUMENT_LOC_CD,VIPS_NBR,VIN_REFERENCE_NBR,MIDI_CD,FACTORY_ORDER_NBR,COMMENT_TXT,COLLATERAL_RELEASE_DT,SLIM_IND,SUPPLIER_PLANT_CD,SECURITIZED_IND,SECURITIZED_RETURN_IND,SNAPSHOT_DT,INSERT_TIMSTM) 
# MAGIC VALUES  
# MAGIC (SRC.Product_Plan_Code,SRC.Vehicle_Type_Cd,SRC.Dealer_Number,SRC.MNR_CD,SRC.DLR_TP_CD,SRC.MFG_TP_CD,SRC.VERSION_NUMBER,SRC.PRODUCT_PLAN_TYPE_CD,SRC.Vin,SRC.Branch_Number,SRC.ARANGMNT_RESOURCE_ITEM_TYPE_CD,SRC.Paid_In_Full_Date,SRC.RELEASE_DT,SRC.NEW_FLAG,SRC.ARANGMNT_TERM,SRC.Maturity_Dt,SRC.ORIG_MATURITY_DT,SRC.SOLD_DT,SRC.MILEAGE_AMT,SRC.GL_DT,SRC.SUPPORT_END_DT,SRC.MATURITY_DT_EXT_CNT,SRC.ORIG_SUPPORT_END_DT,SRC.SECURITIZATION_POOL_NBR,SRC.SECURITIZATION_DT,SRC.GUARANTEE_SUPPORT_END_DT,SRC.Insurance_Start_Date,SRC.INTEREST_START_DT,SRC.TITLE_DOCUMENT_LOC_CD,SRC.VIPS_NBR,SRC.VIN_REFERENCE_NBR,SRC.MIDI_CD,SRC.FACTORY_ORDER_NBR,SRC.COMMENT_TXT,SRC.COLLATERAL_RELEASE_DT,SRC.SLIM_IND,SRC.SUPPLIER_PLANT_CD,SRC.SECURITIZED_IND,SRC.SECURITIZED_RETURN_IND,SRC.file_date,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ARANGMNT_RESOURCE_ITEM_ST ;
# MAGIC