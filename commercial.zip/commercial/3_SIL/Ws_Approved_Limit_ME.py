# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_approved_limit_me_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when,expr
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.createOrReplaceTempView("TEMP_Approved_Limit_ME")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRANCHNUMBER   VARCHAR(50),
GSWID           VARCHAR(50),
REPORTPERIODID      VARCHAR(255),
CREDITSTATEID        VARCHAR(255),
CREDITSTATEDESC       VARCHAR(255),
CREDITLINETYPEID        VARCHAR(255),
CREDITLINETYPECD         VARCHAR(255),
CREDITLINETYPEDESC      VARCHAR(255),
LIMIT_AMT              VARCHAR(50),
LIMIT_UNIT_AMT      VARCHAR(50),
START_DT        VARCHAR(10),
END_DT         VARCHAR(10),
LIMITCOMMENT        VARCHAR(400),
USERNAME         VARCHAR(255),
ISDELETED_IND       VARCHAR(255),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ws_approved_limit_me_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_approved_limit_me_st AS TGT
# MAGIC USING TEMP_Approved_Limit_ME AS SRC
# MAGIC ON 
# MAGIC   TGT.BRANCHNUMBER = SRC.branchnumber AND
# MAGIC   TGT.GSWID = SRC.ccid AND
# MAGIC   TGT.REPORTPERIODID = SRC.reportperiodid AND
# MAGIC   TGT.CREDITSTATEID = SRC.creditstateid AND
# MAGIC   TGT.CREDITSTATEDESC = SRC.creditstatedesc AND
# MAGIC     TGT.CREDITLINETYPEID = SRC.creditlinetypeid AND
# MAGIC     TGT.CREDITLINETYPECD = SRC.creditlinetypecd AND
# MAGIC 	  TGT.CREDITLINETYPEDESC = SRC.creditlinetypedesc AND
# MAGIC 	    TGT.LIMIT_AMT = SRC.limit_amt AND
# MAGIC 	    TGT.LIMIT_UNIT_AMT = SRC.limit_unit_amt AND
# MAGIC 		TGT.START_DT = SRC.start_dt AND
# MAGIC 		TGT.END_DT = SRC.end_dt AND
# MAGIC 		TGT.LIMITCOMMENT = SRC.limitcomment AND
# MAGIC 		TGT.USERNAME = SRC.username AND
# MAGIC 		TGT.ISDELETED_IND = SRC.isdeleted_ind
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC    TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (BRANCHNUMBER, GSWID, REPORTPERIODID, CREDITSTATEID, CREDITSTATEDESC, CREDITLINETYPEID, CREDITLINETYPECD, CREDITLINETYPEDESC, LIMIT_AMT, LIMIT_UNIT_AMT, START_DT, END_DT, LIMITCOMMENT, USERNAME, ISDELETED_IND, INSERT_TIMSTM)
# MAGIC   VALUES (SRC.branchnumber, SRC.ccid, SRC.reportperiodid, SRC.creditstateid, SRC.creditstatedesc, SRC.creditlinetypeid, SRC.creditlinetypecd, SRC.creditlinetypedesc, SRC.limit_amt, SRC.limit_unit_amt,
# MAGIC SRC.start_dt, SRC.end_dt, SRC.limitcomment, SRC.username, SRC.isdeleted_ind, current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_approved_limit_me_bt;