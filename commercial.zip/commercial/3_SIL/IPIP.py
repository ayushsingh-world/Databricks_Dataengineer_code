# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-07-02'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Involved_Party_Inv_Party_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.createOrReplaceTempView("TMP_Involved_Party_Inv_Party_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
InvolvedParty                  VARCHAR(255),
RelatedInvolvedParty            VARCHAR(255),
Code                              VARCHAR(50),
RelatedInvolvedPartyCode          VARCHAR(50),
TypeCode                          VARCHAR(50),
IP_Branch_Number                   VARCHAR(20),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP

"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_Involved_Party_Inv_Party_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_Involved_Party_Inv_Party_ST AS TGT
# MAGIC USING TMP_Involved_Party_Inv_Party_SIL AS SRC
# MAGIC ON 
# MAGIC TGT.InvolvedParty   =   SRC.dealer_involved_party_number  AND
# MAGIC TGT.RelatedInvolvedParty      =     SRC.group_involved_party_number   AND
# MAGIC TGT.Code                      =     SRC.dealer_involved_party_type_cd   AND
# MAGIC TGT.RelatedInvolvedPartyCode    =      SRC.group_involved_party_type_cd   AND
# MAGIC TGT.TypeCode                    =         SRC.typecode         AND
# MAGIC TGT.IP_Branch_Number            =        SRC.involved_party_branch_number   
# MAGIC
# MAGIC 	   WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC    TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (InvolvedParty, RelatedInvolvedParty, Code, RelatedInvolvedPartyCode, TypeCode, IP_Branch_Number, INSERT_TIMSTM
# MAGIC )
# MAGIC   VALUES (SRC.dealer_involved_party_number, SRC.group_involved_party_number, SRC.dealer_involved_party_type_cd, SRC.group_involved_party_type_cd, SRC.typecode, SRC.involved_party_branch_number, SRC.involved_party_branch_number, current_timestamp());