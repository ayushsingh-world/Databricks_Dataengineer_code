# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_resource_item_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 	
 
string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
  df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_RESOURCE_ITEM_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
RESOURCE_ITEM_DESC			VARCHAR	(50),
MSRP_AMT					DECIMAL	(38, 2),
MODEL_YEAR					DECIMAL	(38),
VIN							VARCHAR	(20),
MODEL_CD					VARCHAR	(255),
ORGANIZATION_UNIT_NBR		VARCHAR	(20),
MAKE_CD						VARCHAR	(50),
INVOLVED_PARTY_NM			VARCHAR	(255),
RESOURCE_ITEM_TYPE_CD		VARCHAR	(255),
INVOLVED_PARTY_TYPE_CD		VARCHAR	(50),
VEHICLE_TYPE_CD				VARCHAR	(255),
VEHICLE_REGISTRATION_NBR	VARCHAR	(50),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='resource_item_st' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.resource_item_st as TGT USING TEMP_RESOURCE_ITEM_SIL as SRC ON 
# MAGIC TGT.RESOURCE_ITEM_TYPE_CD = SRC.RESOURCE_ITEM_TYPE_CD AND
# MAGIC TGT.VEHICLE_TYPE_CD = SRC.VEHICLE_TYPE_CD AND
# MAGIC TGT.MODEL_CD = SRC.MODELCODE AND
# MAGIC TGT.VIN = SRC.VIN AND
# MAGIC TGT.ORGANIZATION_UNIT_NBR=SRC.LOANOFFICEBRANCHNUMBER AND
# MAGIC TGT.MAKE_CD=SRC.MAKECODE AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD=SRC.TYPE_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.RESOURCE_ITEM_DESC = SRC.DESCRIPTION,
# MAGIC TGT.MSRP_AMT = SRC.MSRP,
# MAGIC TGT.MODEL_YEAR = SRC.MODELYEAR,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (RESOURCE_ITEM_DESC,MSRP_AMT,MODEL_YEAR,VIN,MODEL_CD,ORGANIZATION_UNIT_NBR,MAKE_CD,INVOLVED_PARTY_NM,RESOURCE_ITEM_TYPE_CD,INVOLVED_PARTY_TYPE_CD,VEHICLE_TYPE_CD,VEHICLE_REGISTRATION_NBR,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.DESCRIPTION,SRC.MSRP,SRC.MODELYEAR,SRC.VIN,SRC.MODELCODE,SRC.LOANOFFICEBRANCHNUMBER,SRC.MAKECODE,SRC.MANUFACTURERNAME,SRC.RESOURCE_ITEM_TYPE_CD,SRC.TYPE_CD,SRC.VEHICLE_TYPE_CD,SRC.VEHICLE_REGISTRATION_NBR,current_timestamp())

# COMMAND ----------

