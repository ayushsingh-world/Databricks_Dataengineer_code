# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_process_calendar_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_PROCESS_CALENDAR_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
SNAPSHOT_DT             VARCHAR(10) NOT NULL,
MONTHEND_GL_DT          VARCHAR(10) NOT NULL,
BRANCH_GROUP_CODE       VARCHAR(255) NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='PROCESS_CALENDAR_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.PROCESS_CALENDAR_ST as TGT USING TEMP_PROCESS_CALENDAR_SIL as SRC ON 
# MAGIC TGT.BRANCH_GROUP_CODE = SRC.BRANCH_GROUP_CODE 
# MAGIC WHEN MATCHED THEN  UPDATE SET  
# MAGIC TGT.SNAPSHOT_DT = SRC.SNAPSHOT_DT AND
# MAGIC TGT.MONTHEND_GL_DT = SRC.MONTHEND_GL_DT AND 
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (SNAPSHOT_DT,MONTHEND_GL_DT,BRANCH_GROUP_CODE,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.SNAPSHOT_DT,SRC.MONTHEND_GL_DT,SRC.BRANCH_GROUP_CODE,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.process_calendar_st;