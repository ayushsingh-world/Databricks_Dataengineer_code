# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_credit_facility_arangmnt_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
    df= df.withColumn(colname, trim(colname))


# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_CREDIT_FACILITY_ARANGMNT_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
DLR_ID                          VARCHAR(50),
MNR_CD                          VARCHAR(50),
SOURCE_SYSTEM_REFERENCE_ID      VARCHAR(255),
DLR_TYPE_CD                     VARCHAR(10),
MFG_TYPE_CD                     VARCHAR(10),
PRODUCT_PLAN_CD                 VARCHAR(20),
ARANGMNT_TYPE_CD                VARCHAR(50),
ARANGMNT_STATUS_CD              VARCHAR(50),
ARANGMNT_CATEGORY_TYPE_CD       VARCHAR(50),
PAYMENT_METHOD_CD               VARCHAR(255),
LOAN_ADVANCE_METHOD_CD          VARCHAR(255),
INTEREST_PAYMENT_METHOD_CD      VARCHAR(255),
BROKEN_PROMISE_CNT              VARCHAR(38),
START_DT                        VARCHAR(10),
STOP_ACCRUAL_DT                 VARCHAR(10),
ARANGMNT_LIFE_CYCLE_STATUS_DT   VARCHAR(10),
BRANCH_NUMBER                   VARCHAR(20),
Version_Number                  DECIMAL(38,0),
Plan_Type_Code                  VARCHAR(20),
CR_LN_NO                        VARCHAR(50),
SUPPLIER_PLANT_CD               VARCHAR(20),
INSERT_TIMSTM                   TIMESTAMP,
UPDATE_TIMSTM                   TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='credit_facility_arangmnt_st' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.credit_facility_arangmnt_st as TGT USING TEMP_CREDIT_FACILITY_ARANGMNT_SIL as SRC ON 
# MAGIC TGT.DLR_ID = SRC.DLR_ID AND
# MAGIC TGT.DLR_TYPE_CD = SRC.DLR_TYPE_CD AND
# MAGIC TGT.MNR_CD = SRC.MNR_CD AND
# MAGIC TGT.MFG_TYPE_CD = SRC.MFG_TYPE_CD AND
# MAGIC TGT.PRODUCT_PLAN_CD = SRC.PRODUCT_PLAN_CD AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER AND
# MAGIC TGT.Plan_Type_Code = SRC.Plan_Type_Code AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD 
# MAGIC WHEN MATCHED THEN  UPDATE SET  
# MAGIC TGT.ARANGMNT_TYPE_CD = SRC.ARANGMNT_TYPE_CD,
# MAGIC TGT.ARANGMNT_STATUS_CD = SRC.ARANGMNT_STATUS_CD,
# MAGIC TGT.ARANGMNT_CATEGORY_TYPE_CD = SRC.ARANGMNT_CATEGORY_TYPE_CD,
# MAGIC TGT.PAYMENT_METHOD_CD = SRC.PAYMENT_METHOD_CD,
# MAGIC TGT.LOAN_ADVANCE_METHOD_CD = SRC.LOAN_ADVANCE_METHOD_CD,
# MAGIC TGT.INTEREST_PAYMENT_METHOD_CD = SRC.INTEREST_PAYMENT_METHOD_CD,
# MAGIC TGT.Version_Number = SRC.Version_Number,
# MAGIC TGT.CR_LN_NO = SRC.CR_LN_NO,
# MAGIC TGT.SOURCE_SYSTEM_REFERENCE_ID = SRC.SOURCE_SYSTEM_REFERENCE_ID ,
# MAGIC TGT.BROKEN_PROMISE_CNT = SRC.BROKEN_PROMISE_CNT ,
# MAGIC TGT.START_DT = SRC.START_DT ,
# MAGIC TGT.STOP_ACCRUAL_DT = SRC.STOP_ACCRUAL_DT ,
# MAGIC TGT.ARANGMNT_LIFE_CYCLE_STATUS_DT = SRC.ARANGMNT_LIFE_CYCLE_STATUS_DT ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (DLR_ID,MNR_CD,SOURCE_SYSTEM_REFERENCE_ID,DLR_TYPE_CD,MFG_TYPE_CD,PRODUCT_PLAN_CD,ARANGMNT_TYPE_CD,ARANGMNT_STATUS_CD,ARANGMNT_CATEGORY_TYPE_CD,PAYMENT_METHOD_CD,LOAN_ADVANCE_METHOD_CD,INTEREST_PAYMENT_METHOD_CD,BROKEN_PROMISE_CNT,START_DT,STOP_ACCRUAL_DT,ARANGMNT_LIFE_CYCLE_STATUS_DT,BRANCH_NUMBER,Version_Number,Plan_Type_Code,CR_LN_NO,SUPPLIER_PLANT_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.DLR_ID,SRC.MNR_CD,SRC.SOURCE_SYSTEM_REFERENCE_ID,SRC.DLR_TYPE_CD,SRC.MFG_TYPE_CD,SRC.PRODUCT_PLAN_CD,SRC.ARANGMNT_TYPE_CD,SRC.ARANGMNT_STATUS_CD,SRC.ARANGMNT_CATEGORY_TYPE_CD,SRC.PAYMENT_METHOD_CD,SRC.LOAN_ADVANCE_METHOD_CD,SRC.INTEREST_PAYMENT_METHOD_CD,SRC.BROKEN_PROMISE_CNT,SRC.START_DT,SRC.STOP_ACCRUAL_DT,SRC.ARANGMNT_LIFE_CYCLE_STATUS_DT,SRC.BRANCH_NUMBER,SRC.Version_Number,SRC.Plan_Type_Code,SRC.CR_LN_NO,SRC.SUPPLIER_PLANT_CD,current_timestamp())

# COMMAND ----------

