# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_INVOLVED_PARTY_RISK_RATING_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("RATING_TP_CD", when((df.RATING_TP_CD=="RRR-GSW") & ((df.RATINGVALUE=="L")|(df.RATINGVALUE=="S")|(df.RATINGVALUE=="P")),"DCC").otherwise(df.RATING_TP_CD))
df=df.withColumn("RATINGVALUE", when(df.RATINGVALUE=="NA","NR").otherwise(df.RATINGVALUE))
df=df.withColumn("CREATEDATE", when(df.CREATEDATE.isNull(),"NA") \
    .when(df.CREATEDATE=="","NA") \
    .otherwise(df.CREATEDATE))

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format
df = df.withColumn("CREATEDATE",to_date(col("CREATEDATE"),"yyyy-MM-dd"))

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType
from pyspark.sql.types import IntegerType

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL;

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
RATING_TP_CD              VARCHAR(50),
RATINGVALUE					      VARCHAR(50),
GSWID							  VARCHAR(50),
BRANCHNUMBER					  VARCHAR(50),
CREATEDATE						  DATE,
INVOLVED_PARTY_TYPE_CD			  VARCHAR(50),
INSERT_TIMSTM                     TIMESTAMP,
UPDATE_TIMSTM                     TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='INVOLVED_PARTY_RISK_RATING_EXTRACT_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.INVOLVED_PARTY_RISK_RATING_EXTRACT_ST USING TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL ON 
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.RATING_TP_CD = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.RATING_TP_CD AND
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.RATINGVALUE = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.RATINGVALUE AND
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.GSWID = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.GSWID AND
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.BRANCHNUMBER = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.BRANCHNUMBER AND
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.INVOLVED_PARTY_TYPE_CD = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.INVOLVED_PARTY_TYPE_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET    
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.CREATEDATE = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.CREATEDATE,
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.INVOLVED_PARTY_TYPE_CD = TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.INVOLVED_PARTY_TYPE_CD,
# MAGIC INVOLVED_PARTY_RISK_RATING_EXTRACT_ST.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (RATING_TP_CD,RATINGVALUE,GSWID,BRANCHNUMBER,CREATEDATE,INVOLVED_PARTY_TYPE_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.RATING_TP_CD,TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.RATINGVALUE,TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.GSWID,TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.BRANCHNUMBER,TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.CREATEDATE,
# MAGIC TEMP_INVOLVED_PARTY_RISK_RATING_EXTRACT_SIL.INVOLVED_PARTY_TYPE_CD,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.INVOLVED_PARTY_RISK_RATING_EXTRACT_ST;

# COMMAND ----------

