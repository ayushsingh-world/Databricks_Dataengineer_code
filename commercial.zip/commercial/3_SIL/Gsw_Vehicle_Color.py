# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_vehicle_color_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

df.count()

# COMMAND ----------

from pyspark.sql.functions import trim 

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when,trim,col

# COMMAND ----------

df = df.withColumn("BRANCH_NUMBER", trim(df.BRANCH_NUMBER))
df = df.withColumn("VIN", trim(df.VIN))
df = df.withColumn("SUPPLIER_PLANT_CD", trim(df.SUPPLIER_PLANT_CD))
df = df.withColumn("COLOUR_CD",
                   when(trim(col("COLOUR_CD")) == "", "NC")
                   .otherwise(trim(col("COLOUR_CD"))))
df = df.withColumn("VEHICLE_TYPE_CD",
                   when(trim(col("VEHICLE_TYPE_CD")) == "WHOLESALE", "CL")
                   .otherwise(trim(col("VEHICLE_TYPE_CD"))))
df = df.withColumn("VEHICLE_LOCATION_CD",
                   when(trim(col("VEHICLE_LOCATION_CD")).isin("UPPER", "LOWER"), "PAINT")
                   .when(trim(col("VEHICLE_LOCATION_CD")).isin("CLOTH", "TRIM"), "TRIM")
                   .otherwise("TRIM"))
df = df.withColumn(
    "COLOR_DESC",
    when(
        col("COLOR_DESC").isNotNull() & (trim(col("COLOR_DESC")) != ""),
        trim(col("COLOR_DESC"))
    ).otherwise("No Colour Description Defined"))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_GSW_VEHICLE_COLOUR_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRANCH_NUMBER VARCHAR(255),
VIN VARCHAR(255),
SUPPLIER_PLANT_CD VARCHAR(255),
COLOUR_CD VARCHAR(255),
VEHICLE_TYPE_CD VARCHAR(255),
VEHICLE_LOCATION_CD VARCHAR(255),
COLOR_DESC VARCHAR(255),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/") #SILVER PATH

# COMMAND ----------

TBL_NAME='VEHICLE_COLOUR' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.VEHICLE_COLOUR as TGT USING TEMP_GSW_VEHICLE_COLOUR_SIL as SRC ON 
# MAGIC TGT.BRANCH_NUMBER=SRC.BRANCH_NUMBER AND
# MAGIC TGT.SUPPLIER_PLANT_CD=SRC.SUPPLIER_PLANT_CD AND
# MAGIC TGT.COLOUR_CD=SRC.COLOUR_CD AND
# MAGIC TGT.VEHICLE_LOCATION_CD=SRC.VEHICLE_LOCATION_CD AND
# MAGIC TGT.VIN=SRC.VIN
# MAGIC WHEN MATCHED THEN  UPDATE SET
# MAGIC TGT.VEHICLE_TYPE_CD=SRC.VEHICLE_TYPE_CD,
# MAGIC TGT.COLOR_DESC=SRC.COLOR_DESC,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED THEN INSERT 
# MAGIC (BRANCH_NUMBER,
# MAGIC VIN,
# MAGIC SUPPLIER_PLANT_CD,
# MAGIC COLOUR_CD,
# MAGIC VEHICLE_TYPE_CD ,
# MAGIC VEHICLE_LOCATION_CD,
# MAGIC COLOR_DESC,
# MAGIC INSERT_TIMSTM)
# MAGIC VALUES  
# MAGIC (SRC.BRANCH_NUMBER,
# MAGIC SRC.VIN,
# MAGIC SRC.SUPPLIER_PLANT_CD,
# MAGIC SRC.COLOUR_CD,
# MAGIC SRC.VEHICLE_TYPE_CD,
# MAGIC SRC.VEHICLE_LOCATION_CD,
# MAGIC SRC.COLOR_DESC,
# MAGIC current_timestamp())
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.VEHICLE_COLOUR;