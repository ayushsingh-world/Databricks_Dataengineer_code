# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

spark.conf.set('spark.sql.caseSensitive', True)
df="""select * from itda_io_dev.io_cml_brz.gsw_arrgunitamt_resorceitem_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("BranchNumber", when(df.BranchNumber.isNull(),"NA") \
    .when(df.BranchNumber=="","NA") \
    .otherwise(df.BranchNumber))
df=df.withColumn("VIN", when(df.VIN.isNull(),"NA") \
    .when(df.VIN=="","NA") \
    .otherwise(df.VIN))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARRGUNITAMT_RESORCEITEM_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
Branch_Number                    VARCHAR(20),
VIN                             VARCHAR(20),
RI_ARANGMNT_UNIT_TP_CD          VARCHAR(255),
ARANGMNT_UNIT_TYPE_CD           VARCHAR(255),
VEHICLE_TYPE_CD                 VARCHAR(255),
ARANGMNT_UNIT_AMOUNT_TYPE_CD    VARCHAR(255),
ARANGMNT_UNIT_AMT               DECIMAL(38,2),
INSERT_TIMSTM                   TIMESTAMP,
UPDATE_TIMSTM                   TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARRGUNITAMT_RESORCEITEM_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

spark.conf.set('spark.sql.caseSensitive', True)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ARRGUNITAMT_RESORCEITEM_ST as TGT USING TEMP_ARRGUNITAMT_RESORCEITEM_SIL as SRC ON 
# MAGIC TGT.ARANGMNT_UNIT_TYPE_CD = SRC.ARANGMNT_UNIT_TYPE_CD AND 
# MAGIC TGT.ARANGMNT_UNIT_AMOUNT_TYPE_CD = SRC.ARANGMNT_UNIT_AMOUNT_TYPE_CD AND
# MAGIC TGT.RI_ARANGMNT_UNIT_TP_CD = SRC.RI_ARANGMNT_UNIT_TP_CD AND
# MAGIC TGT.VIN = SRC.VIN AND
# MAGIC TGT.Branch_Number = SRC.BranchNumber AND
# MAGIC TGT.VEHICLE_TYPE_CD = SRC.VEHICLE_TYPE_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET 
# MAGIC TGT.ARANGMNT_UNIT_AMT = SRC.ARANGMNT_UNIT_AMT ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (Branch_Number,VIN,RI_ARANGMNT_UNIT_TP_CD,ARANGMNT_UNIT_TYPE_CD,VEHICLE_TYPE_CD,ARANGMNT_UNIT_AMOUNT_TYPE_CD,ARANGMNT_UNIT_AMT,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.BranchNumber,SRC.VIN,SRC.RI_ARANGMNT_UNIT_TP_CD,SRC.ARANGMNT_UNIT_TYPE_CD,SRC.VEHICLE_TYPE_CD,
# MAGIC SRC.ARANGMNT_UNIT_AMOUNT_TYPE_CD,SRC.ARANGMNT_UNIT_AMT,current_timestamp())

# COMMAND ----------

