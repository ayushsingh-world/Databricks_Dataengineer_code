# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_ARANGMNT_INVOLVED_PARTY_DEALER_LOAN_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_INVOLVED_PARTY_DEALER_LOAN_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ACCOUNT_NUMBER                VARCHAR(20) NOT NULL,
INVOLVED_PARTY_REFERENCE      VARCHAR(20) NOT NULL,
INVOLVED_PARTY_TP_CD          VARCHAR(50) NOT NULL,
ARG_IP_PTY_TP_CD              VARCHAR(50) NOT NULL,
BRANCH_NBR                    VARCHAR(20) NOT NULL,
INSERT_TIMSTM                 TIMESTAMP,
UPDATE_TIMSTM                 TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARANGMNT_INVOLVED_PARTY_DEALER_LOAN' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into itda_io_dev.io_cml_brz.ARANGMNT_INVOLVED_PARTY_DEALER_LOAN as TGT
# MAGIC using TEMP_ARANGMNT_INVOLVED_PARTY_DEALER_LOAN_SIL as SRC
# MAGIC on 
# MAGIC TGT.ACCOUNT_NUMBER = SRC.AccountNumber AND
# MAGIC TGT.BRANCH_NBR = SRC.BranchNumber 
# MAGIC when matched then update set 
# MAGIC TGT.ACCOUNT_NUMBER=SRC.AccountNumber,
# MAGIC TGT.INVOLVED_PARTY_REFERENCE=SRC.InvolvedPartyReference,
# MAGIC TGT.INVOLVED_PARTY_TP_CD=SRC.INVOLVED_PARTY_TP_CD,
# MAGIC TGT.ARG_IP_PTY_TP_CD=SRC.ARG_IP_PTY_TP_CD,
# MAGIC TGT.BRANCH_NBR=SRC.BranchNumber,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC when not matched then insert 
# MAGIC  (ACCOUNT_NUMBER,INVOLVED_PARTY_REFERENCE ,INVOLVED_PARTY_TP_CD,ARG_IP_PTY_TP_CD,BRANCH_NBR,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.AccountNumber,SRC.InvolvedPartyReference,SRC.INVOLVED_PARTY_TP_CD,SRC.ARG_IP_PTY_TP_CD,SRC.BranchNumber,current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ARANGMNT_INVOLVED_PARTY_DEALER_LOAN;