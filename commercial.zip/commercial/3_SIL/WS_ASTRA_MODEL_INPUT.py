# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-10'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_MODEL_INPUT_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.withColumnRenamed("createdate","CREATEDATE")\
  .withColumnRenamed("ratingperioddate","RATINGPERIODDATE")\
  .withColumnRenamed("involved_party_type_cd","INVOLVED_PARTY_TYPE_CD")\
  .withColumnRenamed("assessment_status_cd","ASSESSMENT_STATUS_CD")\
  .withColumnRenamed("assessment_tp_cd","ASSESSMENT_TYPE_CD")\
  .withColumnRenamed("involved_party_number","GSWID")\
  .withColumnRenamed("involved_party_branch_number","BRANCHNUMBER")\
  .withColumnRenamed("modelinputtypeid","CODE")\
  .withColumnRenamed("modelversiontypeid","MODELVERSIONTYPEID")\
  .withColumnRenamed("version","VERSION")\
  .withColumnRenamed("adjustedanswer","MODEL_INPUT_ADJ_ANSWER_AMT")\
  .withColumnRenamed("answer","MODEL_INPUT_ANSWER_AMT")\
  .withColumnRenamed("weight","MODEL_INPUT_WEIGHT_AMT")\
  .withColumnRenamed("rating","MODEL_INPUT_RATING_VALUE")\
  .withColumnRenamed("financialstatementid","REPORTPERIODID")\
  .withColumnRenamed("ratinggroupid","RATINGGROUPID")\
  .withColumnRenamed("ratinghistoryid","RATINGHISTORYID")\
  .withColumnRenamed("validfrom","VALID_FROM_DT")

# COMMAND ----------

df = df.withColumn("CREATEDATE",
                   when(df.createdate.isNotNull() & (trim(df.createdate) != ''), df.createdate)
                   .otherwise('1900-01-01 00:00:00'))
df = df.withColumn("RATINGPERIODDATE",
                   when(df.ratingperioddate.isNotNull() & (trim(df.ratingperioddate) != ''), df.ratingperioddate)
                   .otherwise('1900-01-01'))
df = df.withColumn("GSWId", trim(df.involved_party_number))
df = df.withColumn("BRANCHNUMBER", trim(df.involved_party_branch_number))
df = df.withColumn("CODE", trim(df.modelinputtypeid))
df = df.withColumn("MODELVERSIONTYPEID", trim(df.modelversiontypeid))
df = df.withColumn("VERSION", trim(df.version))
df = df.withColumn("MODEL_INPUT_ADJ_ANSWER_AMT",
                   when(df.adjustedanswer.isNotNull() & (trim(df.adjustedanswer) != ''), df.adjustedanswer)
                   .otherwise('0'))
df = df.withColumn("MODEL_INPUT_ANSWER_AMT",
                   when(df.answer.isNotNull() & (trim(df.answer) != ''), df.answer)
                   .otherwise('0'))
df = df.withColumn(".MODEL_INPUT_WEIGHT_AMT",
                   when(df.weight.isNotNull() & (trim(df.weight) != ''), df.weight)
                   .otherwise('0'))
df = df.withColumn("MODEL_INPUT_RATING_VALUE",
                   when(df.rating.isNotNull() & (trim(df.rating) != ''), df.rating)
                   .otherwise('Else'))                                                                                               

# COMMAND ----------

df.createOrReplaceTempView("TMP_MODEL_INPUT_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
CREATEDATE VARCHAR(20),
RATINGPERIODDATE VARCHAR(10),
INVOLVED_PARTY_TYPE_CD VARCHAR(50),
ASSESSMENT_STATUS_CD VARCHAR(20),
ASSESSMENT_TYPE_CD VARCHAR(20),
GSWID VARCHAR(255),
BRANCHNUMBER VARCHAR(20),
CODE VARCHAR(20),
MODELVERSIONTYPEID VARCHAR(20),
VERSION VARCHAR(20),
MODEL_INPUT_ADJ_ANSWER_AMT VARCHAR(50),
MODEL_INPUT_ANSWER_AMT VARCHAR(50),
MODEL_INPUT_WEIGHT_AMT VARCHAR(60),
MODEL_INPUT_RATING_VALUE VARCHAR(20),
REPORTPERIODID DECIMAL,
RATINGGROUPID DECIMAL,
RATINGHISTORYID DECIMAL,
VALID_FROM_DT TIMESTAMP,
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ws_MODEL_INPUT_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_MODEL_INPUT_st AS TGT USING TMP_MODEL_INPUT_SIL AS SRC ON
# MAGIC TGT.CREATEDATE = SRC.createdate AND
# MAGIC TGT.RATINGPERIODDATE = SRC.ratingperioddate AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.involved_party_type_cd AND
# MAGIC TGT.ASSESSMENT_STATUS_CD = SRC.assessment_status_cd AND
# MAGIC TGT.ASSESSMENT_TYPE_CD = SRC.assessment_tp_cd AND
# MAGIC TGT.GSWID = SRC.involved_party_number AND
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number AND
# MAGIC TGT.CODE = SRC.modelinputtypeid AND
# MAGIC TGT.MODELVERSIONTYPEID = SRC.modelversiontypeid AND
# MAGIC TGT.VERSION = SRC.version AND
# MAGIC TGT.MODEL_INPUT_ADJ_ANSWER_AMT = SRC.adjustedanswer AND
# MAGIC TGT.MODEL_INPUT_ANSWER_AMT = SRC.answer AND
# MAGIC TGT.MODEL_INPUT_WEIGHT_AMT = SRC.weight AND
# MAGIC TGT.MODEL_INPUT_RATING_VALUE = SRC.rating AND
# MAGIC TGT.REPORTPERIODID = SRC.financialstatementid AND
# MAGIC TGT.RATINGGROUPID = SRC.ratinggroupid AND
# MAGIC TGT.RATINGHISTORYID = SRC.ratinghistoryid AND
# MAGIC TGT.VALID_FROM_DT = SRC.validfrom
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC TGT.CREATEDATE = SRC.createdate,
# MAGIC TGT.RATINGPERIODDATE = SRC.ratingperioddate,
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.involved_party_type_cd,
# MAGIC TGT.ASSESSMENT_STATUS_CD = SRC.assessment_status_cd,
# MAGIC TGT.ASSESSMENT_TYPE_CD = SRC.assessment_tp_cd,
# MAGIC TGT.GSWID = SRC.involved_party_number,
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number,
# MAGIC TGT.CODE = SRC.modelinputtypeid,
# MAGIC TGT.MODELVERSIONTYPEID = SRC.modelversiontypeid,
# MAGIC TGT.VERSION = SRC.version,
# MAGIC TGT.MODEL_INPUT_ADJ_ANSWER_AMT = SRC.adjustedanswer,
# MAGIC TGT.MODEL_INPUT_ANSWER_AMT = SRC.answer,
# MAGIC TGT.MODEL_INPUT_WEIGHT_AMT = SRC.weight,
# MAGIC TGT.MODEL_INPUT_RATING_VALUE = SRC.rating,
# MAGIC TGT.REPORTPERIODID = SRC.financialstatementid,
# MAGIC TGT.RATINGGROUPID = SRC.ratinggroupid,
# MAGIC TGT.RATINGHISTORYID = SRC.ratinghistoryid,
# MAGIC TGT.VALID_FROM_DT = SRC.validfrom,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.CREATEDATE,TGT.RATINGPERIODDATE,TGT.INVOLVED_PARTY_TYPE_CD,TGT.ASSESSMENT_STATUS_CD,TGT.ASSESSMENT_TYPE_CD,TGT.GSWID,TGT.BRANCHNUMBER,TGT.CODE,TGT.MODELVERSIONTYPEID,TGT.VERSION,TGT.MODEL_INPUT_ADJ_ANSWER_AMT,TGT.MODEL_INPUT_ANSWER_AMT,TGT.MODEL_INPUT_WEIGHT_AMT,TGT.MODEL_INPUT_RATING_VALUE,TGT.REPORTPERIODID,TGT.RATINGGROUPID,TGT.RATINGHISTORYID,TGT.VALID_FROM_DT,TGT.INSERT_TIMSTM)
# MAGIC   VALUES (SRC.createdate,SRC.ratingperioddate,SRC.involved_party_type_cd,SRC.assessment_status_cd,SRC.assessment_tp_cd,SRC.involved_party_number,SRC.involved_party_branch_number,SRC.modelinputtypeid,SRC.modelversiontypeid,SRC.version,SRC.adjustedanswer,SRC.answer,SRC.weight,SRC.rating,SRC.financialstatementid,SRC.ratinggroupid,SRC.ratinghistoryid,SRC.validfrom,CURRENT_TIMESTAMP());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_MODEL_INPUT_st;