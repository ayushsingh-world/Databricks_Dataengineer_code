# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_INVOLVED_PARTY_INVOLVED_PARTY_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_INVOLVED_PARTY_INVOLVED_PARTY_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
InvolvedParty               VARCHAR(255),
RelatedInvolvedParty        VARCHAR(255),
Code                        VARCHAR(50) NOT NULL,
RelatedInvolvedPartyCode    VARCHAR(50) NOT NULL,
TypeCode                    VARCHAR(50) NOT NULL,
Branch_Number               VARCHAR(20),
INSERT_TIMSTM               TIMESTAMP,
UPDATE_TIMSTM               TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='INVOLVED_PARTY_INVOLVED_PARTY_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.INVOLVED_PARTY_INVOLVED_PARTY_ST as TGT USING TEMP_INVOLVED_PARTY_INVOLVED_PARTY_SIL as SRC ON 
# MAGIC TGT.InvolvedParty = SRC.InvolvedParty AND
# MAGIC TGT.Code = SRC.Code AND
# MAGIC TGT.RelatedInvolvedPartyCode = SRC.RelatedInvolvedPartyCode AND
# MAGIC TGT.TypeCode = SRC.TypeCode AND
# MAGIC TGT.Branch_Number = SRC.Branch_Number
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC TGT.RelatedInvolvedParty = SRC.RelatedInvolvedParty,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN INSERT
# MAGIC (InvolvedParty,RelatedInvolvedParty,Code,RelatedInvolvedPartyCode,TypeCode,Branch_Number,INSERT_TIMSTM)   
# MAGIC VALUES  
# MAGIC (SRC.InvolvedParty,SRC.RelatedInvolvedParty,SRC.Code,SRC.RelatedInvolvedPartyCode,SRC.TypeCode,SRC.Branch_Number,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.INVOLVED_PARTY_INVOLVED_PARTY_ST;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT InvolvedParty,Code,RelatedInvolvedPartyCode,TypeCode,Branch_Number,COUNT(*) AS count
# MAGIC FROM itda_io_dev.io_cml_brz.involved_party_involved_party_st
# MAGIC GROUP BY InvolvedParty,Code,RelatedInvolvedPartyCode,TypeCode,Branch_Number
# MAGIC HAVING COUNT(*) > 1;