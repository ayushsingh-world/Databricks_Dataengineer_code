# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.Crs_Involved_Party_Watchlist_Extract_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df = df.withColumn("IMPAIRMENT_STATUS_CD", 
                  when(df.IMPAIRMENT_STATUS_CD.isNull(),"NA")
                  .when(df.IMPAIRMENT_STATUS_CD=="","NA")
                  .otherwise(df.IMPAIRMENT_STATUS_CD))

df = df.withColumn("ACTIVATIONDATE", 
                  when((df.ACTIVATIONDATE.isNotNull()) & (df.ACTIVATIONDATE != ""), df.ACTIVATIONDATE)
                  .otherwise('1900-01-01'))

df = df.withColumn("REMOVALDATE", 
                  when((df.REMOVALDATE.isNotNull()) & (df.REMOVALDATE != ""), df.REMOVALDATE)
                  .otherwise('1900-01-01'))

df = df.withColumn("TARGETDATE", 
                  when((df.TARGETDATE.isNotNull()) & (df.TARGETDATE != ""), df.TARGETDATE)
                  .otherwise('1900-01-01'))

df = df.withColumn("AUDITDATE", 
                  when((df.AUDITDATE.isNotNull()) & (df.AUDITDATE != ""), df.AUDITDATE)
                  .otherwise('1900-01-01'))

df = df.withColumn("RELEASECOUNT", 
                  when(df.RELEASECOUNT.isNotNull(), df.RELEASECOUNT)
                  .otherwise(0))

df = df.withColumn("DELAYCOUNT", 
                  when(df.DELAYCOUNT.isNotNull(), df.DELAYCOUNT)
                  .otherwise(0))

df = df.withColumn("NON_ACCURAL_START_DT", 
                  when((df.NON_ACCURAL_START_DT.isNotNull()) & (df.NON_ACCURAL_START_DT != ""), df.NON_ACCURAL_START_DT)
                  .otherwise('1900-01-01'))

df = df.withColumn("NON_ACCURAL_END_DT", 
                  when((df.NON_ACCURAL_END_DT.isNotNull()) & (df.NON_ACCURAL_END_DT != ""), df.NON_ACCURAL_END_DT)
                  .otherwise('1900-01-01'))


# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_Involved_Party_Watchlist_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
    GSWID                      VARCHAR(50),
    BRANCHNUMBER               VARCHAR(50),
    WATCHLIST_REVIEW_STATUS_CD VARCHAR(50),
    WATCHLIST_RISK_STATUS_CD   VARCHAR(50),
    IMPAIRMENT_STATUS_CD       VARCHAR(50),
    ACTIVATIONDATE             DATE,
    REMOVALDATE                DATE,
    TARGETDATE                 DATE,
    COMMENTS                   VARCHAR(50),
    AUDITDATE                  DATE,
    RELEASECOUNT               DECIMAL(38,2),
    DELAYCOUNT                 DECIMAL(38,2),
    WATCHLISTID                VARCHAR(50),
    INVOLVED_PARTY_TYPE_CD     VARCHAR(50),
    NON_ACCURAL_FLAG           DECIMAL(38,2),
    NON_ACCURAL_START_DT       DATE,
    NON_ACCURAL_END_DT         DATE,
    STRATEGY_TYPE_CD           VARCHAR(50),
    STRATEGY_TYPE_DESC         VARCHAR(50),
    INSERT_TIMSTM              TIMESTAMP,
    UPDATE_TIMSTM              TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='Crs_Involved_Party_Watchlist_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.Crs_Involved_Party_Watchlist_ST as TGT USING TEMP_Involved_Party_Watchlist_SIL as SRC ON 
# MAGIC TGT.WATCHLIST_RISK_STATUS_CD = SRC.WATCHLIST_RISK_STATUS_CD AND
# MAGIC TGT.WATCHLIST_REVIEW_STATUS_CD = SRC.WATCHLIST_REVIEW_STATUS_CD AND
# MAGIC TGT.GSWID = SRC.GSWID AND
# MAGIC TGT.BRANCHNUMBER  = SRC.BRANCHNUMBER AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.INVOLVED_PARTY_TYPE_CD AND
# MAGIC TGT.IMPAIRMENT_STATUS_CD = SRC.IMPAIRMENT_STATUS_CD AND
# MAGIC TGT.STRATEGY_TYPE_CD = SRC.STRATEGY_TYPE_CD AND
# MAGIC TGT.STRATEGY_TYPE_DESC = SRC.STRATEGY_TYPE_DESC 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.GSWID = SRC.GSWID,
# MAGIC TGT.BRANCHNUMBER  = SRC.BRANCHNUMBER,
# MAGIC TGT.WATCHLIST_REVIEW_STATUS_CD =SRC.WATCHLIST_REVIEW_STATUS_CD ,
# MAGIC TGT.WATCHLIST_RISK_STATUS_CD = SRC.WATCHLIST_RISK_STATUS_CD ,
# MAGIC TGT.IMPAIRMENT_STATUS_CD = SRC.IMPAIRMENT_STATUS_CD ,
# MAGIC TGT.ACTIVATIONDATE =SRC.ACTIVATIONDATE ,
# MAGIC TGT.REMOVALDATE = SRC.REMOVALDATE ,
# MAGIC TGT.TARGETDATE = SRC.TARGETDATE ,
# MAGIC TGT.COMMENTS  = SRC.COMMENTS ,
# MAGIC TGT.AUDITDATE = SRC.AUDITDATE ,
# MAGIC TGT.RELEASECOUNT = SRC.RELEASECOUNT ,
# MAGIC TGT.DELAYCOUNT   = SRC.DELAYCOUNT ,
# MAGIC TGT.WATCHLISTID = SRC.WATCHLISTID ,
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.INVOLVED_PARTY_TYPE_CD ,
# MAGIC TGT.NON_ACCURAL_FLAG = SRC.NON_ACCURAL_FLAG ,
# MAGIC TGT.NON_ACCURAL_START_DT = SRC.NON_ACCURAL_START_DT ,
# MAGIC TGT.NON_ACCURAL_END_DT  = SRC.NON_ACCURAL_END_DT ,
# MAGIC TGT.STRATEGY_TYPE_CD = SRC.STRATEGY_TYPE_CD ,
# MAGIC TGT.STRATEGY_TYPE_DESC = SRC.STRATEGY_TYPE_DESC ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (GSWID,BRANCHNUMBER ,WATCHLIST_REVIEW_STATUS_CD ,WATCHLIST_RISK_STATUS_CD ,IMPAIRMENT_STATUS_CD ,ACTIVATIONDATE ,REMOVALDATE ,TARGETDATE ,COMMENTS ,AUDITDATE ,RELEASECOUNT ,DELAYCOUNT ,WATCHLISTID, INVOLVED_PARTY_TYPE_CD, NON_ACCURAL_FLAG, NON_ACCURAL_START_DT, NON_ACCURAL_END_DT, STRATEGY_TYPE_CD, STRATEGY_TYPE_DESC, INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.GSWID,SRC.BRANCHNUMBER ,SRC.WATCHLIST_REVIEW_STATUS_CD ,SRC.WATCHLIST_RISK_STATUS_CD ,SRC.IMPAIRMENT_STATUS_CD ,SRC.ACTIVATIONDATE ,SRC.REMOVALDATE ,SRC.TARGETDATE ,SRC.COMMENTS ,SRC.AUDITDATE ,SRC.RELEASECOUNT ,SRC.DELAYCOUNT ,SRC.WATCHLISTID, SRC.INVOLVED_PARTY_TYPE_CD, SRC.NON_ACCURAL_FLAG, SRC.NON_ACCURAL_START_DT, SRC.NON_ACCURAL_END_DT, SRC.STRATEGY_TYPE_CD, SRC.STRATEGY_TYPE_DESC,current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from itda_io_dev.io_cml_brz.crs_involved_party_watchlist_extract_bt where file_date='2024-04-30'