# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-18'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_financial_resource_item_hdr_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when,expr
from pyspark.sql.types import DecimalType

# COMMAND ----------

df = df.withColumn("financial_ri_dt", 
                   when((df.financial_ri_dt.isNotNull()) & (df.financial_ri_dt != ""), df.financial_ri_dt)
                   .otherwise('1900-01-01'))
df = df.withColumn("financial_ri_stmt_cd", 
                   when((df.financial_ri_stmt_cd.isNotNull()) & (df.financial_ri_stmt_cd != ""), df.financial_ri_stmt_cd)
                   .otherwise('NA'))
df = df.withColumn("involved_party_number",when(trim(df.involved_party_number) != "",             
     trim(df.involved_party_number)).otherwise("NA"))
df = df.withColumn("involved_party_branch_number",when(trim(df.involved_party_branch_number) != "",             
     trim(df.involved_party_branch_number)).otherwise("NA"))
df = df.withColumn(
    "baccode",
    when(df.baccode.isNull(), 'NA').otherwise(df.baccode)
)


# COMMAND ----------

df.withColumnRenamed("analystapproved","ANALYST_APPROVED")\
  .withColumnRenamed("baccode","baccode")\
  .withColumnRenamed("financial_ri_dt","FINANCIAL_RI_DT")\
  .withColumnRenamed("financial_ri_status_cd","FINANCIAL_RI_STATUS_CD")\
  .withColumnRenamed("financial_ri_stmt_cd","FINANCIAL_RI_STMT_CD")\
  .withColumnRenamed("financial_ri_type_cd","FINANCIAL_RI_TYPE_CD")\
  .withColumnRenamed("financialstatementid","FINANCIAL_RI_REPORT_PERIOD_ID")\
  .withColumnRenamed("financialstatementinstance","FINANCIAL_STMT_INSTANCE")\
  .withColumnRenamed("involved_party_branch_number","BRANCHNUMBER")\
  .withColumnRenamed("involved_party_number","GSWID")\
  .withColumnRenamed("involved_party_type_cd","Code")\
  .withColumnRenamed("isdeleted","ISDELETED")\
  .withColumnRenamed("isimported","ISIMPORTED")\
  .withColumnRenamed("templatetypeid","TEMPLATE_TYPE_ID")\
  .withColumnRenamed("typecode","TypeCode")

# COMMAND ----------

df.createOrReplaceTempView("TMP_FINANCIAL_RESOURCE_ITEM_HDR_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ANALYST_APPROVED VARCHAR(255),
baccode VARCHAR(255),
FINANCIAL_RI_DT DATE,
FINANCIAL_RI_STATUS_CD VARCHAR(255),
FINANCIAL_RI_STMT_CD VARCHAR(255),
FINANCIAL_RI_TYPE_CD VARCHAR(255),
FINANCIAL_RI_REPORT_PERIOD_ID DECIMAL(10,0),
FINANCIAL_STMT_INSTANCE DECIMAL(10,0),
BRANCHNUMBER VARCHAR(255),
GSWID	VARCHAR(255),
Code	VARCHAR(255),
ISDELETED	VARCHAR(255),
ISIMPORTED	VARCHAR(255),
TEMPLATE_TYPE_ID	VARCHAR(255),
TypeCode	VARCHAR(255),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_FINANCIAL_RESOURCE_ITEM_HDR_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_financial_resource_item_hdr_st AS TGT USING TMP_FINANCIAL_RESOURCE_ITEM_HDR_SIL AS SRC ON
# MAGIC TGT.ANALYST_APPROVED = SRC.analystapproved AND
# MAGIC TGT.baccode = SRC.baccode AND
# MAGIC TGT.FINANCIAL_RI_DT = SRC.financial_ri_dt AND
# MAGIC TGT.FINANCIAL_RI_STATUS_CD = SRC.financial_ri_status_cd AND
# MAGIC TGT.FINANCIAL_RI_STMT_CD = SRC.financial_ri_stmt_cd AND
# MAGIC TGT.FINANCIAL_RI_TYPE_CD = SRC.financial_ri_type_cd AND
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.financialstatementid AND
# MAGIC TGT.FINANCIAL_STMT_INSTANCE = SRC.financialstatementinstance AND
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number AND
# MAGIC TGT.GSWID = SRC.involved_party_number AND
# MAGIC TGT.Code = SRC.involved_party_type_cd AND
# MAGIC TGT.ISDELETED = SRC.isdeleted AND
# MAGIC TGT.ISIMPORTED = SRC.isimported AND
# MAGIC TGT.TEMPLATE_TYPE_ID = SRC.templatetypeid AND
# MAGIC TGT.TypeCode = SRC.typecode
# MAGIC WHEN MATCHED THEN 
# MAGIC UPDATE SET
# MAGIC TGT.ANALYST_APPROVED = SRC.analystapproved,
# MAGIC TGT.baccode = SRC.baccode,
# MAGIC TGT.FINANCIAL_RI_DT = SRC.financial_ri_dt,
# MAGIC TGT.FINANCIAL_RI_STATUS_CD = SRC.financial_ri_status_cd,
# MAGIC TGT.FINANCIAL_RI_STMT_CD = SRC.financial_ri_stmt_cd,
# MAGIC TGT.FINANCIAL_RI_TYPE_CD = SRC.financial_ri_type_cd,
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.financialstatementid,
# MAGIC TGT.FINANCIAL_STMT_INSTANCE = SRC.financialstatementinstance,
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number,
# MAGIC TGT.GSWID = SRC.involved_party_number,
# MAGIC TGT.Code = SRC.involved_party_type_cd,
# MAGIC TGT.ISDELETED = SRC.isdeleted,
# MAGIC TGT.ISIMPORTED = SRC.isimported,
# MAGIC TGT.TEMPLATE_TYPE_ID = SRC.templatetypeid,
# MAGIC TGT.TypeCode = SRC.typecode,
# MAGIC TGT.UPDATE_TIMSTM = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.ANALYST_APPROVED,TGT.baccode,TGT.FINANCIAL_RI_DT,TGT.FINANCIAL_RI_STATUS_CD,TGT.FINANCIAL_RI_STMT_CD,TGT.FINANCIAL_RI_TYPE_CD,TGT.FINANCIAL_RI_REPORT_PERIOD_ID,
# MAGIC   TGT.FINANCIAL_STMT_INSTANCE,TGT.BRANCHNUMBER,TGT.GSWID,TGT.Code,TGT.ISDELETED,TGT.ISIMPORTED,TGT.TEMPLATE_TYPE_ID,TGT.TypeCode,TGT.INSERT_TIMSTM)
# MAGIC 	    VALUES (SRC.analystapproved,SRC.baccode,SRC.financial_ri_dt,SRC.financial_ri_status_cd,SRC.financial_ri_stmt_cd,SRC.financial_ri_type_cd,SRC.financialstatementid,
# MAGIC       SRC.financialstatementinstance,SRC.involved_party_branch_number,SRC.involved_party_number,SRC.involved_party_type_cd,SRC.isdeleted,SRC.isimported,SRC.templatetypeid,SRC.typecode,CURRENT_TIMESTAMP());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_financial_resource_item_hdr_st;