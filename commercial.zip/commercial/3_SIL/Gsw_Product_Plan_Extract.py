# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_PRODUCT_PLAN_EXTRACT_BT  where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_PRODUCT_PLAN_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
PLAN_NM                 VARCHAR(50),
BRANCHNUMBER            VARCHAR(20) NOT NULL,
PRODUCT_PLAN_CD         VARCHAR(20),
PRODUCT_PLAN_TYPE_CD    VARCHAR(10) NOT NULL,
PLAN_SHORT_NM           VARCHAR(50),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='PRODUCT_PLAN_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.PRODUCT_PLAN_ST as TGT USING TEMP_PRODUCT_PLAN_SIL as SRC ON 
# MAGIC TGT.PLAN_NM = SRC.PLAN_NM AND
# MAGIC TGT.BRANCHNUMBER = SRC.BRANCHNUMBER AND
# MAGIC TGT.PRODUCT_PLAN_CD = SRC.PRODUCT_PLAN_CD AND
# MAGIC TGT.PRODUCT_PLAN_TYPE_CD = SRC.PRODUCT_PLAN_TYPE_CD AND
# MAGIC TGT.PLAN_SHORT_NM = SRC.PLAN_SHORT_NM 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (PLAN_NM,BRANCHNUMBER,PRODUCT_PLAN_CD,PRODUCT_PLAN_TYPE_CD,PLAN_SHORT_NM,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.PLAN_NM,SRC.BRANCHNUMBER,SRC.PRODUCT_PLAN_CD,SRC.PRODUCT_PLAN_TYPE_CD,SRC.PLAN_SHORT_NM,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.product_plan_st;