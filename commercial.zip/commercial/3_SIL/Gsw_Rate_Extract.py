# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_RATE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_RATE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
RATE_CD                 VARCHAR(200) NOT NULL,
RATE_DESC               VARCHAR(200),
RATE_TYPE               VARCHAR(200) NOT NULL,
BRANCH_NBR              VARCHAR(20) NOT NULL,
COUNTRY_CD              VARCHAR(30) NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='RATE' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.RATE as TGT USING TEMP_RATE_SIL as SRC ON 
# MAGIC TGT.RATE_CD = SRC.RATE_CD AND
# MAGIC TGT.RATE_TYPE = SRC.RATE_TYPE AND
# MAGIC TGT.BRANCH_NBR = SRC.BRANCHNUMBER 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.RATE_DESC = SRC.RATE_DESC ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (RATE_CD,RATE_DESC,RATE_TYPE,BRANCH_NBR,COUNTRY_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.RATE_CD,SRC.RATE_DESC,SRC.RATE_TYPE,SRC.BRANCHNUMBER,
# MAGIC SRC.COUNTRY_CD,current_timestamp())

# COMMAND ----------

