# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_COLOR_TYPE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("COLOUR_CD", when(df.COLOUR_CD.isNull(),"NC") \
    .when(df.COLOUR_CD=="","NC") \
    .otherwise(df.COLOUR_CD))
df=df.withColumn("COLOUR_DESC", when(df.COLOUR_DESC.isNull(),"No Colour Description Defined") \
    .when(df.COLOUR_DESC=="","No Colour Description Defined") \
    .otherwise(df.COLOUR_DESC))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_COLOR_TYPE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRANCH_NUMBER                   VARCHAR(20) NOT NULL,
SUPPLIER_PLANT_CD               VARCHAR(20) NOT NULL,
COLOUR_CD                       VARCHAR(20) NOT NULL,
COLOUR_DESC                     VARCHAR(255) NOT NULL,
COLOUR_TYPE                     VARCHAR(20) NOT NULL,
INSERT_TIMSTM                   TIMESTAMP,
UPDATE_TIMSTM                   TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='COLOR_TYPE_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.COLOR_TYPE_ST as TGT USING TEMP_COLOR_TYPE_SIL as SRC ON 
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD AND
# MAGIC TGT.COLOUR_CD = SRC.COLOUR_CD AND
# MAGIC TGT.COLOUR_TYPE = SRC.COLOUR_TYPE  
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.COLOUR_DESC = SRC.COLOUR_DESC,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (BRANCH_NUMBER,SUPPLIER_PLANT_CD,COLOUR_CD,COLOUR_DESC,COLOUR_TYPE,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.BRANCH_NUMBER,SRC.SUPPLIER_PLANT_CD,SRC.COLOUR_CD,SRC.COLOUR_DESC,SRC.COLOUR_TYPE,current_timestamp)

# COMMAND ----------


