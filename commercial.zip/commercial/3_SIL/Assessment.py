# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-07-02'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Assessment_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df = df.withColumnRenamed("involved_party_number","gswid")\
  .withColumnRenamed("involved_party_branch_number","branchnumber")\
  .withColumnRenamed("involved_party_type_cd","type_cd")\
  .withColumnRenamed("finstatmenttypeid","fin_stmt_type_cd")\
  .withColumnRenamed("reasonforreviewid","reason_for_review_cd")\
  .withColumnRenamed("validfrom","valid_from_dt")\
  .withColumnRenamed("isdeleted","isdeleted_ind")\
  .withColumnRenamed("override_reason_comment","override_reason_comment_txt")\
  .withColumnRenamed("edge_comment","edge_comment_txt")\
  .withColumnRenamed("opsdla","operation_dla_title_nm")\
  .withColumnRenamed("opsdlaapproved","operation_dla_approve_dt")\
  .withColumnRenamed("riskdla","risk_dla_title_nm")\
 .withColumnRenamed("riskdlaapproved","date")\
 .withColumnRenamed("approvedate","approved_date")\
  .withColumnRenamed("physicalnonconcurrentauditsfrequency","phys_non_conc_audit_nbr")\
  .withColumnRenamed("physicalconcurrentaudits","phys_conc_audit_freq_txt")\
  .withColumnRenamed("physicalnonconcurrentauditsfrequency","phys_non_conc_audit_nbr")\
  .withColumnRenamed("physicalauditsfrequency","phys_audit_nbr")\
  .withColumnRenamed("physicalnonconcurrentaudits","phys_non_conc_audit_freq_txt")

   
                        
                 
                 
               
            


# COMMAND ----------

display (df)

# COMMAND ----------

df = df.withColumn("event_life_cycle_status_cd", 
                   when(df.event_life_cycle_status_cd.isNull(),"NA")
                   .when(df.event_life_cycle_status_cd=="","NA")
                   .otherwise(df.event_life_cycle_status_cd))

df = df.withColumn("event_type_cd", 
                   when(df.event_type_cd.isNull(),"NA")
                   .when(df.event_type_cd=="","NA")
                   .otherwise(df.event_type_cd))

df = df.withColumn("gswid", 
                   when(df.gswid.isNull(),"NA")
                   .when(df.gswid=="","NA")
                   .otherwise(df.gswid))

df = df.withColumn("branchnumber", 
                   when(df.branchnumber.isNull(),"NA")
                   .when(df.branchnumber=="","NA")
                   .otherwise(df.branchnumber))

df = df.withColumn("createdate", 
                   when(df.createdate.isNull(), "1900-01-01")
                   .when(df.createdate=="","1900-01-01")
                   .otherwise(df.createdate))

df = df.withColumn("involved_party_event_tp_cd", 
                   when(df.involved_party_event_tp_cd.isNull(),"NA")
                   .when(df.involved_party_event_tp_cd=="","NA")
                   .otherwise(df.involved_party_event_tp_cd))

df = df.withColumn("assessment_tp_cd", 
                   when(df.assessment_tp_cd.isNull(),"NA")
                   .when(df.assessment_tp_cd=="","NA")
                   .otherwise(df.assessment_tp_cd))

df = df.withColumn("assessment_status_cd", 
                   when(df.assessment_status_cd.isNull(),"NA")
                   .when(df.assessment_status_cd=="","NA")
                   .otherwise(df.assessment_status_cd))

df = df.withColumn("ratingperioddate", 
                   when(df.ratingperioddate.isNull(), "1900-01-01")
                   .when(df.ratingperioddate=="","1900-01-01")
                   .otherwise(df.ratingperioddate))

df = df.withColumn("firstname", 
                   when((df.firstname.isNotNull()) & (df.firstname != ""), df.firstname)
                   .otherwise('NA'))

df = df.withColumn("lastname", 
                   when((df.lastname.isNotNull()) & (df.lastname != ""), df.lastname)
                   .otherwise('NA'))

df = df.withColumn("username", 
                   when((df.username.isNotNull()) & (df.username != ""), df.username)
                   .otherwise('NA'))

df = df.withColumn("ratingcomment", 
                   when(df.ratingcomment != "", df.ratingcomment)
                   .otherwise('NA'))

df = df.withColumn("probdefault", 
                   when(df.probdefault.isNull(),"NA")
                   .when(df.probdefault=="",0)
                   .otherwise(df.probdefault))

df = df.withColumn("override_reason_cd", 
                   when((df.override_reason_cd.isNotNull()) & (df.override_reason_cd != ""), df.override_reason_cd)
                   .otherwise('NA'))

df = df.withColumn("ratinggroupid", 
                   when((df.ratinggroupid.isNotNull()) & (df.ratinggroupid != ""), df.ratinggroupid)
                   .otherwise('NA'))


df = df.withColumn("approved_date", 
                   when(df.approved_date.isNull(), "1900-01-01")
                   .when(df.approved_date=="","1900-01-01")
                   .otherwise(df.approved_date))

df = df.withColumn("isdeleted_ind", 
                   when(df.isdeleted_ind == "TRUE", 1)
                   .otherwise(0))




# COMMAND ----------

df.createOrReplaceTempView("TEMP_Assessment_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
EVENT_LIFE_CYCLE_STATUS_CD        VARCHAR(50),
EVENT_TYPE_CD                     VARCHAR(50),
GSWID                             VARCHAR(50),
BRANCHNUMBER                      VARCHAR(50),
CREATEDATE                        TIMESTAMP,
RATINGHISTORYID                   INTEGER,
INVOLVED_PARTY_EVENT_TP_CD        VARCHAR(50),
ASSESSMENT_TP_CD                  VARCHAR(20),
ASSESSMENT_STATUS_CD              VARCHAR(50),
RATINGPERIODDATE                  DATE,
FIRSTNAME                         VARCHAR(255),
LASTNAME                          VARCHAR(255),
USERNAME                          VARCHAR(255),
RATINGCOMMENT                     VARCHAR(2500),
NUMBEROFMONTHS                    DECIMAL(38),
PROBDEFAULT                       DOUBLE,
MODELPROBABILITYOFDEFAULT         DOUBLE,
ANALYSTPROBABILITYOFDEFAULT       DOUBLE,
TYPE_CD                           VARCHAR(50),
OVERRIDE_REASON_CD                VARCHAR(50),
RATINGGROUPID                     INTEGER,
APPROVER_LAST_NAME                VARCHAR(255),
APPROVER_FIRST_NAME               VARCHAR(255),
APPROVER_USER_ID                  VARCHAR(255),
APPROVED_DATE                     DATE,
REPORTPERIODID                    INTEGER,
FIN_STMT_TYPE_CD                  VARCHAR(50),
FIN_STMT_TYPE_DESC                VARCHAR(255),
REASON_FOR_REVIEW_CD              VARCHAR(50),
REASON_FOR_REVIEW_DESC            VARCHAR(50),
OVERRIDE_REASON_DESC              VARCHAR(255),
EFFECTIVE_DT                      TIMESTAMP,
VALID_FROM_DT                      TIMESTAMP,
ISDELETED_IND                      VARCHAR(255),
OVERRIDE_REASON_COMMENT_TXT       VARCHAR(4000), 
EDGE_COMMENT_TXT                  VARCHAR(4000),
OPERATION_DLA_TITLE_NM            VARCHAR(255),
OPERATION_DLA_APPROVE_DT          DATE,
RISK_DLA_TITLE_NM                 VARCHAR(255),
RISK_DLA_APPROVE_DT               DATE,
PHYS_CONC_AUDIT_NBR               INTEGER,
PHYS_CONC_AUDIT_FREQ_TXT          VARCHAR(255),
PHYS_AUDIT_NBR                      VARCHAR(255),
PHYS_NON_CONC_AUDIT_NBR                 VARCHAR(255),
PHYS_AUDIT_FREQ_TXT                  VARCHAR(255),
PHYS_NON_CONC_AUDIT_FREQ_TXT      VARCHAR(255)

"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_Assessment_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_Assessment_st AS TGT
# MAGIC USING TEMP_Assessment_SIL AS SRC
# MAGIC ON 
# MAGIC   TGT.EVENT_LIFE_CYCLE_STATUS_CD = SRC.event_life_cycle_status_cd AND
# MAGIC   TGT.ASSESSMENT_STATUS_CD = SRC.assessment_status_cd AND 
# MAGIC   TGT.ASSESSMENT_TP_CD = SRC.assessment_tp_cd AND  
# MAGIC   TGT.INVOLVED_PARTY_EVENT_TP_CD = SRC.INVOLVED_PARTY_EVENT_TP_CD AND
# MAGIC   TGT.GSWID = SRC.gswid AND                   
# MAGIC   TGT.BRANCHNUMBER = SRC.branchnumber AND 
# MAGIC   TGT.TYPE_CD = SRC.type_cd AND 
# MAGIC   TGT.OVERRIDE_REASON_CD = SRC.override_reason_cd AND 
# MAGIC   TGT.FIN_STMT_TYPE_CD = SRC.fin_stmt_type_cd AND
# MAGIC   TGT.APPROVER_USER_ID = SRC.approver_user_id AND
# MAGIC   TGT.REASON_FOR_REVIEW_CD = SRC.reason_for_review_cd AND
# MAGIC   TGT.USERNAME = SRC.username               
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC     TGT.EVENT_TYPE_CD = SRC.event_type_cd,           
# MAGIC     TGT.CREATEDATE = SRC.createdate,                  
# MAGIC     TGT.RATINGHISTORYID = SRC.ratinggistoryid,          
# MAGIC     TGT.RATINGPERIODDATE = SRC.ratingperioddate,     
# MAGIC     TGT.FIRSTNAME = SRC.firstname,                
# MAGIC     TGT.LASTNAME = SRC.lastname,                                 
# MAGIC     TGT.RATINGCOMMENT = SRC.ratingcomment,               
# MAGIC     TGT.NUMBEROFMONTHS = SRC.numberofmonths,          
# MAGIC     TGT.PROBDEFAULT = SRC.probdefault,         
# MAGIC     TGT.MODELPROBABILITYOFDEFAULT = SRC.modelprobabilityofdefault,      
# MAGIC     TGT.ANALYSTPROBABILITYOFDEFAULT = SRC.analystpobabilityofdefault,
# MAGIC     TGT.TYPE_CD = SRC.type_cd,
# MAGIC     TGT.RATINGGROUPID = SRC.ratinggroupid,   
# MAGIC     TGT.APPROVER_LAST_NAME = SRC.approver_last_name,  
# MAGIC     TGT.APPROVER_FIRST_NAME = SRC.approver_first_name, 
# MAGIC     TGT.APPROVED_DATE = SRC.approved_date,
# MAGIC     TGT.REPORTPERIODID = SRC.reportperiodid,
# MAGIC     TGT.FIN_STMT_TYPE_DESC = SRC.fin_stmt_type_desc,  
# MAGIC     TGT.REASON_FOR_REVIEW_DESC = SRC.reason_for_review_desc,
# MAGIC     TGT.OVERRIDE_REASON_DESC = SRC.override_reason_desc,
# MAGIC     TGT.VALID_FROM_DT = SRC.valid_from_dt,
# MAGIC     TGT.ISDELETED_IND = SRC.isdeleted,
# MAGIC     TGT.OVERRIDE_REASON_COMMENT_TXT = SRC.override_reason_comment_txt,
# MAGIC     TGT.EDGE_COMMENT_TXT = SRC.edge_comment_txt,
# MAGIC     TGT.OPERATION_DLA_TITLE_NM = SRC.operation_dla_title_nm,
# MAGIC     TGT.OPERATION_DLA_APPROVE_DT = SRC.operation_dla_approve_dt,
# MAGIC     TGT.RISK_DLA_TITLE_NM = SRC.risk_dla_title_nm,
# MAGIC     TGT.RISK_DLA_APPROVE_DT = SRC.risk_dla_approve_dt,
# MAGIC     TGT.PHYS_NON_CONC_AUDIT_NBR = SRC.phys_non_conc_audit_nbr,
# MAGIC     TGT.PHYS_CONC_AUDIT_FREQ_TXT = SRC.phys_conc_audit_freq_txt,
# MAGIC     TGT.PHYS_AUDIT_NBR = SRC.phys_audit_nbr,
# MAGIC     TGT.PHYS_CONC_AUDIT_NBR = SRC.phys_conc_audit_nbr,
# MAGIC     TGT.PHYS_AUDIT_FREQ_TXT = SRC.phys_audit_freq_txt,
# MAGIC     TGT.PHYS_NON_CONC_AUDIT_FREQ_TXT = SRC.phys_non_conc_audit_freq_txt,
# MAGIC     TGT.EFFECTIVE_DT = current_timestamp
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (
# MAGIC     EVENT_LIFE_CYCLE_STATUS_CD, ASSESSMENT_STATUS_CD, ASSESSMENT_TP_CD, INVOLVED_PARTY_EVENT_TP_CD, GSWID, BRANCHNUMBER, TYPE_CD, OVERRIDE_REASON_CD, FIN_STMT_TYPE_CD, APPROVER_USER_ID, REASON_FOR_REVIEW_CD, USERNAME,
# MAGIC     EVENT_TYPE_CD, CREATEDATE, RATINGHISTORYID,  
# MAGIC      RATINGPERIODDATE, FIRSTNAME, LASTNAME,  RATINGCOMMENT, NUMBEROFMONTHS, 
# MAGIC     PROBDEFAULT, MODELPROBABILITYOFDEFAULT, ANALYSTPROBABILITYOFDEFAULT,  OVERRIDE_REASON_CD, RATINGGROUPID, 
# MAGIC     APPROVER_LAST_NAME, APPROVER_FIRST_NAME,  APPROVED_DATE, REPORTPERIODID, FIN_STMT_TYPE_CD, 
# MAGIC     FIN_STMT_TYPE_DESC,  REASON_FOR_REVIEW_DESC, OVERRIDE_REASON_DESC, EFFECTIVE_DT, VALID_FROM_DT, 
# MAGIC     ISDELETED_IND, OVERRIDE_REASON_COMMENT_TXT, EDGE_COMMENT_TXT, OPERATION_DLA_TITLE_NM, OPERATION_DLA_APPROVE_DT, 
# MAGIC     RISK_DLA_TITLE_NM, RISK_DLA_APPROVE_DT, PHYS_NON_CONC_AUDIT_NBR, PHYS_CONC_AUDIT_FREQ_TXT, PHYS_AUDIT_NBR, 
# MAGIC     PHYS_CONC_AUDIT_NBR, PHYS_AUDIT_FREQ_TXT, PHYS_NON_CONC_AUDIT_FREQ_TXT, EFFECTIVE_DT
# MAGIC   ) 
# MAGIC   VALUES (
# MAGIC     SRC.event_life_cycle_status_cd, SRC.assessment_status_cd, SRC.assessment_tp_cd, SRC.involved_party_event_tp_cd, SRC.gswid, SRC.branchnumber, SRC.type_cd, SRC.override_reason_cd, SRC.fin_stmt_type_cd, SRC.approver_user_id, SRC.reason_for_review_cd, SRC.username,
# MAGIC     SRC.event_type_cd,   SRC.createdate, SRC.ratinggistoryid, SRC.ratingperioddate, SRC.firstname, 
# MAGIC     SRC.lastname,  SRC.ratingcomment, SRC.numberofmonths, SRC.probdefault, SRC.modelprobabilityofdefault, 
# MAGIC     SRC.analystpobabilityofdefault,   SRC.ratinggroupid, SRC.approver_last_name, 
# MAGIC     SRC.approver_first_name,  SRC.approved_date, SRC.reportperiodid,  
# MAGIC     SRC.fin_stmt_type_desc,  SRC.reason_for_review_desc, SRC.override_reason_desc, SRC.valid_from_dt, 
# MAGIC     SRC.isdeleted, SRC.override_reason_comment_txt, SRC.edge_comment_txt, SRC.operation_dla_title_nm, SRC.operation_dla_approve_dt, 
# MAGIC     SRC.risk_dla_title_nm, SRC.risk_dla_approve_dt, SRC.phys_non_conc_audit_nbr, SRC.phys_conc_audit_freq_txt, SRC.phys_audit_nbr, 
# MAGIC     SRC.phys_conc_audit_nbr, SRC.phys_audit_freq_txt, SRC.phys_non_conc_audit_freq_txt, current_timestamp
# MAGIC   )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_Assessment_st AS TGT
# MAGIC USING TEMP_Assessment_SIL AS SRC
# MAGIC ON 
# MAGIC TGT.EVENT_LIFE_CYCLE_STATUS_CD  = SRC.event_life_cycle_status_cd AND
# MAGIC TGT.ASSESSMENT_STATUS_CD   = SRC.assessment_status_cd  AND 
# MAGIC TGT.ASSESSMENT_TP_CD    = SRC.assessment_tp_cd      AND  
# MAGIC TGT.INVOLVED_PARTY_EVENT_TP_CD   =   SRC.INVOLVED_PARTY_EVENT_TP_CD  AND
# MAGIC TGT.GSWID     =    SRC.gswid AND                   
# MAGIC TGT.BRANCHNUMBER   =   SRC.branchnumber AND 
# MAGIC TGT.TYPE_CD     =    SRC.type_cd         AND 
# MAGIC TGT.OVERRIDE_REASON_CD          =     SRC.override_reason_cd   AND 
# MAGIC TGT.FIN_STMT_TYPE_CD             =        SRC.fin_stmt_type_cd    AND
# MAGIC TGT.APPROVER_USER_ID            =     SRC.approver_user_id      AND
# MAGIC TGT.REASON_FOR_REVIEW_CD           =   SRC.reason_for_review_cd  AND
# MAGIC TGT.USERNAME     = SRC.username               
# MAGIC   WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC   TGT.EVENT_TYPE_CD    =  SRC.event_type_cd,           
# MAGIC TGT.CREATEDATE  =    SRC.createdate,                  
# MAGIC TGT.RATINGHISTORYID    = SRC.ratinggistoryid,          
# MAGIC TGT.RATINGPERIODDATE      =  SRC.ratingperioddate,     
# MAGIC TGT.FIRSTNAME    =  SRC.firstname,                
# MAGIC TGT.LASTNAME     = SRC.lastname,                                 
# MAGIC TGT.RATINGCOMMENT    = SRC.ratingcomment,               
# MAGIC TGT.NUMBEROFMONTHS   =   SRC.numberofmonths,          
# MAGIC TGT.PROBDEFAULT        =  SRC.probdefault,         
# MAGIC TGT.MODELPROBABILITYOFDEFAULT    =   SRC.modelprobabilityofdefault,      
# MAGIC TGT.ANALYSTPROBABILITYOFDEFAULT  = SRC.analystpobabilityofdefault,
# MAGIC TGT.TYPE_CD                  =       SRC.type_cd,
# MAGIC TGT.RATINGGROUPID             =        SRC.ratinggroupid,   
# MAGIC TGT.APPROVER_LAST_NAME        =      SRC.approver_last_name,  
# MAGIC TGT.APPROVER_FIRST_NAME         =    SRC.approver_first_name, 
# MAGIC TGT.APPROVED_DATE               =       SRC.approved_date,
# MAGIC TGT.REPORTPERIODID              =        SRC.reportperiodid,
# MAGIC TGT.FIN_STMT_TYPE_DESC            =     SRC.fin_stmt_type_desc,  
# MAGIC TGT.REASON_FOR_REVIEW_DESC         =   SRC.reason_for_review_desc,
# MAGIC TGT.OVERRIDE_REASON_DESC           =     SRC.override_reason_desc,
# MAGIC TGT.VALID_FROM_DT                =    SRC.valid_from_dt,
# MAGIC TGT.ISDELETED_IND                  =     SRC.isdeleted,
# MAGIC TGT.OVERRIDE_REASON_COMMENT_TXT     =     SRC.override_reason_comment_txt,
# MAGIC TGT.EDGE_COMMENT_TXT                 =    SRC.edge_comment_txt,
# MAGIC TGT.OPERATION_DLA_TITLE_NM           =    SRC.operation_dla_title_nm,
# MAGIC TGT.OPERATION_DLA_APPROVE_DT         =   SRC.operation_dla_approve_dt,
# MAGIC TGT.RISK_DLA_TITLE_NM               =     SRC.risk_dla_title_nm,
# MAGIC TGT.RISK_DLA_APPROVE_DT             =     SRC.risk_dla_approve_dt,
# MAGIC TGT.PHYS_NON_CONC_AUDIT_NBR           =    SRC.phys_non_conc_audit_nbr,
# MAGIC TGT.PHYS_CONC_AUDIT_FREQ_TXT         =     SRC.phys_conc_audit_freq_txt,
# MAGIC TGT.PHYS_AUDIT_NBR                    =    SRC.phys_audit_nbr,
# MAGIC TGT.PHYS_CONC_AUDIT_NBR              =    SRC.phys_conc_audit_nbr,
# MAGIC TGT.PHYS_AUDIT_FREQ_TXT               =   SRC.phys_audit_freq_txt,
# MAGIC TGT.PHYS_NON_CONC_AUDIT_FREQ_TXT      =     SRC.phys_non_conc_audit_freq_txt,
# MAGIC     TGT.EFFECTIVE_DT = current_timestamp
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (EVENT_LIFE_CYCLE_STATUS_CD, EVENT_TYPE_CD, GSWID ,BRANCHNUMBER ,CREATEDATE ,RATINGHISTORYID ,INVOLVED_PARTY_EVENT_TP_CD, ASSESSMENT_TP_CD, ASSESSMENT_STATUS_CD, RATINGPERIODDATE ,FIRSTNAME ,LASTNAME , USERNAME ,RATINGCOMMENT ,NUMBEROFMONTHS ,PROBDEFAULT,MODELPROBABILITYOFDEFAULT, ANALYSTPROBABILITYOFDEFAULT ,TYPE_CD  ,OVERRIDE_REASON_CD  ,RATINGGROUPID ,APPROVER_LAST_NAME ,APPROVER_FIRST_NAME ,APPROVER_USER_ID, APPROVED_DATE ,REPORTPERIODID ,FIN_STMT_TYPE_CD ,FIN_STMT_TYPE_DESC ,REASON_FOR_REVIEW_CD ,REASON_FOR_REVIEW_DESC ,OVERRIDE_REASON_DESC, EFFECTIVE_DT ,VALID_FROM_DT  ,ISDELETED_IND  ,OVERRIDE_REASON_COMMENT_TXT ,EDGE_COMMENT_TXT ,OPERATION_DLA_TITLE_NM, OPERATION_DLA_APPROVE_DT, RISK_DLA_TITLE_NM ,RISK_DLA_APPROVE_DT ,PHYS_NON_CONC_AUDIT_NBR ,PHYS_CONC_AUDIT_FREQ_TXT  ,PHYS_AUDIT_NBR, PHYS_CONC_AUDIT_NBR, PHYS_AUDIT_FREQ_TXT  ,PHYS_NON_CONC_AUDIT_FREQ_TXT, EFFECTIVE_DT) 
# MAGIC VALUES (SRC.event_life_cycle_status_cd, SRC.event_type_cd, SRC.gswid, SRC.branchnumber, SRC.createdate, SRC.ratinggistoryid, SRC.involved_party_event_tp_cd, SRC.assessment_tp_cd, SRC.assessment_status_cd, SRC.ratingperioddate, SRC.firstname, SRC.lastname, SRC.username, SRC.ratingcomment, SRC.numberofmonths, SRC.probdefault, SRC.modelprobabilityofdefault, SRC.analystpobabilityofdefault , SRC.type_cd, SRC.override_reason_cd , SRC.ratinggroupid, SRC.approver_last_name, SRC.approver_first_name, SRC.approver_user_id, SRC.approved_date, SRC.reportperiodid, SRC.fin_stmt_type_cd, SRC.fin_stmt_type_desc, SRC.reason_for_review_cd, SRC.reason_for_review_desc, SRC.override_reason_desc, 
# MAGIC SRC.valid_from_dt, SRC.isdeleted, SRC.override_reason_comment_txt, SRC.edge_comment_txt, SRC.operation_dla_title_nm, SRC.operation_dla_approve_dt, SRC.risk_dla_title_nm, SRC.risk_dla_approve_dt, SRC.phys_non_conc_audit_nbr, SRC.phys_conc_audit_freq_txt, SRC.phys_audit_nbr, SRC.phys_conc_audit_nbr, SRC.phys_audit_freq_txt, SRC.phys_non_conc_audit_freq_txt, current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from CIWSIL.Assessment;