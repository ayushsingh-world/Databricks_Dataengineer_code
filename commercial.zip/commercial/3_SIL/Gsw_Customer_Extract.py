# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-05-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_customer_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
  df= df.withColumn(colname, trim(colname))	


# COMMAND ----------

from pyspark.sql.functions import when
spark.conf.set(
'spark.sql.caseSensitive'
,
True
)

##from pyspark.sql.functions import 

# COMMAND ----------

df=df.withColumn("Tax_Id", when(df.Tax_Id.isNull(),"NA") \
    .when(df.Tax_Id=="","NA") \
    .otherwise(df.Tax_Id))
df=df.withColumn("EFF_CUSTOMER_DT", when(df.EFF_CUSTOMER_DT.isNull(),"NA") \
    .when(df.EFF_CUSTOMER_DT=="","NA") \
    .otherwise(df.EFF_CUSTOMER_DT))
df=df.withColumn("END_CUSTOMER_DT", when(df.END_CUSTOMER_DT.isNull(),"NA") \
    .when(df.END_CUSTOMER_DT=="","NA") \
    .otherwise(df.END_CUSTOMER_DT))
df=df.withColumn("THIRD_PARTY_TYPE_ID", when(df.THIRD_PARTY_TYPE_ID.isNull(),"NA") \
    .when(df.THIRD_PARTY_TYPE_ID=="","NA") \
    .otherwise(df.THIRD_PARTY_TYPE_ID))
df=df.withColumn("RELEASE_PRIVILEGE_EFF_DT", when(df.RELEASE_PRIVILEGE_EFF_DT.isNull(),"NA") \
    .when(df.RELEASE_PRIVILEGE_EFF_DT=="","NA") \
    .otherwise(df.RELEASE_PRIVILEGE_EFF_DT))
df=df.withColumn("RELEASE_PRIVILEGE_DAYS_NBR", when(df.RELEASE_PRIVILEGE_DAYS_NBR.isNull(),"NA") \
    .when(df.RELEASE_PRIVILEGE_DAYS_NBR=="","NA") \
    .otherwise(df.RELEASE_PRIVILEGE_DAYS_NBR))
df=df.withColumn("FLAT_CHARGE_CATEGORY_EFF_DT", when(df.FLAT_CHARGE_CATEGORY_EFF_DT.isNull(),"NA") \
    .when(df.FLAT_CHARGE_CATEGORY_EFF_DT=="","NA") \
    .otherwise(df.FLAT_CHARGE_CATEGORY_EFF_DT))
df=df.withColumn("FLAT_CHARGE_CATEGORY_CD", when(df.FLAT_CHARGE_CATEGORY_CD.isNull(),"NA") \
    .when(df.FLAT_CHARGE_CATEGORY_CD=="","NA") \
    .otherwise(df.FLAT_CHARGE_CATEGORY_CD))   

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format
df = df.withColumn("EFF_CUSTOMER_DT",to_date(col("EFF_CUSTOMER_DT"),"yyyy-MM-dd")) \
       .withColumn("END_CUSTOMER_DT",to_date(col("END_CUSTOMER_DT"),"yyyy-MM-dd")) \
       .withColumn("RELEASE_PRIVILEGE_EFF_DT",to_date(col("RELEASE_PRIVILEGE_EFF_DT"),"yyyy-MM-dd")) \
       .withColumn("FLAT_CHARGE_CATEGORY_EFF_DT",to_date(col("FLAT_CHARGE_CATEGORY_EFF_DT"),"yyyy-MM-dd"))

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType
from pyspark.sql.types import IntegerType

# COMMAND ----------

df = df.withColumn("LIQUIDATION_IND", df["LIQUIDATION_IND"].cast(DecimalType(38,2))) \
        .withColumn("EMPLOYEE_CNT", df["EMPLOYEE_CNT"].cast(DecimalType(38,2))) \
        .withColumn("ACTIVE_DEALER_FLAG", df["ACTIVE_DEALER_FLAG"].cast(DecimalType(38,2)))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_CUSTOMER_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
DEALERNUMBER VARCHAR(255),
CITYNAME VARCHAR(50),
STATENAME VARCHAR(50),
TAX_ID VARCHAR(20),
CODE VARCHAR(50) NOT NULL,
EMAIL_ADDRESS_DESC VARCHAR(50),
INDUSTRY_CLASSIFICATION_CD VARCHAR(50) NOT NULL,
County_Name VARCHAR(255) NOT NULL,
Country_Name VARCHAR(255),
UnionCountryName VARCHAR(255),
TypeCode VARCHAR(250) NOT NULL,
EFF_CUSTOMER_DT DATE,
END_CUSTOMER_DT DATE,
LIQUIDATION_INDICATOR DECIMAL(38),
TAX_CODE_ID VARCHAR(20),
THIRD_PARTY_TYPE_ID VARCHAR(38),
COMPANY_NM VARCHAR(255),
EMPLOYEE_CNT DECIMAL(38),
REGISTERED_PLACE_NM VARCHAR(100) NOT NULL,
REFERENCE_NBR VARCHAR(50),
FISCAL_CD VARCHAR(50),
VAT_NBR VARCHAR(50),
Branch_Number VARCHAR(20),
ACTIVE_DEALER_FLAG DECIMAL(38),
DOING_BUSINESS_AS_NM VARCHAR(255),
RELEASE_PRIVILEGE_EFF_DT DATE,
RELEASE_PRIVILEGE_DAYS_NBR VARCHAR(10),
FLAT_CHARGE_CATEGORY_EFF_DT DATE,
FLAT_CHARGE_CATEGORY_CD VARCHAR(50),
PRIMARY_PHONE_NBR VARCHAR(20),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/") #SILVER PATH

# COMMAND ----------

TBL_NAME='customer_extract_st' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.customer_extract_st as TGT USING TEMP_CUSTOMER_SIL as SRC ON 
# MAGIC TGT.CITYNAME=SRC.CityName AND
# MAGIC TGT.STATENAME=SRC.StateName AND
# MAGIC TGT.County_Name=SRC.CountyName AND
# MAGIC TGT.Country_Name=SRC.CountryName AND
# MAGIC TGT.UnionCountryName=SRC.UnionCountryName AND
# MAGIC TGT.DEALERNUMBER=SRC.DealerNumber AND
# MAGIC TGT.INDUSTRY_CLASSIFICATION_CD=SRC.INDUSTRY_CLASSIFICATION_CD AND
# MAGIC TGT.TypeCode=SRC.TypeCode AND
# MAGIC TGT.CODE=SRC.CODE AND
# MAGIC TGT.TAX_CODE_ID=SRC.TAX_CODE_ID AND
# MAGIC TGT.FLAT_CHARGE_CATEGORY_CD=SRC.FLAT_CHARGE_CATEGORY_CD AND
# MAGIC TGT.Branch_Number=SRC.Branch_Number
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.TAX_ID=SRC.Tax_Id,
# MAGIC TGT.EMAIL_ADDRESS_DESC=SRC.EMAIL_ADDRESS_DESC,
# MAGIC TGT.EFF_CUSTOMER_DT=SRC.EFF_CUSTOMER_DT,
# MAGIC TGT.END_CUSTOMER_DT=SRC.END_CUSTOMER_DT,
# MAGIC TGT.LIQUIDATION_INDICATOR=SRC.LIQUIDATION_IND,
# MAGIC TGT.THIRD_PARTY_TYPE_ID=SRC.THIRD_PARTY_TYPE_ID,
# MAGIC TGT.COMPANY_NM=SRC.COMPANY_NM,
# MAGIC TGT.EMPLOYEE_CNT=SRC.EMPLOYEE_CNT,
# MAGIC TGT.REGISTERED_PLACE_NM=SRC.REGISTERED_PLACE_NM,
# MAGIC TGT.REFERENCE_NBR=SRC.REFERENCE_NBR,
# MAGIC TGT.FISCAL_CD=SRC.FISCAL_CD,
# MAGIC TGT.VAT_NBR=SRC.VAT_NBR,
# MAGIC TGT.ACTIVE_DEALER_FLAG=SRC.ACTIVE_DEALER_FLAG,
# MAGIC TGT.DOING_BUSINESS_AS_NM=SRC.DOING_BUSINESS_AS_NM,
# MAGIC TGT.RELEASE_PRIVILEGE_EFF_DT=SRC.RELEASE_PRIVILEGE_EFF_DT,
# MAGIC TGT.RELEASE_PRIVILEGE_DAYS_NBR=SRC.RELEASE_PRIVILEGE_DAYS_NBR,
# MAGIC TGT.FLAT_CHARGE_CATEGORY_EFF_DT=SRC.FLAT_CHARGE_CATEGORY_EFF_DT,
# MAGIC TGT.PRIMARY_PHONE_NBR=SRC.PRIMARY_PHONE_NBR,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED THEN INSERT 
# MAGIC (DEALERNUMBER,
# MAGIC CITYNAME,
# MAGIC STATENAME,
# MAGIC TAX_ID,
# MAGIC CODE,
# MAGIC EMAIL_ADDRESS_DESC,
# MAGIC INDUSTRY_CLASSIFICATION_CD,
# MAGIC County_Name,
# MAGIC Country_Name,
# MAGIC UnionCountryName,
# MAGIC TypeCode,
# MAGIC EFF_CUSTOMER_DT,
# MAGIC END_CUSTOMER_DT,
# MAGIC LIQUIDATION_INDICATOR,
# MAGIC TAX_CODE_ID,
# MAGIC THIRD_PARTY_TYPE_ID,
# MAGIC COMPANY_NM,
# MAGIC EMPLOYEE_CNT,
# MAGIC REGISTERED_PLACE_NM,
# MAGIC REFERENCE_NBR,
# MAGIC FISCAL_CD,
# MAGIC VAT_NBR,
# MAGIC Branch_Number,
# MAGIC ACTIVE_DEALER_FLAG,
# MAGIC DOING_BUSINESS_AS_NM,
# MAGIC RELEASE_PRIVILEGE_EFF_DT,
# MAGIC RELEASE_PRIVILEGE_DAYS_NBR,
# MAGIC FLAT_CHARGE_CATEGORY_EFF_DT,
# MAGIC FLAT_CHARGE_CATEGORY_CD,
# MAGIC PRIMARY_PHONE_NBR,
# MAGIC INSERT_TIMSTM )   
# MAGIC VALUES  
# MAGIC (SRC.DealerNumber,
# MAGIC SRC.CityName,
# MAGIC SRC.StateName,
# MAGIC SRC.Tax_Id,
# MAGIC SRC.CODE,
# MAGIC SRC.EMAIL_ADDRESS_DESC,
# MAGIC SRC.INDUSTRY_CLASSIFICATION_CD,
# MAGIC SRC.CountyName,
# MAGIC SRC.CountryName,
# MAGIC SRC.UnionCountryName,
# MAGIC SRC.TypeCode,
# MAGIC SRC.EFF_CUSTOMER_DT,
# MAGIC SRC.END_CUSTOMER_DT,
# MAGIC SRC.LIQUIDATION_IND,
# MAGIC SRC.TAX_CODE_ID,
# MAGIC SRC.THIRD_PARTY_TYPE_ID,
# MAGIC SRC.COMPANY_NM,
# MAGIC SRC.EMPLOYEE_CNT,
# MAGIC SRC.REGISTERED_PLACE_NM,
# MAGIC SRC.REFERENCE_NBR,
# MAGIC SRC.FISCAL_CD,
# MAGIC SRC.VAT_NBR,
# MAGIC SRC.Branch_Number,
# MAGIC SRC.ACTIVE_DEALER_FLAG,
# MAGIC SRC.DOING_BUSINESS_AS_NM,
# MAGIC SRC.RELEASE_PRIVILEGE_EFF_DT,
# MAGIC SRC.RELEASE_PRIVILEGE_DAYS_NBR,
# MAGIC SRC.FLAT_CHARGE_CATEGORY_EFF_DT,
# MAGIC SRC.FLAT_CHARGE_CATEGORY_CD,
# MAGIC SRC.PRIMARY_PHONE_NBR,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.customer_extract_st;