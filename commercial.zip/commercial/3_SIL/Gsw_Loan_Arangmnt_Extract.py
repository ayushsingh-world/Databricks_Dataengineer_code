# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_LOAN_ARANGMNT_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
  df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("ARANGMNT_LIFE_CYCLE_STATUS_DT", when(df.ARANGMNT_LIFE_CYCLE_STATUS_DT.isNull(),"1900-01-01 00:00:00") \
    .when(df.ARANGMNT_LIFE_CYCLE_STATUS_DT=="","1900-01-01 00:00:00") \
    .otherwise(df.ARANGMNT_LIFE_CYCLE_STATUS_DT))
df=df.withColumn("LOAN_SRT_DT", when(df.LOAN_SRT_DT.isNull(),"1900-01-01") \
    .when(df.LOAN_SRT_DT=="","1900-01-01") \
    .otherwise(df.LOAN_SRT_DT))
df=df.withColumn("LON_CHK_DT", when(df.LON_CHK_DT.isNull(),"1900-01-01") \
    .when(df.LON_CHK_DT=="","1900-01-01") \
    .otherwise(df.LON_CHK_DT))
df=df.withColumn("LON_PIF_DT", when(df.LON_PIF_DT.isNull(),"1900-01-01") \
    .when(df.LON_PIF_DT=="","1900-01-01") \
    .otherwise(df.LON_PIF_DT))
df=df.withColumn("STOP_ACCRUAL_DT", when(df.STOP_ACCRUAL_DT.isNull(),"1900-01-01") \
    .when(df.STOP_ACCRUAL_DT=="","1900-01-01") \
    .otherwise(df.STOP_ACCRUAL_DT))
df=df.withColumn("OLDT_OST_DUE_DT", when(df.OLDT_OST_DUE_DT.isNull(),"1900-01-01") \
    .when(df.OLDT_OST_DUE_DT=="","1900-01-01") \
    .otherwise(df.OLDT_OST_DUE_DT))
df=df.withColumn("PRINICIPAL_REDUCTION_CNT", when(df.PRINICIPAL_REDUCTION_CNT.isNull(),"0") \
    .when(df.PRINICIPAL_REDUCTION_CNT=="","0") \
    .otherwise(df.PRINICIPAL_REDUCTION_CNT))
df=df.withColumn("CR_LN_NO", when(df.CR_LN_NO.isNull(),"NA") \
    .when(df.CR_LN_NO=="","NA") \
    .otherwise(df.CR_LN_NO))
df=df.withColumn("LOAN_PURPOSE", when(df.LOAN_PURPOSE.isNull(),"-1") \
    .when(df.LOAN_PURPOSE=="","-1") \
    .otherwise(df.LOAN_PURPOSE))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_LOAN_ARANGMNT_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ARANGMNT_CATEGORY_CD            VARCHAR(50) NOT NULL,
ARANGMNT_TYPE_CD                VARCHAR(50) NOT NULL,
ARANGMNT_STATUS_CD              VARCHAR(50) NOT NULL,
ARANGMNT_LIFE_CYCLE_STATUS_DT   VARCHAR(38),
LOAN_PYT_MET_CD                 VARCHAR(255),
LOAN_ADV_MET_CD                 VARCHAR(255),
INT_PYT_MET_CD                  VARCHAR(255),
ACCOUNT_NUMBER                  VARCHAR(20) NOT NULL,
LOAN_SRT_DT                     VARCHAR(20) NOT NULL,
LON_CHK_DT                      VARCHAR(20),
LON_PIF_DT                      VARCHAR(20),
STOP_ACCRUAL_DT                 VARCHAR(20),
LON_DS                          VARCHAR(255) NOT NULL,
LON_OVR_QY                      VARCHAR(255) NOT NULL,
PRINICIPAL_REDUCTION_CNT        VARCHAR(38),
LOAN_PENALTY_METHOD_CD          VARCHAR(255),
BRN_ID_NO                       VARCHAR(255),
ACC_ONL_TRM                     VARCHAR(255),
OLDT_OST_DUE_DT                 VARCHAR(20),
CR_LN_NO                        VARCHAR(50),
DLR_ID_NO                       VARCHAR(255),
LOAN_PURPOSE                    VARCHAR(10),
INSERT_TIMSTM                   TIMESTAMP,
UPDATE_TIMSTM                   TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/") #SILVER PATH

# COMMAND ----------

TBL_NAME='LOAN_ARANGMNT' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.LOAN_ARANGMNT as TGT USING TEMP_LOAN_ARANGMNT_SIL as SRC ON 
# MAGIC TGT.ARANGMNT_CATEGORY_CD = SRC.ARANGMNT_CATEGORY_CD AND
# MAGIC TGT.ARANGMNT_TYPE_CD = SRC.ARANGMNT_TYPE_CD AND
# MAGIC TGT.ARANGMNT_STATUS_CD = SRC.ARANGMNT_STATUS_CD AND
# MAGIC TGT.LOAN_PYT_MET_CD = SRC.LOAN_PYT_MET_CD AND
# MAGIC TGT.LOAN_ADV_MET_CD = SRC.LOAN_ADV_MET_CD AND
# MAGIC TGT.INT_PYT_MET_CD = SRC.INT_PYT_MET_CD AND
# MAGIC TGT.ACCOUNT_NUMBER = SRC.ACCOUNT_NUMBER AND
# MAGIC TGT.LOAN_PENALTY_METHOD_CD = SRC.LOAN_PENALTY_METHOD_CD AND
# MAGIC TGT.BRN_ID_NO = SRC.BRN_ID_NO AND
# MAGIC TGT.CR_LN_NO = SRC.CR_LN_NO AND
# MAGIC TGT.DLR_ID_NO = SRC.DLR_ID_NO AND
# MAGIC TGT.LOAN_PURPOSE = SRC.LOAN_PURPOSE 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.ARANGMNT_LIFE_CYCLE_STATUS_DT = SRC.ARANGMNT_LIFE_CYCLE_STATUS_DT ,
# MAGIC TGT.LOAN_SRT_DT = SRC.LOAN_SRT_DT ,
# MAGIC TGT.LON_CHK_DT = SRC.LON_CHK_DT ,
# MAGIC TGT.LON_PIF_DT = SRC.LON_PIF_DT ,
# MAGIC TGT.STOP_ACCRUAL_DT = SRC.STOP_ACCRUAL_DT ,
# MAGIC TGT.LON_DS = SRC.LON_DS ,
# MAGIC TGT.LON_OVR_QY = SRC.LON_OVR_QY ,
# MAGIC TGT.PRINICIPAL_REDUCTION_CNT = SRC.PRINICIPAL_REDUCTION_CNT ,
# MAGIC TGT.ACC_ONL_TRM = SRC.ACC_ONL_TRM ,
# MAGIC TGT.OLDT_OST_DUE_DT = SRC.OLDT_OST_DUE_DT ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (ARANGMNT_CATEGORY_CD,ARANGMNT_TYPE_CD,ARANGMNT_STATUS_CD,ARANGMNT_LIFE_CYCLE_STATUS_DT,LOAN_PYT_MET_CD,LOAN_ADV_MET_CD,INT_PYT_MET_CD,ACCOUNT_NUMBER,LOAN_SRT_DT,LON_CHK_DT,LON_PIF_DT,STOP_ACCRUAL_DT,LON_DS,LON_OVR_QY,PRINICIPAL_REDUCTION_CNT,LOAN_PENALTY_METHOD_CD,BRN_ID_NO,ACC_ONL_TRM,OLDT_OST_DUE_DT,CR_LN_NO,DLR_ID_NO,LOAN_PURPOSE,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.ARANGMNT_CATEGORY_CD,SRC.ARANGMNT_TYPE_CD,SRC.ARANGMNT_STATUS_CD,SRC.ARANGMNT_LIFE_CYCLE_STATUS_DT,SRC.LOAN_PYT_MET_CD,SRC.LOAN_ADV_MET_CD,SRC.INT_PYT_MET_CD,SRC.ACCOUNT_NUMBER,SRC.LOAN_SRT_DT,SRC.LON_CHK_DT,SRC.LON_PIF_DT,SRC.STOP_ACCRUAL_DT,SRC.LON_DS,SRC.LON_OVR_QY,SRC.PRINICIPAL_REDUCTION_CNT,SRC.LOAN_PENALTY_METHOD_CD,SRC.BRN_ID_NO,SRC.ACC_ONL_TRM,SRC.OLDT_OST_DUE_DT,SRC.CR_LN_NO,SRC.DLR_ID_NO,SRC.LOAN_PURPOSE,current_timestamp())

# COMMAND ----------

