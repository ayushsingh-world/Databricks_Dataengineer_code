# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-01-15'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Involved_Party_Post_Add_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

df=spark.sql("select * from itda_io_dev.io_cml_brz.ws_Involved_Party_Post_Add_bt")

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.createOrReplaceTempView("TMP_Involved_Party_Post_Add_ST")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
AccountNumber                    VARCHAR(20),
ProductTypeId                    VARCHAR(5),
Customer_ID                      VARCHAR(255),
AccountStatusDescription          VARCHAR(50),
Address1                             VARCHAR(50),
Address2                            VARCHAR(50),
CityName                            VARCHAR(50),
StateName                            VARCHAR(50),
BarrioName                          VARCHAR(20),
PostalCode                          VARCHAR(20),
TypeOfAddress                     VARCHAR(50),
StartDate                       VARCHAR(38),
EndDate                        VARCHAR(38),
HomeValueAmount              Decimal(38,2),
MonthlyPaymentAmount          Decimal(38,2),
DurationMonthsCount             Decimal(38,2),
DurationYearsCount               Decimal(38,2),
AddressTypeCode             VARCHAR(50),
OccupancyTypeCode               VARCHAR(50),
CountyName                     VARCHAR(50),
CountryName                  VARCHAR(50),
UnionCountryName             VARCHAR(50),
BranchNumber              Integer,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_Involved_Party_Post_Add_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_Involved_Party_Post_Add_ST AS TGT
# MAGIC USING TMP_Involved_Party_Post_Add_ST AS SRC
# MAGIC ON 
# MAGIC TGT.AccountNumber              =     SRC.accountnumber     AND
# MAGIC TGT.ProductTypeId               =       SRC.producttypeid    AND
# MAGIC TGT.Customer_ID                  =     SRC.involved_party_number    AND
# MAGIC TGT.AccountStatusDescription     =        SRC.accountstatusid     AND
# MAGIC TGT.Address1                     =       SRC.addressline1    AND
# MAGIC TGT.Address2                      =   SRC.addressline2     AND
# MAGIC TGT.CityName                      =     SRC.cityname     AND
# MAGIC TGT.StateName                     =     SRC.state       AND
# MAGIC TGT.BarrioName                   =     SRC.barrioname     AND
# MAGIC TGT.PostalCode                   =   SRC.postalcode       AND
# MAGIC TGT.TypeOfAddress                =    SRC.code      AND
# MAGIC TGT.StartDate                     =    SRC.startdate    AND
# MAGIC TGT.EndDate                        =    SRC.enddate     AND
# MAGIC TGT.HomeValueAmount                 =      SRC.homevalueamount    AND
# MAGIC TGT.MonthlyPaymentAmount             =        SRC.monthlypaymentamount    AND
# MAGIC TGT.DurationMonthsCount               =      SRC.durationmonthscount     AND
# MAGIC TGT.DurationYearsCount                =     SRC.durationyearscount     AND
# MAGIC TGT.AddressTypeCode                  =    SRC.addresstypecode         AND
# MAGIC TGT.OccupancyTypeCode                 =      SRC.occupancytypecode    AND
# MAGIC TGT.CountyName                     =    SRC.county_nm        AND 
# MAGIC TGT.CountryName                    =    SRC.countryname       AND
# MAGIC TGT.UnionCountryName               =    SRC.unioncountryname     AND
# MAGIC TGT.BranchNumber                 =       SRC.branch_number      
# MAGIC 	   WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC   TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (AccountNumber, ProductTypeId, Customer_ID, AccountStatusDescription, Address1, Address2, CityName,StateName, BarrioName, PostalCode, TypeOfAddress, StartDate, EndDate, HomeValueAmount, MonthlyPaymentAmount,DurationMonthsCount, DurationYearsCount, AddressTypeCode, OccupancyTypeCode, CountyName, CountryName, UnionCountryName, BranchNumber, INSERT_TIMSTM)
# MAGIC   VALUES (SRC.accountnumber, SRC.producttypeid, SRC.involved_party_number, SRC.accountstatusid, SRC.addressline1, SRC.addressline2, SRC.cityname, SRC.state, SRC.barrioname, SRC.postalcode
# MAGIC , SRC.code, SRC.startdate, SRC.enddate, SRC.homevalueamount, SRC.monthlypaymentamount, SRC.durationmonthscount, SRC.durationyearscount, SRC.addresstypecode, SRC.occupancytypecode, SRC.county_nm, SRC.countryname, SRC.unioncountryname, SRC.branch_number, current_timestamp())
# MAGIC