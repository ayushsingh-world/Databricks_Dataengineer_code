# Databricks notebook source
# MAGIC %sql
# MAGIC ---drop table itda_io_dev.io_cml_brz.WS_ANALYST_ST;

# COMMAND ----------

##dbutils.fs.ls("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_ANALYST_ST")

# COMMAND ----------

##%fs
##rm -r abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_ANALYST_ST

# COMMAND ----------

from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_analyst_bt  where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df.withColumnRenamed("analyst_first_nm","ANALYST_FIRST_NAME")\
  .withColumnRenamed("analyst_last_nm","ANALYST_LAST_NAME")\
  .withColumnRenamed("analyst_user_id","ANALYST_USER_ID")\
  .withColumnRenamed("branch_number","BRANCH_NUMBER")\
   .withColumnRenamed("code","CODE")\
   .withColumnRenamed("isactive","ACTIVE_IND")

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType

# COMMAND ----------

from pyspark.sql.functions import when
df=df.withColumn("analyst_last_nm", when(df.analyst_last_nm.isNull(),"NA") \
    .when(df.analyst_last_nm=="","NA") \
    .otherwise(df.analyst_last_nm))
df=df.withColumn("analyst_user_id ", when(df.analyst_user_id .isNull(),"NA") \
    .when(df.analyst_user_id =="","NA") \
    .otherwise(df.analyst_user_id))
df=df.withColumn("branch_number", when(df.branch_number.isNull(),"NA") \
    .when(df.branch_number=="","NA") \
    .otherwise(df.branch_number))

# COMMAND ----------

df.createOrReplaceTempView("TEMP_ANALYST_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ANALYST_FIRST_NAME	VARCHAR(255),
ANALYST_LAST_NAME	VARCHAR(255),
ANALYST_USER_ID	   VARCHAR(255),
BRANCH_NUMBER      VARCHAR(50),
CODE VARCHAR(50),
ACTIVE_IND	CHAR(1),
INSERT_TIMSTM       TIMESTAMP,
UPDATE_TIMSTM    TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_ANALYST_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_ANALYST_ST as TGT USING TEMP_ANALYST_SIL as SRC ON 
# MAGIC     TGT.ANALYST_USER_ID = SRC.ANALYST_USER_ID AND
# MAGIC      TGT.BRANCH_NUMBER= SRC.branch_number 
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     TGT.ANALYST_FIRST_NAME = SRC.analyst_first_nm,
# MAGIC     TGT.ANALYST_LAST_NAME = SRC.analyst_last_nm ,
# MAGIC      TGT.CODE = SRC.code ,
# MAGIC     TGT.ACTIVE_IND = SRC.isactive,
# MAGIC     TGT.UPDATE_TIMSTM = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (ANALYST_FIRST_NAME,ANALYST_LAST_NAME,ANALYST_USER_ID,BRANCH_NUMBER ,CODE,ACTIVE_IND,INSERT_TIMSTM)
# MAGIC   VALUES (SRC.analyst_first_nm, SRC.analyst_last_nm,SRC.analyst_user_id,SRC.branch_number ,SRC.code ,SRC.isactive,CURRENT_TIMESTAMP());