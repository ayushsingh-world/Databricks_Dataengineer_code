# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_product_rate_type_extract_bt  where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

df=df.withColumn("START_DT", when(df.START_DT.isNull(),"1900-01-01") \
    .when(df.START_DT=="","1900-01-01") \
    .otherwise(df.START_DT))
df=df.withColumn("END_DT", when(df.END_DT.isNull(),"1900-01-01") \
    .when(df.END_DT=="","1900-01-01") \
    .otherwise(df.END_DT))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_PRODUCT_RATE_TYPE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
PRODUCT_PLAN_NAME		VARCHAR(255) NOT NULL,
VERSIONNUMBER			DECIMAL(38) NOT NULL,
RATE_TYPE_CODE			VARCHAR(255) NOT NULL,
BRANCH_NUMBER			VARCHAR(20) NOT NULL,
RATE_CD					VARCHAR(50) NOT NULL,
PRODUCT_PLAN_TYPE_CD	VARCHAR(20) NOT NULL,
RATE_BASIS_CD			VARCHAR(20) NOT NULL,
START_DT				TIMESTAMP  NOT NULL,
END_DT					TIMESTAMP,
RATE_PCT				DECIMAL(10) NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='PRODUCT_RATE_TYPE_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into itda_io_dev.io_cml_brz.PRODUCT_RATE_TYPE_ST as TGT
# MAGIC using TEMP_PRODUCT_RATE_TYPE_SIL as SRC
# MAGIC on 
# MAGIC TGT.PRODUCT_PLAN_NAME = SRC.PRODUCT_PLAN_NAME AND
# MAGIC TGT.VERSIONNUMBER = SRC.VERSIONNUMBER AND
# MAGIC TGT.RATE_TYPE_CODE = SRC.RATE_TYPE_CODE AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER AND
# MAGIC TGT.RATE_CD = SRC.RATE_CD AND
# MAGIC TGT.PRODUCT_PLAN_TYPE_CD = SRC.PRODUCT_PLAN_TYPE_CD AND
# MAGIC TGT.RATE_BASIS_CD = SRC.RATE_BASIS_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET  
# MAGIC TGT.START_DT = SRC.START_DT,
# MAGIC TGT.END_DT = SRC.END_DT,
# MAGIC TGT.RATE_PCT = SRC.RATE_PCT,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED  THEN INSERT 
# MAGIC (PRODUCT_PLAN_NAME,VERSIONNUMBER,RATE_TYPE_CODE,RATE_CD,BRANCH_NUMBER,PRODUCT_PLAN_TYPE_CD,RATE_BASIS_CD,START_DT,END_DT,RATE_PCT,INSERT_TIMSTM)   
# MAGIC VALUES  
# MAGIC (SRC.PRODUCT_PLAN_NAME,SRC.VERSIONNUMBER,SRC.RATE_TYPE_CODE,SRC.RATE_CD,SRC.BRANCH_NUMBER,SRC.PRODUCT_PLAN_TYPE_CD,SRC.RATE_BASIS_CD,SRC.START_DT,SRC.END_DT,SRC.RATE_PCT,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.product_rate_type_st;