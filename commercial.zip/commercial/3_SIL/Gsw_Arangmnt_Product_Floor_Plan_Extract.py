# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_ARANGMNT_PRODUCT_FLOOR_PLAN_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_PRODUCT_FLOOR_PLAN_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
DLR_ID                      VARCHAR(50),
DLR_TYPE_CD                 VARCHAR(10),
MFG_CD                      VARCHAR(50),
MFG_TYPE_CD                 VARCHAR(10),
VERSION_NUMBER                  INTEGER,
PRODUCT_PLAN_CD             VARCHAR(50),
BRN_ID_NO                   VARCHAR(20),
PRODUCT_PLAN_TYPE_CD        VARCHAR(20),
SUPPLIER_PLANT_CD           VARCHAR(20),
INSERT_TIMSTM                 TIMESTAMP,
UPDATE_TIMSTM                 TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARANGMNT_PRODUCT_FLOOR_PLAN_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ARANGMNT_PRODUCT_FLOOR_PLAN_ST as TGT USING TEMP_ARANGMNT_PRODUCT_FLOOR_PLAN_SIL as SRC ON 
# MAGIC TGT.DLR_ID = SRC.DLR_ID AND
# MAGIC TGT.DLR_TYPE_CD = SRC.DLR_TYPE_CD AND
# MAGIC TGT.MFG_CD = SRC.MFG_CD AND
# MAGIC TGT.MFG_TYPE_CD = SRC.MFG_TYPE_CD AND
# MAGIC TGT.BRN_ID_NO = SRC.BRN_ID_NO AND
# MAGIC TGT.VERSION_NUMBER = SRC.VERSION_NUMBER AND
# MAGIC TGT.PRODUCT_PLAN_CD = SRC.PRODUCT_PLAN_CD AND
# MAGIC TGT.PRODUCT_PLAN_TYPE_CD = SRC.PRODUCT_PLAN_TYPE_CD AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (DLR_ID,DLR_TYPE_CD,MFG_CD,MFG_TYPE_CD,VERSION_NUMBER,PRODUCT_PLAN_CD,BRN_ID_NO,PRODUCT_PLAN_TYPE_CD,SUPPLIER_PLANT_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.DLR_ID,SRC.DLR_TYPE_CD,SRC.MFG_CD,SRC.MFG_TYPE_CD,SRC.VERSION_NUMBER,SRC.PRODUCT_PLAN_CD,SRC.BRN_ID_NO,SRC.PRODUCT_PLAN_TYPE_CD,SRC.SUPPLIER_PLANT_CD,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.arangmnt_product_floor_plan_st;