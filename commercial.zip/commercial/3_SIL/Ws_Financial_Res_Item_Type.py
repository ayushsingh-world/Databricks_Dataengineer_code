# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Financial_Res_Item_Type_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when,expr
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.createOrReplaceTempView("TEMP_Financial_Res_Item_Type")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
RESOURCE_ITEM_TYPE_CD    VARCHAR(255),
RESOURCE_ITEM_TYPE_DESC     VARCHAR(255),
RESOURCE_ITEM_TYPE_PRES_DESC      VARCHAR(255),
RESOURCE_ITEM_TYPE_LIT_CD          VARCHAR(255),
RESOURCE_ITEM_TYPE_FORMULA_DES      VARCHAR(4000),
CURRENCY_IND                   VARCHAR(255),
ADJUST_IND            DECIMAL(38),
EXPORT_IND            DECIMAL(38),
ISDELETED_IND         DECIMAL(38),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ws_Financial_Res_Item_Type_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_Financial_Res_Item_Type_st AS TGT
# MAGIC USING TEMP_Financial_Res_Item_Type AS SRC
# MAGIC ON 
# MAGIC   TGT.RESOURCE_ITEM_TYPE_CD = SRC.resource_item_type_cd AND
# MAGIC   TGT.RESOURCE_ITEM_TYPE_DESC = SRC.resource_item_type_desc AND
# MAGIC   TGT.RESOURCE_ITEM_TYPE_PRES_DESC = SRC.resource_item_type_pres_desc AND
# MAGIC   TGT.RESOURCE_ITEM_TYPE_LIT_CD = SRC.resource_item_type_lit_cd AND
# MAGIC   TGT.RESOURCE_ITEM_TYPE_FORMULA_DES = SRC.resource_item_type_formula_des AND
# MAGIC     TGT.CURRENCY_IND = SRC.currency_ind AND
# MAGIC     TGT.ADJUST_IND = SRC.resource_item_adjustable AND
# MAGIC 	  TGT.EXPORT_IND = SRC.resource_item_in_ciw AND
# MAGIC 	    TGT.ISDELETED_IND = SRC.isdeleted 
# MAGIC 	   WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC       TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (RESOURCE_ITEM_TYPE_CD, RESOURCE_ITEM_TYPE_DESC, RESOURCE_ITEM_TYPE_PRES_DESC, RESOURCE_ITEM_TYPE_LIT_CD, RESOURCE_ITEM_TYPE_FORMULA_DES, CURRENCY_IND, ADJUST_IND, EXPORT_IND, ISDELETED_IND, INSERT_TIMSTM)
# MAGIC   VALUES (SRC.resource_item_type_cd, SRC.resource_item_type_desc, SRC.resource_item_type_pres_desc, SRC.resource_item_type_lit_cd, SRC.resource_item_type_formula_des, SRC.currency_ind, SRC.resource_item_adjustable, SRC.resource_item_in_ciw, SRC.isdeleted, current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_Financial_Res_Item_Type_st;