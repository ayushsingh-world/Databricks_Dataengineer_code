# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_txn_ev_rsrc_items_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.functions import *
from pyspark.sql.functions import when


# COMMAND ----------

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.withColumn("BRN_ID_NO", when(df.BRN_ID_NO.isNull(),"NA") \
    .when(df.BRN_ID_NO=="","NA") \
    .otherwise(df.BRN_ID_NO))
df=df.withColumn("COL_ID", when(df.COL_ID.isNull(),"NA") \
    .when(df.COL_ID=="","NA") \
    .otherwise(df.COL_ID))
df=df.withColumn("TRANSACTION_TP_CD", when(df.TRANSACTION_TP_CD.isNull(),"NA") \
    .when(df.TRANSACTION_TP_CD=="","NA") \
    .otherwise(df.TRANSACTION_TP_CD))
df=df.withColumn("TRANSACTION_REASON_TP_CD", when(df.TRANSACTION_REASON_TP_CD.isNull(),"NA") \
    .when(df.TRANSACTION_REASON_TP_CD=="","NA") \
    .otherwise(df.TRANSACTION_REASON_TP_CD))
df=df.withColumn("EVENT_TYPE_CD", when(df.EVENT_TYPE_CD.isNull(),"NA") \
    .when(df.EVENT_TYPE_CD=="","NA") \
    .otherwise(df.EVENT_TYPE_CD))
df=df.withColumn("EVENT_LIFE_CYCLE_STATUS_CD", when(df.EVENT_LIFE_CYCLE_STATUS_CD.isNull(),"NA") \
    .when(df.EVENT_LIFE_CYCLE_STATUS_CD=="","NA") \
    .otherwise(df.EVENT_LIFE_CYCLE_STATUS_CD))
df=df.withColumn("RESOURCE_ITEM_EVENT_TYPE_CD", when(df.RESOURCE_ITEM_EVENT_TYPE_CD.isNull(),"NA") \
    .when(df.RESOURCE_ITEM_EVENT_TYPE_CD=="","NA") \
    .otherwise(df.RESOURCE_ITEM_EVENT_TYPE_CD))
df=df.withColumn("VEHICLE_TYPE_CD", when(df.VEHICLE_TYPE_CD.isNull(),"NA") \
    .when(df.VEHICLE_TYPE_CD=="","NA") \
    .otherwise(df.VEHICLE_TYPE_CD))
df=df.withColumn("ACTIVITY_TYPE", when(df.ACTIVITY_TYPE.isNull(),"NA") \
    .when(df.ACTIVITY_TYPE=="","NA") \
    .otherwise(df.ACTIVITY_TYPE))
df=df.withColumn("PAYMENT_METHOD_CD", when(df.PAYMENT_METHOD_CD.isNull(),"NA") \
    .when(df.PAYMENT_METHOD_CD=="","NA") \
    .otherwise(df.PAYMENT_METHOD_CD))
df=df.withColumn("DLR_ID_NO", when(df.DLR_ID_NO.isNull(),"NA") \
    .when(df.DLR_ID_NO=="","NA") \
    .otherwise(df.DLR_ID_NO))
df=df.withColumn("PAYMENT_SOURCE_TYPE", when(df.PAYMENT_SOURCE_TYPE.isNull(),"NA") \
    .when(df.PAYMENT_SOURCE_TYPE=="","NA") \
    .otherwise(df.PAYMENT_SOURCE_TYPE))
df=df.withColumn("PAYMENT_TYPE", when(df.PAYMENT_TYPE.isNull(),"NA") \
    .when(df.PAYMENT_TYPE=="","NA") \
    .otherwise(df.PAYMENT_TYPE))
df=df.withColumn("TRANSACTION_GL_DT", when(df.TRANSACTION_GL_DT.isNull(),"1900-01-01") \
    .when(df.TRANSACTION_GL_DT=="","1900-01-01") \
    .otherwise(df.TRANSACTION_GL_DT))

# COMMAND ----------


df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_TXN_EV_RSRC_ITEMS_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRN_ID_NO	                       VarChar(20),
COL_ID	                           VarChar(20),
TRANSACTION_TP_CD	               VarChar(20) NOT NULL,
TRANSACTION_REASON_TP_CD	       VarChar(255),
TRANSACTION_DUE_DT	               Date,
TRANSACTION_BOOK_DT	               Date,
TRANSACTION_VALUE_DT	           Date,
TRANSACTION_AMT	                   Decimal(38,2),
TRANSACTION_SEQUENCE_NBR	       SmallInt NOT NULL,
EVENT_TYPE_CD	                   VarChar(50) NOT NULL,
EVENT_LIFE_CYCLE_STATUS_CD	       VarChar(50) NOT NULL,
RESOURCE_ITEM_EVENT_TYPE_CD        VarChar(50) NOT NULL,
VEHICLE_TYPE_CD	                   VarChar(50) NOT NULL,
ACTIVITY_TYPE	                   VarChar(50) NOT NULL,
PAYMENT_METHOD_CD	               VarChar(50),
SOURCE_SYSTEM_REFERENCE_ID	       VarChar(255),
DLR_ID_NO	                       VarChar(20),
Involved_Part_Event_TypeCode	   VarChar(20),
PAYMENT_SOURCE_TYPE	               VarChar(10) NOT NULL,
PAYMENT_TYPE	                   VarChar(10) NOT NULL,
PLAN_CODE	                       VarChar(20) NOT NULL,
COMMENT_TEXT                      VarChar(4000) NOT NULL,
BANK_NM	                           VarChar(255),
BANK_SUBBLOCK_CD	               VarChar(10),
TRANSACTION_GL_DT	               Date NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/") #SILVER PATH

# COMMAND ----------

TBL_NAME='TXN_EV_RSRC_ITEMS_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.TXN_EV_RSRC_ITEMS_ST as TGT USING TEMP_TXN_EV_RSRC_ITEMS_SIL as SRC ON 
# MAGIC TGT.EVENT_TYPE_CD =	SRC.EVENT_TYPE_CD AND 
# MAGIC TGT.EVENT_LIFE_CYCLE_STATUS_CD = SRC.EVENT_LIFE_CYCLE_STATUS_CD AND
# MAGIC TGT.ACTIVITY_TYPE =	SRC.ACTIVITY_TYPE AND
# MAGIC TGT.TRANSACTION_REASON_TP_CD = SRC.TRANSACTION_REASON_TP_CD AND
# MAGIC TGT.TRANSACTION_TP_CD =	SRC.TRANSACTION_TP_CD AND
# MAGIC TGT.PAYMENT_METHOD_CD =	SRC.PAYMENT_METHOD_CD AND
# MAGIC TGT.RESOURCE_ITEM_EVENT_TYPE_CD = SRC.RESOURCE_ITEM_EVENT_TYPE_CD AND
# MAGIC TGT.COL_ID = SRC.COL_ID AND
# MAGIC TGT.VEHICLE_TYPE_CD = SRC.VEHICLE_TYPE_CD AND
# MAGIC TGT.BRN_ID_NO =	SRC.BRN_ID_NO AND
# MAGIC TGT.DLR_ID_NO =	SRC.DLR_ID_NO AND
# MAGIC TGT.Involved_Part_Event_TypeCode = SRC.Involved_Part_Event_TypeCode AND
# MAGIC TGT.PAYMENT_TYPE = SRC.PAYMENT_TYPE AND
# MAGIC TGT.PAYMENT_SOURCE_TYPE=SRC.PAYMENT_SOURCE_TYPE AND
# MAGIC TGT.TRANSACTION_DUE_DT = SRC.TRANSACTION_DUE_DT AND
# MAGIC TGT.TRANSACTION_BOOK_DT	= SRC.TRANSACTION_BOOK_DT AND
# MAGIC TGT.TRANSACTION_VALUE_DT = SRC.TRANSACTION_VALUE_DT AND
# MAGIC TGT.TRANSACTION_AMT = SRC.TRANSACTION_AMT AND
# MAGIC TGT.TRANSACTION_SEQUENCE_NBR=SRC.TRANSACTION_SEQUENCE_NBR AND
# MAGIC TGT.SOURCE_SYSTEM_REFERENCE_ID=SRC.SOURCE_SYSTEM_REFERENCE_ID AND
# MAGIC TGT.PLAN_CODE=SRC.PLAN_CODE AND
# MAGIC TGT.COMMENT_TEXT = SRC.PAYMENT_DESCRIPTION AND
# MAGIC TGT.BANK_NM	= SRC.BANK_NM AND
# MAGIC TGT.BANK_SUBBLOCK_CD=SRC.BANK_SUBBLOCK_CD AND
# MAGIC TGT.TRANSACTION_GL_DT =	SRC.TRANSACTION_GL_DT
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (BRN_ID_NO,COL_ID,TRANSACTION_TP_CD,TRANSACTION_REASON_TP_CD,TRANSACTION_DUE_DT,TRANSACTION_BOOK_DT,TRANSACTION_VALUE_DT,TRANSACTION_AMT,TRANSACTION_SEQUENCE_NBR,EVENT_TYPE_CD,EVENT_LIFE_CYCLE_STATUS_CD,RESOURCE_ITEM_EVENT_TYPE_CD,VEHICLE_TYPE_CD,ACTIVITY_TYPE,PAYMENT_METHOD_CD,SOURCE_SYSTEM_REFERENCE_ID,DLR_ID_NO,Involved_Part_Event_TypeCode,PAYMENT_SOURCE_TYPE,PAYMENT_TYPE,PLAN_CODE,COMMENT_TEXT,BANK_NM,BANK_SUBBLOCK_CD,TRANSACTION_GL_DT,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.BRN_ID_NO,SRC.COL_ID,SRC.TRANSACTION_TP_CD,SRC.TRANSACTION_REASON_TP_CD,SRC.TRANSACTION_DUE_DT,
# MAGIC SRC.TRANSACTION_BOOK_DT,SRC.TRANSACTION_VALUE_DT,SRC.TRANSACTION_AMT,SRC.TRANSACTION_SEQUENCE_NBR,SRC.EVENT_TYPE_CD,
# MAGIC SRC.EVENT_LIFE_CYCLE_STATUS_CD,SRC.RESOURCE_ITEM_EVENT_TYPE_CD,SRC.VEHICLE_TYPE_CD,SRC.ACTIVITY_TYPE,
# MAGIC SRC.PAYMENT_METHOD_CD,SRC.SOURCE_SYSTEM_REFERENCE_ID,SRC.DLR_ID_NO,SRC.Involved_Part_Event_TypeCode,
# MAGIC SRC.PAYMENT_SOURCE_TYPE,SRC.PAYMENT_TYPE,SRC.PLAN_CODE,SRC.PAYMENT_DESCRIPTION,SRC.BANK_NM,SRC.BANK_SUBBLOCK_CD,
# MAGIC SRC.TRANSACTION_GL_DT,current_timestamp())