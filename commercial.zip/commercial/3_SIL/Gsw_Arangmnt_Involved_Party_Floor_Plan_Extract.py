# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_ARANGMNT_INVOLVED_PARTY_FLOOR_PLAN_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import *

# COMMAND ----------

df = df.withColumn("VERSION_NUMBER", df["VERSION_NUMBER"].cast(IntegerType()))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_INVOLVED_PARTY_FLOOR_PLAN_EXTRACT_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
INVOLVED_PARTY_REFERENCE   VARCHAR(20) NOT NULL,
INVOLVED_PARTY_TP_CD       VARCHAR(50) NOT NULL,
ARG_IP_PTY_TP_CD           VARCHAR(50) NOT NULL,
DEALER_NBR                 VARCHAR(20) NOT NULL,
DLR_TYPE_CD                VARCHAR(10) NOT NULL,
MFG_CD                     VARCHAR(50) NOT NULL,
MFG_TYPE_CD                VARCHAR(10) NOT NULL,
VERSION_NUMBER             INTEGER NOT NULL,
PRODUCT_PLAN_CD            VARCHAR(20) NOT NULL,
PRODUCT_PLAN_TYPE_CD       VARCHAR(20) NOT NULL,
BRANCH_NBR                 VARCHAR(20) NOT NULL,
SUPPLIER_PLANT_CD          VARCHAR(20) NOT NULL,
INSERT_TIMSTM              TIMESTAMP,
UPDATE_TIMSTM              TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ARANGMNT_INVOLVED_PARTY_FLOOR_PLAN_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(file_date) from TEMP_ARANGMNT_INVOLVED_PARTY_FLOOR_PLAN_EXTRACT_SIL;

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into itda_io_dev.io_cml_brz.ARANGMNT_INVOLVED_PARTY_FLOOR_PLAN_ST as TGT
# MAGIC using TEMP_ARANGMNT_INVOLVED_PARTY_FLOOR_PLAN_EXTRACT_SIL as SRC
# MAGIC on 
# MAGIC TGT.INVOLVED_PARTY_REFERENCE = SRC.InvolvedPartyReference AND
# MAGIC TGT.INVOLVED_PARTY_TP_CD = SRC.INVOLVED_PARTY_TP_CD AND
# MAGIC TGT.ARG_IP_PTY_TP_CD=SRC.ARG_IP_PTY_TP_CD AND
# MAGIC TGT.DEALER_NBR = SRC.DealerNumber AND
# MAGIC TGT.MFG_CD = SRC.MFG_CD AND
# MAGIC TGT.BRANCH_NBR = SRC.BranchNumber AND
# MAGIC TGT.DLR_TYPE_CD=SRC.DLR_TYPE_CD AND
# MAGIC TGT.MFG_TYPE_CD=SRC.MFG_TYPE_CD AND
# MAGIC TGT.PRODUCT_PLAN_CD = SRC.PRODUCT_PLAN_CD AND 
# MAGIC TGT.PRODUCT_PLAN_TYPE_CD = SRC.PRODUCT_PLAN_TYPE_CD AND
# MAGIC TGT.VERSION_NUMBER=SRC.VERSION_NUMBER AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD 
# MAGIC when matched then update set 
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC when not matched then insert 
# MAGIC  (INVOLVED_PARTY_REFERENCE,INVOLVED_PARTY_TP_CD,ARG_IP_PTY_TP_CD,DEALER_NBR,DLR_TYPE_CD,MFG_CD,MFG_TYPE_CD,
# MAGIC VERSION_NUMBER,PRODUCT_PLAN_CD,PRODUCT_PLAN_TYPE_CD,BRANCH_NBR,SUPPLIER_PLANT_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.InvolvedPartyReference,SRC.INVOLVED_PARTY_TP_CD,SRC.ARG_IP_PTY_TP_CD,SRC.DealerNumber,SRC.DLR_TYPE_CD,SRC.MFG_CD,SRC.MFG_TYPE_CD,
# MAGIC SRC.VERSION_NUMBER,SRC.PRODUCT_PLAN_CD,SRC.PRODUCT_PLAN_TYPE_CD,SRC.BranchNumber,SRC.SUPPLIER_PLANT_CD,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.arangmnt_involved_party_floor_plan_st