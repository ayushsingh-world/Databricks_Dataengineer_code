# Databricks notebook source
# MAGIC %sql
# MAGIC select * from  itda_io_dev.io_cml_brz.WS_IP_Credit_Facility_Rating_ST;

# COMMAND ----------

dbutils.fs.rm("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_IP_Credit_Facility_Rating_ST/",True)

# COMMAND ----------

from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-18'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_IP_CREDIT_FACILITY_RATING_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df.withColumnRenamed("involved_party_number","GSWId")
df.withColumnRenamed("involved_party_branch_number","Branch_Number")
df.withColumnRenamed("involved_party_type_cd","INVOLVED_PARTY_TYPE_CD")
df.withColumnRenamed("credit_facility_cd","CREDIT_FACILITY_CD")
df.withColumnRenamed("ratingvalue","RatingValue")
df.withColumnRenamed("rating_tp_cd","RATING_TP_CD")
df.withColumnRenamed("start_dt","START_DT")
df.withColumnRenamed("end","END_DT")
df.withColumnRenamed("lgdflatratepercent","LGD_PCT")
df.withColumnRenamed("osb","LGD_RATING_OSB_AMT")
df.withColumnRenamed("financialstatementid","REPORTPERIODID")
df.withColumnRenamed("ratingid","RATINGGROUPID")
df.withColumnRenamed("ratinghistoryid","RATINGHISTORYID")
df.withColumnRenamed("validfrom","VALID_FROM_DT")

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType

# COMMAND ----------

from pyspark.sql.functions import trim, to_date,date_sub,current_date

# COMMAND ----------

df = df.withColumn("GSWId", trim(df.involved_party_number))
df = df.withColumn("Branch_Number", trim(df.involved_party_branch_number))
df = df.withColumn("RatingValue", to_date(df.ratingvalue, "yyyy-MM-dd"))
df = df.withColumn("START_DT", to_date(df.start_dt))
df = df.withColumn("END_DT", to_date(df.end_dt, "yyyy-MM-dd"))
df = df.withColumn("LGD_PCT", (df.lgdflatratepercent).cast(DecimalType(38, 0)))
df = df.withColumn("LGD_RATING_OSB_AMT", (df.osb).cast(DecimalType(38, 0)))

# COMMAND ----------

df.createOrReplaceTempView("TEMP_IP_CFR_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
CREDIT_FACILITY_CD VARCHAR(50),
FINANCIAL_RI_REPORT_PERIOD_ID DECIMAL,
INVOLVED_PARTY_TYPE_CD VARCHAR(50),
RATING_TP_CD VARCHAR(50),
RATINGHISTORYID DECIMAL,
RATINGID DECIMAL,
RATINGVALUE DATE,
GSWId DECIMAL,
BRANCH_NUMBER DECIMAL,
LGD_RATING_OSB_AMT DECIMAL,
START_DT DATE,
END_DT DATE,
LGD_PCT	DECIMAL,
VALID_FROM_DT TIMESTAMP,
INSERT_TIMSTM TIMESTAMP ,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_IP_Credit_Facility_Rating_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_IP_Credit_Facility_Rating_ST AS TGT USING TEMP_IP_CFR_SIL AS SRC ON 
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.FINANCIALSTATEMENTID AND
# MAGIC TGT.GSWId = SRC.INVOLVED_PARTY_NUMBER AND
# MAGIC TGT.BRANCH_NUMBER = SRC.INVOLVED_PARTY_BRANCH_NUMBER AND
# MAGIC TGT.VALID_FROM_DT = SRC.VALIDFROM
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     TGT.CREDIT_FACILITY_CD = SRC.CREDIT_FACILITY_CD,
# MAGIC     TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.FINANCIALSTATEMENTID,
# MAGIC     TGT.INVOLVED_PARTY_TYPE_CD = SRC.INVOLVED_PARTY_TYPE_CD,
# MAGIC     TGT.RATING_TP_CD = SRC.RATING_TP_CD,
# MAGIC     TGT.RATINGHISTORYID = SRC.RATINGHISTORYID,
# MAGIC     TGT.RATINGID = SRC.RATINGID,
# MAGIC     TGT.RATINGVALUE = SRC.RATINGVALUE,
# MAGIC     TGT.GSWId = SRC.INVOLVED_PARTY_NUMBER,
# MAGIC     TGT.BRANCH_NUMBER = SRC.INVOLVED_PARTY_BRANCH_NUMBER,
# MAGIC     TGT.LGD_RATING_OSB_AMT = SRC.OSB,
# MAGIC     TGT.START_DT = SRC.START_DT,
# MAGIC     TGT.END_DT = SRC.END_DT,
# MAGIC     TGT.LGD_PCT	= SRC.LGDFLATRATEPERCENT,
# MAGIC     TGT.VALID_FROM_DT = SRC.VALIDFROM,
# MAGIC     TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.CREDIT_FACILITY_CD,TGT.FINANCIAL_RI_REPORT_PERIOD_ID, TGT.INVOLVED_PARTY_TYPE_CD, TGT.RATING_TP_CD, TGT.RATINGHISTORYID, TGT.RATINGID, TGT.RATINGVALUE, TGT.GSWId,TGT.BRANCH_NUMBER,TGT.LGD_RATING_OSB_AMT,TGT.START_DT,TGT.END_DT,TGT.LGD_PCT,TGT.VALID_FROM_DT,TGT.INSERT_TIMSTM)
# MAGIC   VALUES (SRC.CREDIT_FACILITY_CD,SRC.FINANCIALSTATEMENTID, SRC.INVOLVED_PARTY_TYPE_CD, SRC.RATING_TP_CD, SRC.RATINGHISTORYID,SRC.RATINGID, SRC.RATINGVALUE, SRC.INVOLVED_PARTY_NUMBER,SRC.INVOLVED_PARTY_BRANCH_NUMBER, SRC.OSB, SRC.START_DT, SRC.END_DT, SRC.LGDFLATRATEPERCENT, SRC.VALIDFROM,current_timestamp());