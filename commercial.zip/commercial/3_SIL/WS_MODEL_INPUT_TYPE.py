# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-18'

# COMMAND ----------

dbutils.ls("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz)

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.WS_MODEL_INPUT_TYPE_BT where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

df=spark.sql("select * from itda_io_dev.io_cml_brz.ws_model_input_type_bt")

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.withColumnRenamed("modelinputtypeid","CODE")\
  .withColumnRenamed("modelinputtypedescription","DESCRIPTION")\
  .withColumnRenamed("modelversiontypeid","MODELVERSIONTYPEID")\
  .withColumnRenamed("modelversion","VERSION")

# COMMAND ----------

df.withColumn("MODELVERSIONTYPEID",trim(df.modelversiontypeid))
df.withColumn("VERSION",trim(df.modelversion))

# COMMAND ----------

df.createOrReplaceTempView("TMP_MODEL_INPUT_TYPE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
CODE VARCHAR(255),
DESCRIPTION VARCHAR(255),
VERSION VARCHAR(255),
MODELVERSIONTYPEID VARCHAR(20),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_MODEL_INPUT_TYPE_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_MODEL_INPUT_TYPE_ST AS TGT USING TMP_MODEL_INPUT_TYPE_SIL AS SRC ON
# MAGIC TGT.CODE = SRC.modelinputtypeid AND
# MAGIC TGT.DESCRIPTION = SRC.modelinputtypedescription AND
# MAGIC TGT.VERSION = SRC.modelversion AND
# MAGIC TGT.MODELVERSIONTYPEID = SRC.modelversiontypeid
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC TGT.CODE = SRC.modelinputtypeid,
# MAGIC TGT.DESCRIPTION = SRC.modelinputtypedescription,
# MAGIC TGT.VERSION = SRC.modelversion,
# MAGIC TGT.MODELVERSIONTYPEID = SRC.modelversiontypeid,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.CODE,TGT.DESCRIPTION,TGT.VERSION,TGT.MODELVERSIONTYPEID,TGT.INSERT_TIMSTM)
# MAGIC   VALUES (SRC.modelinputtypeid, SRC.modelinputtypedescription, SRC.modelversion, SRC.modelversiontypeid,CURRENT_TIMESTAMP());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_model_input_type_st;