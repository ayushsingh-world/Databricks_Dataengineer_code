# Databricks notebook source
# MAGIC %sql
# MAGIC ---##drop table if exists itda_io_dev.io_cml_brz.WS_Customer_Obligor_ST

# COMMAND ----------

###dbutils.fs.ls("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_Customer_Obligor_ST")

# COMMAND ----------

###%fs
##rm -r abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_Customer_Obligor_ST

# COMMAND ----------

from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-18'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_customer_obligor_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

df=spark.sql("select * from itda_io_dev.io_cml_brz.ws_customer_obligor_bt")

# COMMAND ----------

display (df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.createOrReplaceTempView("TMP_customer_obligor_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
FINANCIAL_YEAR_END_DATE       DATE,
LAST_REVEIW_DT                  DATE,
NEXT_REVIEW_DATE                DATE,
REVIEWS_PER_YEAR_COUNT          DECIMAL(38),
CODE                             VARCHAR(50),
BRANCH_NUMBER                     VARCHAR(20),
INVOLVED_PARTY_INV_PTY_TP_CD       VARCHAR(50),
INDUSTRY_CLASSIFICATION_CD         VARCHAR(50),
STATE                              VARCHAR(50),
COUNTRY_NM                          VARCHAR(255),
UNION_COUNTRY_NM                    VARCHAR(255),
CITY                                DECIMAL(38),
ESTABLISHEDON                       VARCHAR(50),
COUNTY_NM                          VARCHAR(255),
CLIENT_ID                         VARCHAR(50),
Name                              VARCHAR(255),
ClientStatusTypeId               Integer,
ISLEGALENTITY                 Integer,
ISGROUP                        Integer,
BAC                          VARCHAR(255),
FORMOFBUSINESSCD             VARCHAR(50),
FORMOFBUSINESSDESC          VARCHAR(255),
BORROWERNBR                  VARCHAR(255),
ACCOUNT_TYPE_CD              VARCHAR(50),
CLIENT_TYPE_CD             VARCHAR(50),
CLIENT_SUB_TYPE_CD          VARCHAR(50),
TAX_ID                       VARCHAR(50),
ISDELETED                VARCHAR(255),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_Customer_Obligor_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_Customer_Obligor_ST AS TGT
# MAGIC USING TMP_customer_obligor_SIL AS SRC
# MAGIC ON 
# MAGIC     TGT.FINANCIAL_YEAR_END_DATE = SRC.fiscalyearend AND
# MAGIC     TGT.LAST_REVEIW_DT = SRC.lastreviewedon AND              
# MAGIC     TGT.NEXT_REVIEW_DATE = SRC.nextreviewon AND                   
# MAGIC     TGT.REVIEWS_PER_YEAR_COUNT = SRC.reviewsperyear AND                 
# MAGIC     TGT.CODE = SRC.involved_party_type_cd AND          
# MAGIC     TGT.BRANCH_NUMBER = SRC.involved_party_branch_number AND                 
# MAGIC     TGT.INVOLVED_PARTY_INV_PTY_TP_CD = SRC.involved_party_inv_pty_tp_cd AND         
# MAGIC     TGT.INDUSTRY_CLASSIFICATION_CD = SRC.industry_classification_cd AND                    
# MAGIC     TGT.STATE = SRC.state AND                    
# MAGIC     TGT.COUNTRY_NM = SRC.state AND           
# MAGIC     TGT.UNION_COUNTRY_NM = SRC.country_nm AND       
# MAGIC     TGT.CITY = SRC.cityname AND            
# MAGIC     TGT.ESTABLISHEDON = SRC.establishedon AND           
# MAGIC     TGT.COUNTY_NM = SRC.county_nm AND             
# MAGIC     TGT.CLIENT_ID = SRC.client_id AND          
# MAGIC     TGT.Name = SRC.name AND           
# MAGIC     TGT.ClientStatusTypeId = SRC.clientstatustypeid AND    
# MAGIC     TGT.ISLEGALENTITY = SRC.islegalentity AND
# MAGIC     TGT.ISGROUP = SRC.isgroup AND
# MAGIC     TGT.BAC = SRC.bac AND
# MAGIC     TGT.FORMOFBUSINESSCD = SRC.formofbusinessid AND   
# MAGIC     TGT.FORMOFBUSINESSDESC = SRC.formofbussinessdesc AND
# MAGIC     TGT.BORROWER_NBR = SRC.borrowernumber AND                 
# MAGIC     TGT.ACCOUNT_TYPE_CD = SRC.accounttypeid AND          
# MAGIC     TGT.CLIENT_TYPE_CD = SRC.clienttypeid AND
# MAGIC     TGT.CLIENT_SUB_TYPE_CD = SRC.clientsubtypeid AND
# MAGIC     TGT.TAX_ID = SRC.taxid AND
# MAGIC     TGT.ISDELETED = SRC.isdeleted
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC     INSERT (FINANCIAL_YEAR_END_DATE, LAST_REVEIW_DT, NEXT_REVIEW_DATE, REVIEWS_PER_YEAR_COUNT, CODE, BRANCH_NUMBER , INVOLVED_PARTY_INV_PTY_TP_CD, INDUSTRY_CLASSIFICATION_CD, STATE, COUNTRY_NM, UNION_COUNTRY_NM, CITY, ESTABLISHEDON, COUNTY_NM, CLIENT_ID, Name, ClientStatusTypeId, ISLEGALENTITY, ISGROUP, BAC, FORMOFBUSINESSCD, FORMOFBUSINESSDESC, BORROWER_NBR, ACCOUNT_TYPE_CD, CLIENT_TYPE_CD, CLIENT_SUB_TYPE_CD, TAX_ID, ISDELETED, INSERT_TIMSTM)
# MAGIC     VALUES (SRC.fiscalyearend, SRC.lastreviewedon, SRC.nextreviewon, SRC.reviewsperyear, SRC.involved_party_type_cd, SRC.involved_party_branch_number, SRC.involved_party_inv_pty_tp_cd, SRC.industry_classification_cd, SRC.state, SRC.country_nm, SRC.union_country_nm, SRC.cityname, SRC.establishedon, SRC.county_nm, SRC.client_id, SRC.name, SRC.clientstatustypeid, SRC.islegalentity, SRC.isgroup, SRC.bac, SRC.formofbusinessid, SRC.formofbussinessdesc, SRC.borrowernumber, SRC.accounttypeid, SRC.clienttypeid, SRC.clientsubtypeid, SRC.taxid, SRC.isdeleted, current_timestamp());
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_Customer_Obligor_ST AS TGT
# MAGIC USING TMP_customer_obligor_SIL AS SRC
# MAGIC ON 
# MAGIC TGT.FINANCIAL_YEAR_END_DATE     =   SRC.fiscalyearend   AND
# MAGIC TGT.LAST_REVEIW_DT             =     SRC.lastreviewedon   AND              
# MAGIC TGT.NEXT_REVIEW_DATE               =   SRC.nextreviewon   AND                   
# MAGIC TGT.REVIEWS_PER_YEAR_COUNT          =      SRC.reviewsperyear  AND                 
# MAGIC TGT.CODE                               =      SRC.involved_party_type_cd   AND          
# MAGIC TGT.BRANCH_NUMBER                       =   SRC.involved_party_branch_number  AND                 
# MAGIC TGT.INVOLVED_PARTY_INV_PTY_TP_CD        =      SRC.involved_party_inv_pty_tp_cd   AND         
# MAGIC TGT.INDUSTRY_CLASSIFICATION_CD  =                 SRC.industry_classification_cd    AND                    
# MAGIC TGT.STATE                    =                    SRC.state     AND                    
# MAGIC TGT.COUNTRY_NM                =                      SRC.state     AND           
# MAGIC TGT.UNION_COUNTRY_NM        =                          SRC.country_nm     AND       
# MAGIC TGT.CITY                     =                          SRC.cityname      AND            
# MAGIC TGT.ESTABLISHEDON             =                         SRC.establishedon     AND           
# MAGIC TGT.COUNTY_NM                =                             SRC.county_nm      AND             
# MAGIC TGT.CLIENT_ID                 =                         SRC.client_id      AND          
# MAGIC TGT.Name                        =                         SRC.name         AND           
# MAGIC TGT.ClientStatusTypeId         =                   SRC.clientstatustypeid      AND    
# MAGIC TGT.ISLEGALENTITY              =                   SRC.islegalentity  AND
# MAGIC TGT.ISGROUP                    =                      SRC.isgroup   AND
# MAGIC TGT.BAC                        =                SRC.bac       AND
# MAGIC TGT.FORMOFBUSINESSCD           =            SRC.formofbusinessid    AND   
# MAGIC TGT.FORMOFBUSINESSDESC          =          SRC.formofbussinessdesc     AND
# MAGIC TGT.BORROWER_NBR               =                      SRC.borrowernumber AND                 
# MAGIC TGT.ACCOUNT_TYPE_CD           =                   SRC.accounttypeid       AND          
# MAGIC TGT.CLIENT_TYPE_CD              =            SRC.clienttypeid       AND
# MAGIC TGT.CLIENT_SUB_TYPE_CD          =            SRC.clientsubtypeid       AND
# MAGIC TGT.TAX_ID                  =                SRC.taxid          AND        
# MAGIC TGT.ISDELETED              =                 SRC.isdeleted       
# MAGIC 	   WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC     TGT.EFFECTIVE_DT = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (FINANCIAL_YEAR_END_DATE, LAST_REVEIW_DT, NEXT_REVIEW_DATE, REVIEWS_PER_YEAR_COUNT, CODE, BRANCH_NUMBER , INVOLVED_PARTY_INV_PTY_TP_CD, INDUSTRY_CLASSIFICATION_CD, STATE, COUNTRY_NM, UNION_COUNTRY_NM, CITY, ESTABLISHEDON, COUNTY_NM, CLIENT_ID, Name, ClientStatusTypeId, ISLEGALENTITY, ISGROUP, BAC, FORMOFBUSINESSCD, FORMOFBUSINESSDESC, BORROWER_NBR, ACCOUNT_TYPE_CD, CLIENT_TYPE_CD, CLIENT_SUB_TYPE_CD, TAX_ID, EFFECTIVE_DT, ISDELETED)
# MAGIC   VALUES (SRC.fiscalyearend, SRC.lastreviewedon, SRC.nextreviewon, SRC.reviewsperyear, SRC.involved_party_type_cd, SRC.involved_party_branch_number, SRC.involved_party_inv_pty_tp_cd, SRC.industry_classification_cd, SRC.state, SRC.country_nm, SRC.union_country_nm, SRC.cityname, SRC.establishedon, SRC.county_nm, SRC.client_id, SRC.name, SRC.clientstatustypeid, SRC.islegalentity, SRC.isgroup, SRC.bac, SRC.formofbusinessid, SRC.formofbussinessdesc, SRC.borrowernumber, SRC.accounttypeid, SRC.clienttypeid, SRC.clientsubtypeid, SRC.taxid, current_timestamp(), SRC.isdeleted);