# Databricks notebook source
# MAGIC %sql
# MAGIC --drop table itda_io_dev.io_cml_brz.ws_guarantor_st
# MAGIC  ;

# COMMAND ----------

######dbutils.fs.ls("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/ws_Guarantor_st")

# COMMAND ----------

###%fs
###rm -r abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/ws_Guarantor_st

# COMMAND ----------

from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-01-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df_sql="""select * from itda_io_dev.io_cml_brz.ws_Guarantor_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df_sql)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim

# COMMAND ----------

from pyspark.sql.functions import trim

string_cols = [c for c, t in df.dtypes if t == 'string']
for colname in string_cols:
    df = df.withColumn(colname, trim(df[colname]))

# COMMAND ----------

display(df)

# COMMAND ----------

df.createOrReplaceTempView("TEMP_Guarantor")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
IP_TYPE_CD                     VARCHAR(50),
INVOLVED_PARTY_INV_PTY_TP_CD   VARCHAR(50),
THIRD_PARTY_TYPE_CD            VARCHAR(50),
BRANCH_NUMBER_GUARANTOR        VARCHAR(20),
CLIENT_ID_GUARANTOR            INTEGER,
TAX_ID                         VARCHAR(20),
GUARANTOR_NM                   VARCHAR(255),
EMAIL_ADDRESS                  VARCHAR(255),
INDUSTRY_CLASSIFICATION_CD     VARCHAR(50),
STATE                          VARCHAR(50),
COUNTRY_NM                     VARCHAR(50),
UNION_COUNTRY_NM               VARCHAR(50),
CITY                           VARCHAR(50),
ESTABLISHEDON                  VARCHAR(10),
COUNTY_NM                      VARCHAR(50),
GUARANTOR_TYPE_CD              VARCHAR(50),
GUARANTOR_TYPE_DESC            VARCHAR(255),
GUARANTOR_ACTIVE_IND           INTEGER,
GUARANTOR_SPOUSE_NM            VARCHAR(255),
COUNTRY_OF_RESIDENCE           VARCHAR(255),
GUARANTOR_ROLE_DESC            VARCHAR(255),
GUARANTOR_ROLE_ID              VARCHAR(50),
RELATIONSHIP_TO_BORROWER_CD    VARCHAR(255),
RELATIONSHIP_TO_BORROWER_DESC  VARCHAR(255),
OWNER_PCT                      DECIMAL(38),
SPOUSAL_GUARANTEE_IND          INTEGER,
GUARANTEE_START_DT             VARCHAR(10),
WHOLSESALE_SUPPORT_IND         INTEGER,
LOAN_SUPPORT_IND               INTEGER,
EXPIRATION_DT                  VARCHAR(10),
CCCDCG_IND                     INTEGER,
STATED_NET_WORTH_AMT           DECIMAL(38),
LIMIT_AMT                      DECIMAL(38),
BRANCH_NUMBER_DEALER           VARCHAR(20),
INVOLVDED_PARTY_TYPE           VARCHAR(50),
CLIENT_ID_DEALER               VARCHAR(20),
GUARANTEE_NUMBER               INTEGER,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ws_Guarantor_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_Guarantor_st AS TGT
# MAGIC USING TEMP_Guarantor AS SRC
# MAGIC ON 
# MAGIC   TGT.IP_TYPE_CD = SRC.ip_type_cd AND
# MAGIC   TGT.INVOLVED_PARTY_INV_PTY_TP_CD = SRC.involved_party_inv_pty_tp_cd AND
# MAGIC   TGT.THIRD_PARTY_TYPE_CD = SRC.third_party_type_cd AND
# MAGIC   TGT.BRANCH_NUMBER_GUARANTOR = SRC.branch_number_guarantor AND
# MAGIC   TGT.CLIENT_ID_GUARANTOR = SRC.client_id_guarantor AND
# MAGIC   TGT.TAX_ID = SRC.tax_id AND
# MAGIC   TGT.GUARANTOR_NM = SRC.guarantor_nm AND
# MAGIC   TGT.EMAIL_ADDRESS = SRC.email_address AND
# MAGIC   TGT.INDUSTRY_CLASSIFICATION_CD = SRC.industry_classification_cd AND
# MAGIC   TGT.STATE = SRC.state AND
# MAGIC   TGT.COUNTRY_NM = SRC.country_nm AND
# MAGIC   TGT.UNION_COUNTRY_NM = SRC.union_country_nm AND
# MAGIC   TGT.CITY = SRC.city AND
# MAGIC   TGT.ESTABLISHEDON = SRC.establishedon AND
# MAGIC   TGT.COUNTY_NM = SRC.county_nm AND
# MAGIC   TGT.GUARANTOR_TYPE_CD = SRC.guarantor_type_cd AND
# MAGIC   TGT.GUARANTOR_TYPE_DESC = SRC.guarantor_type_desc AND
# MAGIC   TGT.GUARANTOR_ACTIVE_IND = SRC.guarantor_active_ind AND
# MAGIC   TGT.GUARANTOR_SPOUSE_NM = SRC.guarantor_spouse_nm AND
# MAGIC   TGT.COUNTRY_OF_RESIDENCE = SRC.country_of_residence AND
# MAGIC   TGT.GUARANTOR_ROLE_DESC = SRC.guarantor_role_desc AND
# MAGIC   TGT.GUARANTOR_ROLE_ID = SRC.guarantor_role_id AND
# MAGIC   TGT.RELATIONSHIP_TO_BORROWER_CD = SRC.relationship_to_borrower_cd AND
# MAGIC   TGT.RELATIONSHIP_TO_BORROWER_DESC = SRC.relationship_to_borrower_desc AND
# MAGIC   TGT.OWNER_PCT = SRC.owner_pct AND
# MAGIC   TGT.SPOUSAL_GUARANTEE_IND = SRC.spousal_guarantee_ind AND
# MAGIC   TGT.GUARANTEE_START_DT = SRC.guarantee_start_dt AND
# MAGIC   TGT.WHOLSESALE_SUPPORT_IND = SRC.wholsesale_support_ind AND
# MAGIC   TGT.LOAN_SUPPORT_IND = SRC.loan_support_ind AND
# MAGIC   TGT.EXPIRATION_DT = SRC.expiration_dt AND
# MAGIC   TGT.CCCDCG_IND = SRC.cccdcg_ind AND
# MAGIC   TGT.STATED_NET_WORTH_AMT = SRC.stated_net_worth_amt AND
# MAGIC   TGT.LIMIT_AMT = SRC.limit_amt AND
# MAGIC   TGT.BRANCH_NUMBER_DEALER = SRC.branch_number_dealer AND
# MAGIC   TGT.INVOLVDED_PARTY_TYPE = SRC.involved_party_type AND
# MAGIC   TGT.CLIENT_ID_DEALER = SRC.client_id_dealer AND
# MAGIC   TGT.GUARANTEE_NUMBER = SRC.guarantee_number
# MAGIC   
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC     TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (IP_TYPE_CD, INVOLVED_PARTY_INV_PTY_TP_CD, THIRD_PARTY_TYPE_CD, BRANCH_NUMBER_GUARANTOR, CLIENT_ID_GUARANTOR, TAX_ID, GUARANTOR_NM, EMAIL_ADDRESS, INDUSTRY_CLASSIFICATION_CD, STATE, COUNTRY_NM, UNION_COUNTRY_NM, CITY, ESTABLISHEDON, COUNTY_NM, GUARANTOR_TYPE_CD, GUARANTOR_TYPE_DESC, GUARANTOR_ACTIVE_IND, GUARANTOR_SPOUSE_NM, COUNTRY_OF_RESIDENCE, GUARANTOR_ROLE_DESC, GUARANTOR_ROLE_ID, RELATIONSHIP_TO_BORROWER_CD, RELATIONSHIP_TO_BORROWER_DESC, OWNER_PCT, SPOUSAL_GUARANTEE_IND, GUARANTEE_START_DT, WHOLSESALE_SUPPORT_IND, LOAN_SUPPORT_IND, EXPIRATION_DT, CCCDCG_IND, STATED_NET_WORTH_AMT, LIMIT_AMT, BRANCH_NUMBER_DEALER, INVOLVDED_PARTY_TYPE, CLIENT_ID_DEALER, GUARANTEE_NUMBER, INSERT_TIMSTM
# MAGIC )
# MAGIC   VALUES (SRC.ip_type_cd, SRC.involved_party_inv_pty_tp_cd, SRC.third_party_type_cd, SRC.branch_number_guarantor, SRC.client_id_guarantor, SRC.tax_id, SRC.guarantor_nm, SRC.email_address, SRC.industry_classification_cd, SRC.state, SRC.country_nm, SRC.union_country_nm, SRC.city, SRC.establishedon, SRC.county_nm, SRC.guarantor_type_cd, SRC.guarantor_type_desc, SRC.guarantor_active_ind, SRC.guarantor_spouse_nm, SRC.country_of_residence, SRC.guarantor_role_desc, SRC.guarantor_role_id, SRC.relationship_to_borrower_cd, SRC.relationship_to_borrower_desc, SRC.owner_pct, SRC.spousal_guarantee_ind, SRC.guarantee_start_dt, SRC.wholsesale_support_ind, SRC.loan_support_ind, SRC.expiration_dt, SRC.cccdcg_ind, SRC.stated_net_worth_amt, SRC.limit_amt, SRC.branch_number_dealer, SRC.involved_party_type, SRC.client_id_dealer, SRC.guarantee_number,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_Guarantor_st AS TGT
# MAGIC USING TEMP_Guarantor AS SRC
# MAGIC ON 
# MAGIC   TGT.IP_TYPE_CD = SRC.ip_type_cd AND
# MAGIC   TGT.INVOLVED_PARTY_INV_PTY_TP_CD = SRC.involved_party_inv_pty_tp_cd AND
# MAGIC   TGT.THIRD_PARTY_TYPE_CD = SRC.third_party_type_cd AND
# MAGIC   TGT.BRANCH_NUMBER_GUARANTOR = SRC.branch_number_guarantor AND
# MAGIC   TGT.CLIENT_ID_GUARANTOR = SRC.client_id_guarantor AND
# MAGIC   TGT.TAX_ID = SRC.tax_id AND
# MAGIC   TGT.GUARANTOR_NM = SRC.guarantor_nm AND
# MAGIC   TGT.EMAIL_ADDRESS = SRC.email_address AND
# MAGIC   TGT.INDUSTRY_CLASSIFICATION_CD = SRC.industry_classification_cd AND
# MAGIC   TGT.STATE = SRC.state AND
# MAGIC   TGT.COUNTRY_NM = SRC.country_nm AND
# MAGIC   TGT.UNION_COUNTRY_NM = SRC.union_country_nm AND
# MAGIC   TGT.CITY = SRC.city AND
# MAGIC   TGT.ESTABLISHEDON = SRC.establishedon AND
# MAGIC   TGT.COUNTY_NM = SRC.county_nm AND
# MAGIC   TGT.GUARANTOR_TYPE_CD = SRC.guarantor_type_cd AND
# MAGIC   TGT.GUARANTOR_TYPE_DESC = SRC.guarantor_type_desc AND
# MAGIC   TGT.GUARANTOR_ACTIVE_IND = SRC.guarantor_active_ind AND
# MAGIC   TGT.GUARANTOR_SPOUSE_NM = SRC.guarantor_spouse_nm AND
# MAGIC   TGT.COUNTRY_OF_RESIDENCE = SRC.country_of_residence AND
# MAGIC   TGT.GUARANTOR_ROLE_DESC = SRC.guarantor_role_desc AND
# MAGIC   TGT.GUARANTOR_ROLE_ID = SRC.guarantor_role_id AND
# MAGIC   TGT.RELATIONSHIP_TO_BORROWER_CD = SRC.relationship_to_borrower_cd AND
# MAGIC   TGT.RELATIONSHIP_TO_BORROWER_DESC = SRC.relationship_to_borrower_desc AND
# MAGIC   TGT.OWNER_PCT = try_cast(SRC.owner_pct AS DECIMAL(38)) AND
# MAGIC   TGT.SPOUSAL_GUARANTEE_IND = SRC.spousal_guarantee_ind AND
# MAGIC   TGT.GUARANTEE_START_DT = SRC.guarantee_start_dt AND
# MAGIC   TGT.WHOLSESALE_SUPPORT_IND = SRC.wholsesale_support_ind AND
# MAGIC   TGT.LOAN_SUPPORT_IND = SRC.loan_support_ind AND
# MAGIC   TGT.EXPIRATION_DT = SRC.expiration_dt AND
# MAGIC   TGT.CCCDCG_IND = SRC.cccdcg_ind AND
# MAGIC   TGT.STATED_NET_WORTH_AMT = try_cast(SRC.stated_net_worth_amt AS DECIMAL(38)) AND
# MAGIC   TGT.LIMIT_AMT = try_cast(SRC.limit_amt AS DECIMAL(38)) AND
# MAGIC   TGT.BRANCH_NUMBER_DEALER = SRC.branch_number_dealer AND
# MAGIC   TGT.INVOLVDED_PARTY_TYPE = SRC.involved_party_type AND
# MAGIC   TGT.CLIENT_ID_DEALER = SRC.client_id_dealer AND
# MAGIC   TGT.GUARANTEE_NUMBER = SRC.guarantee_number
# MAGIC   
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC     TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (
# MAGIC     IP_TYPE_CD, INVOLVED_PARTY_INV_PTY_TP_CD, THIRD_PARTY_TYPE_CD, BRANCH_NUMBER_GUARANTOR, CLIENT_ID_GUARANTOR, TAX_ID, 
# MAGIC     GUARANTOR_NM, EMAIL_ADDRESS, INDUSTRY_CLASSIFICATION_CD, STATE, COUNTRY_NM, UNION_COUNTRY_NM, CITY, ESTABLISHEDON, 
# MAGIC     COUNTY_NM, GUARANTOR_TYPE_CD, GUARANTOR_TYPE_DESC, GUARANTOR_ACTIVE_IND, GUARANTOR_SPOUSE_NM, COUNTRY_OF_RESIDENCE, 
# MAGIC     GUARANTOR_ROLE_DESC, GUARANTOR_ROLE_ID, RELATIONSHIP_TO_BORROWER_CD, RELATIONSHIP_TO_BORROWER_DESC, OWNER_PCT, 
# MAGIC     SPOUSAL_GUARANTEE_IND, GUARANTEE_START_DT, WHOLSESALE_SUPPORT_IND, LOAN_SUPPORT_IND, EXPIRATION_DT, CCCDCG_IND, 
# MAGIC     STATED_NET_WORTH_AMT, LIMIT_AMT, BRANCH_NUMBER_DEALER, INVOLVDED_PARTY_TYPE, CLIENT_ID_DEALER, GUARANTEE_NUMBER, 
# MAGIC     INSERT_TIMSTM
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     SRC.ip_type_cd, SRC.involved_party_inv_pty_tp_cd, SRC.third_party_type_cd, SRC.branch_number_guarantor, 
# MAGIC     SRC.client_id_guarantor, SRC.tax_id, SRC.guarantor_nm, SRC.email_address, SRC.industry_classification_cd, 
# MAGIC     SRC.state, SRC.country_nm, SRC.union_country_nm, SRC.city, SRC.establishedon, SRC.county_nm, 
# MAGIC     SRC.guarantor_type_cd, SRC.guarantor_type_desc, SRC.guarantor_active_ind, SRC.guarantor_spouse_nm, 
# MAGIC     SRC.country_of_residence, SRC.guarantor_role_desc, SRC.guarantor_role_id, SRC.relationship_to_borrower_cd, 
# MAGIC     SRC.relationship_to_borrower_desc, try_cast(SRC.owner_pct AS DECIMAL(38)), SRC.spousal_guarantee_ind, 
# MAGIC     SRC.guarantee_start_dt, SRC.wholsesale_support_ind, SRC.loan_support_ind, SRC.expiration_dt, 
# MAGIC     SRC.cccdcg_ind, try_cast(SRC.stated_net_worth_amt AS DECIMAL(38)), try_cast(SRC.limit_amt AS DECIMAL(38)), 
# MAGIC     SRC.branch_number_dealer, SRC.involved_party_type, SRC.client_id_dealer, SRC.guarantee_number, 
# MAGIC     current_timestamp()
# MAGIC   )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_Guarantor_st;