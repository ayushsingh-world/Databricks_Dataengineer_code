# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_MAKE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("DESCRIPTION", when(df.Description.isNull(),"NA") \
    .when(df.Description=="","NA") \
    .otherwise(df.Description))
df=df.withColumn("MAKECODE", when(df.MakeCode.isNull(),"NA") \
    .when(df.MakeCode=="","NA") \
    .otherwise(df.MakeCode))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_MAKE_SIL")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from TEMP_MAKE_SIL;

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
DESCRIPTION				VARCHAR(50),
MAKECODE                VARCHAR(50) NOT NULL,
MANUFACTURERId          VARCHAR(255) NOT NULL,
BRANCH_NBR              VARCHAR(20) NOT NULL,
TYPE_CD                 VARCHAR(200) NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='GSW_MAKE' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.GSW_MAKE USING TEMP_MAKE_SIL ON 
# MAGIC GSW_MAKE.MANUFACTURERId = TEMP_MAKE_SIL.MANUFACTURERId AND
# MAGIC GSW_MAKE.BRANCH_NBR = TEMP_MAKE_SIL.BRANCH_NUMBER AND
# MAGIC GSW_MAKE.TYPE_CD = TEMP_MAKE_SIL.TYPE_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET    
# MAGIC GSW_MAKE.DESCRIPTION = TEMP_MAKE_SIL.DESCRIPTION,
# MAGIC GSW_MAKE.MAKECODE = TEMP_MAKE_SIL.MAKECODE,
# MAGIC GSW_MAKE.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (DESCRIPTION,MAKECODE,MANUFACTURERId,TYPE_CD,BRANCH_NBR,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (TEMP_MAKE_SIL.DESCRIPTION,TEMP_MAKE_SIL.MAKECODE,TEMP_MAKE_SIL.MANUFACTURERId,TEMP_MAKE_SIL.TYPE_CD,TEMP_MAKE_SIL.BRANCH_NUMBER,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.GSW_MAKE

# COMMAND ----------

