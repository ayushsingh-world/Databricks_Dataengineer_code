# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_involved_party_risk_rating_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df = df.withColumn("approveddate", 
                   when((df.approveddate.isNotNull()) & (df.approveddate != ""), df.approveddate)
                   .otherwise('1900-01-01'))
df=df.withColumn("rating_tp_cd", when((df.rating_tp_cd=="RRR-GSW") & ((df.riskratingcode=="L")|(df.riskratingcode=="S")|(df.riskratingcode=="P")),"DCC").otherwise(df.rating_tp_cd))
df=df.withColumn("riskratingcode", when(df.riskratingcode=="NA","NR").otherwise(df.riskratingcode))

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format
df = df.withColumn("approveddate",to_date(col("approveddate"),"yyyy-mm-dd"))

# COMMAND ----------

df.withColumnRenamed("approveddate","CREATEDATE")\
  .withColumnRenamed("financialstatementid","REPORTPERIODID")\
  .withColumnRenamed("involved_party_branch_number","BRANCHNUMBER")\
  .withColumnRenamed("involved_party_number","GSWID")\
  .withColumnRenamed("involved_party_type_cd","INVOLVED_PARTY_TYPE_CD")\
  .withColumnRenamed("rating_tp_cd","RATING_TP_CD")\
  .withColumnRenamed("ratinghistoryid","RATINGHISTORYID")\
  .withColumnRenamed("ratingid","RATINGGROUPID")\
  .withColumnRenamed("riskratingcode","RATINGVALUE")\
  .withColumnRenamed("validfrom","VALID_FROM_DT")

# COMMAND ----------

df.createOrReplaceTempView("TMP_IP_RISK_RATING_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
RATING_TP_CD                      VARCHAR(50),
RATINGVALUE					      VARCHAR(50),
GSWID							  VARCHAR(50),
BRANCHNUMBER					  VARCHAR(50),
CREATEDATE						  DATE,
INVOLVED_PARTY_TYPE_CD			  VARCHAR(50),
FINANCIAL_RI_REPORT_PERIOD_ID     INTEGER,
RISK_RATING_GROUP_ID			  INTEGER,
RISK_RATING_HISTORY_ID			  INTEGER,
VALID_FROM_DT				      DATE,
INSERT_TIMSTM                     TIMESTAMP,
UPDATE_TIMSTM                     TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ws_involved_party_risk_rating_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_involved_party_risk_rating_st AS TGT USING TMP_IP_RISK_RATING_SIL AS SRC ON
# MAGIC TGT.GSWID = SRC.involved_party_number AND
# MAGIC TGT.RATING_TP_CD = SRC.rating_tp_cd AND
# MAGIC TGT.RATINGVALUE = SRC.riskratingcode AND
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number AND
# MAGIC TGT.CREATEDATE = SRC.approveddate AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.involved_party_type_cd AND
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.financialstatementid AND
# MAGIC TGT.RISK_RATING_GROUP_ID = SRC.ratingid AND
# MAGIC TGT.RISK_RATING_HISTORY_ID = SRC.ratinghistoryid AND
# MAGIC TGT.VALID_FROM_DT = SRC.validfrom
# MAGIC WHEN MATCHED THEN 
# MAGIC UPDATE SET
# MAGIC TGT.GSWID = SRC.involved_party_number,
# MAGIC TGT.RISK_RATING_GROUP_ID = SRC.ratingid, 
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.financialstatementid,
# MAGIC TGT.RISK_RATING_HISTORY_ID = SRC.ratinghistoryid,
# MAGIC TGT.VALID_FROM_DT = SRC.validfrom,
# MAGIC TGT.RATING_TP_CD = SRC.rating_tp_cd,
# MAGIC TGT.RATINGVALUE = SRC.riskratingcode,
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number,
# MAGIC TGT.CREATEDATE = SRC.approveddate,
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD = SRC.involved_party_type_cd,
# MAGIC TGT.UPDATE_TIMSTM = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.RATING_TP_CD ,TGT.RATINGVALUE,TGT.GSWID,TGT.BRANCHNUMBER,TGT.CREATEDATE,TGT.INVOLVED_PARTY_TYPE_CD,TGT.FINANCIAL_RI_REPORT_PERIOD_ID,
# MAGIC   TGT.RISK_RATING_GROUP_ID,TGT.RISK_RATING_HISTORY_ID,TGT.VALID_FROM_DT,TGT.INSERT_TIMSTM)
# MAGIC 	    VALUES (SRC.rating_tp_cd ,SRC.riskratingcode,SRC.involved_party_number,SRC.involved_party_branch_number,SRC.approveddate,SRC.involved_party_type_cd,SRC.financialstatementid,
# MAGIC       SRC.ratingid,SRC.ratinghistoryid,SRC.validfrom,CURRENT_TIMESTAMP());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_involved_party_risk_rating_st;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from TMP_IP_RISK_RATING_SIL;