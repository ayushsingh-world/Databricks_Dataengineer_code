# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_ARANGMNT_RATE_TYPE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("START_DT", when(df.START_DT.isNull(),"1900-01-01") \
    .when(df.START_DT=="","1900-01-01") \
    .otherwise(df.START_DT))
df=df.withColumn("END_DT", when(df.END_DT.isNull(),"1900-01-01") \
    .when(df.END_DT=="","1900-01-01") \
    .otherwise(df.END_DT))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_ARANGMNT_RATE_TYPE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ACCOUNT_NBR             VARCHAR(20) NOT NULL,
RATE_TYPE_CD            VARCHAR(50) NOT NULL,
RATE_BASIS_CD           VARCHAR(50) NOT NULL,
START_DT                VARCHAR(10),
END_DT                  VARCHAR(10),
RATE_VALUE              DECIMAL(10,6) NOT NULL,
BRANCH_NUMBER           VARCHAR(20) NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='GSW_ARANGMNT_RATE_TYPE_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.GSW_ARANGMNT_RATE_TYPE_ST as TGT USING TEMP_ARANGMNT_RATE_TYPE_SIL as SRC ON 
# MAGIC TGT.ACCOUNT_NBR = SRC.ACCOUNT_NBR AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.RATE_TYPE_CD = SRC.RATE_TYPE_CD,
# MAGIC TGT.RATE_BASIS_CD = SRC.RATE_BASIS_CD,
# MAGIC TGT.START_DT = SRC.START_DT,
# MAGIC TGT.END_DT = SRC.END_DT,
# MAGIC TGT.RATE_VALUE = SRC.RATE_VALUE,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (ACCOUNT_NBR,RATE_TYPE_CD,RATE_BASIS_CD,START_DT,END_DT,RATE_VALUE,BRANCH_NUMBER,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.ACCOUNT_NBR,SRC.RATE_TYPE_CD,SRC.RATE_BASIS_CD,SRC.START_DT,SRC.END_DT,SRC.RATE_VALUE,SRC.BRANCH_NUMBER,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.arangmnt_rate_type_st 

# COMMAND ----------

df = spark.sql(f'''select * from itda_io_dev.io_cml_brz.Txn_Ev_Dlr_Charges_st''')
df.exceptAll(df.dropDuplicates()).show()
 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.txn_ev_dlr_charges_st where DealerNumber='3386'