# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_txn_ev_plan_change_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.functions import *
from pyspark.sql.functions import when


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

df=df.withColumn("VIN", when(df.VIN.isNull(),"NA") \
    .when(df.VIN=="","NA") \
    .otherwise(df.VIN))
df=df.withColumn("PLAN_TRANSFER_DT", when(df.PLAN_TRANSFER_DT.isNull(),"1900-01-01") \
    .when(df.PLAN_TRANSFER_DT=="","1900-01-01") \
    .otherwise(df.PLAN_TRANSFER_DT))
df=df.withColumn("PLAN_CHANGE_REASON_CD", when(df.PLAN_CHANGE_REASON_CD.isNull(),"NA") \
    .when(df.PLAN_CHANGE_REASON_CD=="","NA") \
    .otherwise(df.PLAN_CHANGE_REASON_CD))
df=df.withColumn("NEW_PLAN_CD", when(df.NEW_PLAN_CD.isNull(),"NA") \
    .when(df.NEW_PLAN_CD=="","NA") \
    .otherwise(df.NEW_PLAN_CD))
df=df.withColumn("OLD_PLN_CD", when(df.OLD_PLN_CD.isNull(),"NA") \
    .when(df.OLD_PLN_CD=="","NA") \
    .otherwise(df.OLD_PLN_CD))
df=df.withColumn("OLD_PLAN_START_DT", when(df.OLD_PLAN_START_DT.isNull(),"1900-01-01") \
    .when(df.OLD_PLAN_START_DT=="","1900-01-01") \
    .otherwise(df.OLD_PLAN_START_DT))
df=df.withColumn("OLD_FLAT_CHARGE_START_DT", when(df.OLD_FLAT_CHARGE_START_DT.isNull(),"1900-01-01") \
    .when(df.OLD_FLAT_CHARGE_START_DT=="","1900-01-01") \
    .otherwise(df.OLD_FLAT_CHARGE_START_DT))
df=df.withColumn("OLD_INTEREST_START_DT", when(df.OLD_INTEREST_START_DT.isNull(),"1900-01-01") \
    .when(df.OLD_INTEREST_START_DT=="","1900-01-01") \
    .otherwise(df.OLD_INTEREST_START_DT))
df=df.withColumn("OLD_SUPPORT_END_DT", when(df.OLD_SUPPORT_END_DT.isNull(),"1900-01-01") \
    .when(df.OLD_SUPPORT_END_DT=="","1900-01-01") \
    .otherwise(df.OLD_SUPPORT_END_DT))
df=df.withColumn("NEW_PRELIMINARY_FIANANCE_IND", when(df.NEW_PRELIMINARY_FIANANCE_IND.isNull(),"NA") \
    .when(df.NEW_PRELIMINARY_FIANANCE_IND=="","NA") \
    .otherwise(df.NEW_PRELIMINARY_FIANANCE_IND))
df=df.withColumn("TRANSFER_GL_DT", when(df.TRANSFER_GL_DT.isNull(),"1900-01-01") \
    .when(df.TRANSFER_GL_DT=="","1900-01-01") \
    .otherwise(df.TRANSFER_GL_DT))
df=df.withColumn("OLD_FLAT_CHARGE_END_DT", when(df.OLD_FLAT_CHARGE_END_DT.isNull(),"1900-01-01") \
    .when(df.OLD_FLAT_CHARGE_END_DT=="","1900-01-01") \
    .otherwise(df.OLD_FLAT_CHARGE_END_DT))
df=df.withColumn("OLD_FLAT_CHARGE_PNT_DT", when(df.OLD_FLAT_CHARGE_PNT_DT.isNull(),"1900-01-01") \
    .when(df.OLD_FLAT_CHARGE_PNT_DT=="","1900-01-01") \
    .otherwise(df.OLD_FLAT_CHARGE_PNT_DT))
df=df.withColumn("OLD_VOLUME_TYPE_CD", when(df.OLD_VOLUME_TYPE_CD.isNull(),"NA") \
    .when(df.OLD_VOLUME_TYPE_CD=="","NA") \
    .otherwise(df.OLD_VOLUME_TYPE_CD)) 
df=df.withColumn("OLD_IB_FLAT_CHARGE_DT", when(df.OLD_IB_FLAT_CHARGE_DT.isNull(),"1900-01-01") \
    .when(df.OLD_IB_FLAT_CHARGE_DT=="","1900-01-01") \
    .otherwise(df.OLD_IB_FLAT_CHARGE_DT))
df=df.withColumn("OUTSTANDING_BALANCE_AMT", when(df.OUTSTANDING_BALANCE_AMT.isNull(),"NA") \
    .when(df.OUTSTANDING_BALANCE_AMT=="","NA") \
    .otherwise(df.OUTSTANDING_BALANCE_AMT))  

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_TXN_EV_PLAN_CHANGE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ORGANIZATION_UNIT_NBR	        VarChar(20),	
VIN	                          VarChar(20) Not Null,
PLAN_TRANSFER_DT	            Timestamp	Not Null,
PLAN_CHANGE_REASON_CD	        VarChar(50) Not Null,
NEW_DLR_NO	                  VarChar(50),	
NEW_PLAN_CD	                  VarChar(50) Not Null,
OLD_DLR_NO	                  VarChar(50),	
OLD_PLN_CD	                  VarChar(50) Not Null,
OLD_PLAN_START_DT	            Date Not Null,
OLD_FLAT_CHARGE_START_DT	    Date Not Null,
OLD_INTEREST_START_DT	        Date Not Null,
OLD_SUPPORT_END_DT	          Date Not Null,
NEW_PRELIMINARY_FIANANCE_IND  Integer Not Null,
TRANSFER_GL_DT	              Date Not Null,
OLD_FLAT_CHARGE_END_DT	      Date Not Null,
OLD_FLAT_CHARGE_PNT_DT	      Date Not Null,
OLD_SPT_END_DT1	              VarChar(10),
OLD_SPT_END_DT2	              VarChar(10),
OLD_VOLUME_TYPE_CD	          VarChar(50) Not Null,
OLD_IB_FLAT_CHARGE_DT	        Date Not Null,
OLD_SUPPLIER_PLANT_CD	        VarChar(50),	
OUTSTANDING_BALANCE_AMT	      Decimal(38,2) Not Null,
INSERT_TIMSTM                 TIMESTAMP,
UPDATE_TIMSTM                 TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='TXN_EVN_PLAN_CHANGE_EVENT_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.TXN_EVN_PLAN_CHANGE_EVENT_ST as TGT USING TEMP_TXN_EV_PLAN_CHANGE_SIL as SRC ON 
# MAGIC TGT.ORGANIZATION_UNIT_NBR =	SRC.ORGANIZATION_UNIT_NBR AND	
# MAGIC TGT.NEW_DLR_NO = SRC.NEW_DLR_NO	AND
# MAGIC TGT.OLD_DLR_NO = SRC.OLD_DLR_NO	AND
# MAGIC TGT.OUTSTANDING_BALANCE_AMT	= SRC.OUTSTANDING_BALANCE_AMT 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.VIN = SRC.VIN,		
# MAGIC TGT.PLAN_TRANSFER_DT = SRC.PLAN_TRANSFER_DT,
# MAGIC TGT.PLAN_CHANGE_REASON_CD = SRC.PLAN_CHANGE_REASON_CD,	
# MAGIC TGT.NEW_PLAN_CD = SRC.NEW_PLAN_CD, 		
# MAGIC TGT.OLD_PLN_CD = SRC.OLD_PLN_CD,	
# MAGIC TGT.OLD_PLAN_START_DT = SRC.OLD_PLAN_START_DT,		
# MAGIC TGT.OLD_FLAT_CHARGE_START_DT = SRC.OLD_FLAT_CHARGE_START_DT,		
# MAGIC TGT.OLD_INTEREST_START_DT = SRC.OLD_INTEREST_START_DT,		
# MAGIC TGT.OLD_SUPPORT_END_DT = SRC.OLD_SUPPORT_END_DT,		
# MAGIC TGT.NEW_PRELIMINARY_FIANANCE_IND = SRC.NEW_PRELIMINARY_FIANANCE_IND,		
# MAGIC TGT.TRANSFER_GL_DT = SRC.TRANSFER_GL_DT,		
# MAGIC TGT.OLD_FLAT_CHARGE_END_DT = SRC.OLD_FLAT_CHARGE_END_DT,		
# MAGIC TGT.OLD_FLAT_CHARGE_PNT_DT = SRC.OLD_FLAT_CHARGE_PNT_DT,		
# MAGIC TGT.OLD_SPT_END_DT1 = SRC.OLD_SPT_END_DT1,		
# MAGIC TGT.OLD_SPT_END_DT2 = SRC.OLD_SPT_END_DT2,		
# MAGIC TGT.OLD_VOLUME_TYPE_CD = SRC.OLD_VOLUME_TYPE_CD,		
# MAGIC TGT.OLD_IB_FLAT_CHARGE_DT = SRC.OLD_IB_FLAT_CHARGE_DT,		
# MAGIC TGT.OLD_SUPPLIER_PLANT_CD = SRC.OLD_SUPPLIER_PLANT_CD,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (ORGANIZATION_UNIT_NBR,VIN,PLAN_TRANSFER_DT,PLAN_CHANGE_REASON_CD,NEW_DLR_NO,NEW_PLAN_CD,OLD_DLR_NO,OLD_PLN_CD,
# MAGIC  OLD_PLAN_START_DT,OLD_FLAT_CHARGE_START_DT,OLD_INTEREST_START_DT,OLD_SUPPORT_END_DT,NEW_PRELIMINARY_FIANANCE_IND,TRANSFER_GL_DT,
# MAGIC  OLD_FLAT_CHARGE_END_DT,OLD_FLAT_CHARGE_PNT_DT,OLD_SPT_END_DT1,OLD_SPT_END_DT2,OLD_VOLUME_TYPE_CD,OLD_IB_FLAT_CHARGE_DT,OLD_SUPPLIER_PLANT_CD,OUTSTANDING_BALANCE_AMT,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.ORGANIZATION_UNIT_NBR,SRC.VIN,SRC.PLAN_TRANSFER_DT,SRC.PLAN_CHANGE_REASON_CD,SRC.NEW_DLR_NO,SRC.NEW_PLAN_CD,SRC.OLD_DLR_NO,
# MAGIC SRC.OLD_PLN_CD,SRC.OLD_PLAN_START_DT,SRC.OLD_FLAT_CHARGE_START_DT,SRC.OLD_INTEREST_START_DT,
# MAGIC SRC.OLD_SUPPORT_END_DT,SRC.NEW_PRELIMINARY_FIANANCE_IND,SRC.TRANSFER_GL_DT,SRC.OLD_FLAT_CHARGE_END_DT,
# MAGIC SRC.OLD_FLAT_CHARGE_PNT_DT,SRC.OLD_SPT_END_DT1,SRC.OLD_SPT_END_DT2,SRC.OLD_VOLUME_TYPE_CD,SRC.OLD_IB_FLAT_CHARGE_DT,
# MAGIC SRC.OLD_SUPPLIER_PLANT_CD,SRC.OUTSTANDING_BALANCE_AMT,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.TXN_EVN_PLAN_CHANGE_EVENT_ST;