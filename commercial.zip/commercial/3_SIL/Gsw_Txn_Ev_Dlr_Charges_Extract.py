# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_txn_ev_dlr_chgs_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

from pyspark.sql.functions import when
df=df.withColumn("TransactionDueDate", when(df.TransactionDueDate.isNull(),"1900-01-01") \
    .when(df.TransactionDueDate=="","1900-01-01") \
    .otherwise(df.TransactionDueDate))
df=df.withColumn("TransactionValueDate", when(df.TransactionValueDate.isNull(),"1900-01-01") \
    .when(df.TransactionValueDate=="","1900-01-01") \
    .otherwise(df.TransactionValueDate))
df=df.withColumn("TransactionBookDate", when(df.TransactionBookDate.isNull(),"1900-01-01") \
    .when(df.TransactionBookDate=="","1900-01-01") \
    .otherwise(df.TransactionBookDate))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_Txn_Ev_Dlr_Charges_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BranchNumber Varchar(20),
DealerNumber Varchar(255),
TransactionTypeCode Varchar(50),
TransactionReasonTypeCode Varchar(50),
Involved_Party_Type_Code Varchar(50),
InvolvedPartyEventTypeCode Varchar(50),
TransactionDueDate DATE NOT NULL,
TransactionValueDate DATE NOT NULL,
TransactionBookDate DATE NOT NULL,
TransactionAmount DECIMAL(38),
TransactionSequenceNumber DECIMAL(38),
EventTypeCode Varchar(20),
EventLifeCycleStatusCode Varchar(20),
ActivityType Varchar(20),
PaymentMethodCode Varchar(20),
SourceSystemRefereceId Varchar(20),
BANK_NM Varchar(20),
BANK_SUBBLOCK_CD Varchar(20),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/") #SILVER PATH

# COMMAND ----------

TBL_NAME='Txn_Ev_Dlr_Charges_st' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.Txn_Ev_Dlr_Charges_st as TGT USING TEMP_Txn_Ev_Dlr_Charges_SIL as SRC ON 
# MAGIC TGT.InvolvedPartyEventTypeCode=SRC.InvolvedPartyEventTypeCode AND
# MAGIC TGT.DealerNumber=SRC.DealerNumber AND
# MAGIC TGT.BranchNumber=SRC.BranchNumber AND
# MAGIC TGT.Involved_Party_Type_Code=SRC.Involved_Party_Type_Code AND
# MAGIC TGT.TransactionTypeCode=SRC.TransactionTypeCode AND 
# MAGIC TGT.TransactionReasonTypeCode=SRC.TransactionReasonTypeCode AND
# MAGIC TGT.ActivityType=SRC.ActivityType AND
# MAGIC TGT.EventLifeCycleStatusCode =SRC.EventLifeCycleStatusCode AND
# MAGIC TGT.EventTypeCode=SRC.EventTypeCode AND
# MAGIC TGT.PaymentMethodCode=SRC.PaymentMethodCode AND
# MAGIC TGT.TransactionBookDate=SRC.TransactionBookDate AND
# MAGIC TGT.TransactionSequenceNumber=SRC.TransactionSequenceNumber AND
# MAGIC TGT.TransactionDueDate=SRC.TransactionDueDate AND
# MAGIC TGT.TransactionValueDate=SRC.TransactionValueDate AND
# MAGIC TGT.BANK_NM=SRC.BANK_NM AND
# MAGIC TGT.BANK_SUBBLOCK_CD=SRC.BANK_SUBBLOCK_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.TransactionAmount=SRC.TransactionAmount,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (BranchNumber,
# MAGIC DealerNumber,
# MAGIC TransactionTypeCode,
# MAGIC TransactionReasonTypeCode,
# MAGIC Involved_Party_Type_Code,
# MAGIC InvolvedPartyEventTypeCode,
# MAGIC TransactionDueDate,
# MAGIC TransactionValueDate,
# MAGIC TransactionBookDate,
# MAGIC TransactionAmount,
# MAGIC TransactionSequenceNumber,
# MAGIC EventTypeCode,
# MAGIC EventLifeCycleStatusCode,
# MAGIC ActivityType,
# MAGIC PaymentMethodCode,
# MAGIC SourceSystemRefereceId,
# MAGIC BANK_NM,
# MAGIC BANK_SUBBLOCK_CD,
# MAGIC INSERT_TIMSTM)
# MAGIC VALUES  
# MAGIC (SRC.BranchNumber,
# MAGIC SRC.DealerNumber,
# MAGIC SRC.TransactionTypeCode,
# MAGIC SRC.TransactionReasonTypeCode,
# MAGIC SRC.Involved_Party_Type_Code,
# MAGIC SRC.InvolvedPartyEventTypeCode,
# MAGIC SRC.TransactionDueDate,
# MAGIC SRC.TransactionValueDate,
# MAGIC SRC.TransactionBookDate,
# MAGIC SRC.TransactionAmount,
# MAGIC SRC.TransactionSequenceNumber,
# MAGIC SRC.EventTypeCode,
# MAGIC SRC.EventLifeCycleStatusCode,
# MAGIC SRC.ActivityType,
# MAGIC SRC.PaymentMethodCode,
# MAGIC SRC.SourceSystemRefereceId,
# MAGIC SRC.BANK_NM,
# MAGIC SRC.BANK_SUBBLOCK_CD,
# MAGIC current_timestamp())
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.Txn_Ev_Dlr_Charges_st;

# COMMAND ----------

