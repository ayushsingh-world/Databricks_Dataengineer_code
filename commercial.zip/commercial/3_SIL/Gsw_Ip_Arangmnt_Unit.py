# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_IP_ARANGMNT_UNIT_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_IP_ARANGMNT_UNIT")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
DEALERNUMBER                   VARCHAR(255) NOT NULL,
IP_ARANGMNT_UNIT_TP_CD         VARCHAR(50) NOT NULL,
ARANGMNT_UNIT_TYPE_CD          VARCHAR(255) NOT NULL,
INVOLVED_PARTY_TYPE_CD         VARCHAR(20) NOT NULL,
BRANCHNUMBER                   VARCHAR(20) NOT NULL,
INSERT_TIMSTM                  TIMESTAMP,
UPDATE_TIMSTM                  TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='IP_ARANGMNT_UNIT_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.IP_ARANGMNT_UNIT_ST as TGT USING TEMP_IP_ARANGMNT_UNIT as SRC ON 
# MAGIC TGT.DEALERNUMBER = SRC.DEALERNUMBER AND
# MAGIC TGT.IP_ARANGMNT_UNIT_TP_CD  = SRC.IP_ARANGMNT_UNIT_TP_CD   AND
# MAGIC TGT.ARANGMNT_UNIT_TYPE_CD   = SRC.ARANGMNT_UNIT_TYPE_CD   AND
# MAGIC TGT.INVOLVED_PARTY_TYPE_CD  = SRC.INVOLVED_PARTY_TYPE_CD  AND
# MAGIC TGT.BRANCHNUMBER   = SRC.BRANCHNUMBER 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (DEALERNUMBER,IP_ARANGMNT_UNIT_TP_CD,ARANGMNT_UNIT_TYPE_CD ,INVOLVED_PARTY_TYPE_CD ,BRANCHNUMBER,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.DEALERNUMBER,SRC.IP_ARANGMNT_UNIT_TP_CD,SRC.ARANGMNT_UNIT_TYPE_CD,SRC.INVOLVED_PARTY_TYPE_CD,SRC.BRANCHNUMBER,current_timestamp())