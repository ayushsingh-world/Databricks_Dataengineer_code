# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_MODEL_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("MODEL_DESC", when(df.MODEL_DESC.isNull(),"NA") \
    .when(df.MODEL_DESC=="","NA") \
    .otherwise(df.MODEL_DESC))


# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_MODEL_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
MODEL_CD           VARCHAR(255),
MODEL_DESC         VARCHAR(255),
MAKECODE           VARCHAR(255),
UNITCLASSCODE      VARCHAR(255),
BRANCH_NUMBER      VARCHAR(20),
MANUFACTURERNAME   VARCHAR(255),
TYPE_CD            VARCHAR(50),
INSERT_TIMSTM      TIMESTAMP,
UPDATE_TIMSTM      TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='MODEL' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.MODEL as TGT USING TEMP_MODEL_SIL as SRC ON 
# MAGIC TGT.MAKECODE  =  SRC.MAKECODE  AND
# MAGIC TGT.BRANCH_NUMBER  = SRC.BRANCH_NUMBER  AND
# MAGIC TGT.MANUFACTURERNAME  = SRC.MANUFACTURERNAME  AND
# MAGIC TGT.TYPE_CD  = SRC.TYPE_CD AND
# MAGIC TGT.UNITCLASSCODE  = SRC.UNITCLASSCODE  
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.MODEL_DESC  = SRC.MODEL_DESC,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC (MODEL_CD,MODEL_DESC,MAKECODE,UNITCLASSCODE,BRANCH_NUMBER,MANUFACTURERNAME ,TYPE_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.MODEL_CD,SRC.MODEL_DESC,SRC.MAKECODE,SRC.UNITCLASSCODE,SRC.BRANCH_NUMBER,SRC.MANUFACTURERNAME ,SRC.TYPE_CD,current_timestamp())