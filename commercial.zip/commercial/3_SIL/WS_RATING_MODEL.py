# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-15'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.WS_RATING_MODEL_BT where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

df=spark.sql("select * from itda_io_dev.io_cml_brz.ws_rating_model_bt")

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
 	df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
from pyspark.sql.types import DecimalType

# COMMAND ----------

df.withColumnRenamed("modelversiontypeid","MODELVERSIONTYPEID")\
  .withColumnRenamed("modelversionname","DESCRIPTION")\
  .withColumnRenamed("versionnumber","VERSION")

# COMMAND ----------

df.withColumn("MODELVERSIONTYPEID",trim(df.modelversiontypeid))
df.withColumn("DESCRIPTION",trim(df.modelversionname))
df.withColumn("VERSION",trim(df.versionnumber))

# COMMAND ----------

df.createOrReplaceTempView("TMP_RATING_MODEL_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
MODELVERSIONTYPEID VARCHAR(255),
DESCRIPTION VARCHAR(255),
VERSION VARCHAR(255),
INSERT_TIMSTM TIMESTAMP,
UPDATE_TIMSTM TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_RATING_MODEL_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_RATING_MODEL_ST AS TGT
# MAGIC USING TMP_RATING_MODEL_SIL AS SRC
# MAGIC ON TGT.MODELVERSIONTYPEID = SRC.modelversiontypeid
# MAGIC AND TGT.DESCRIPTION = SRC.modelversionname
# MAGIC AND TGT.VERSION = SRC.versionnumber
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     TGT.MODELVERSIONTYPEID = SRC.modelversiontypeid,
# MAGIC     TGT.DESCRIPTION = SRC.modelversionname,
# MAGIC     TGT.VERSION = SRC.versionnumber,
# MAGIC     TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (MODELVERSIONTYPEID, DESCRIPTION, VERSION, INSERT_TIMSTM)
# MAGIC   VALUES (SRC.modelversiontypeid, SRC.modelversionname, SRC.versionnumber, CURRENT_TIMESTAMP());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_rating_model_st;