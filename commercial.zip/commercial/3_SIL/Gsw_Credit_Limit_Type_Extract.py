# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_CREDIT_LIMIT_TYPE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("CREDIT_LIMIT_TP_DESC", when(df.CREDIT_LIMIT_TP_DESC.isNull(),"NA") \
    .when(df.CREDIT_LIMIT_TP_DESC=="","NA") \
    .otherwise(df.CREDIT_LIMIT_TP_DESC))
df=df.withColumn("CREDIT_LIMIT_TP_SHORT_DESC", when(df.CREDIT_LIMIT_TP_SHORT_DESC.isNull(),"NA") \
    .when(df.CREDIT_LIMIT_TP_SHORT_DESC=="","NA") \
    .otherwise(df.CREDIT_LIMIT_TP_SHORT_DESC))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_CREDIT_LIMIT_TYPE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
CREDIT_LIMIT_TP_CD            VARCHAR(20) NOT NULL,
CREDIT_LIMIT_TP_DESC          VARCHAR(255) NOT NULL,
CREDIT_LIMIT_TP_SHORT_DESC    VARCHAR(50) NOT NULL,
BRANCH_NUMBER                 VARCHAR(20) NOT NULL,
INSERT_TIMSTM                 TIMESTAMP,
UPDATE_TIMSTM                 TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='CREDIT_LIMIT_TYPE' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.CREDIT_LIMIT_TYPE as TGT USING TEMP_CREDIT_LIMIT_TYPE_SIL as SRC ON 
# MAGIC TGT.CREDIT_LIMIT_TP_CD = SRC.CREDIT_LIMIT_TP_CD AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.CREDIT_LIMIT_TP_DESC = SRC.CREDIT_LIMIT_TP_DESC ,
# MAGIC TGT.CREDIT_LIMIT_TP_SHORT_DESC = SRC.CREDIT_LIMIT_TP_SHORT_DESC ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (CREDIT_LIMIT_TP_CD,CREDIT_LIMIT_TP_DESC,CREDIT_LIMIT_TP_SHORT_DESC,BRANCH_NUMBER,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.CREDIT_LIMIT_TP_CD,SRC.CREDIT_LIMIT_TP_DESC,SRC.CREDIT_LIMIT_TP_SHORT_DESC,SRC.BRANCH_NUMBER,current_timestamp)

# COMMAND ----------

