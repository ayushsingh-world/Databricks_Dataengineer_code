# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_IP_RATE_TYPE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 	
 
string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
  df= df.withColumn(colname, trim(colname))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("END_DT", when(df.END_DT.isNull(),"1900-01-01") \
    .when(df.END_DT=="","1900-01-01") \
    .otherwise(df.END_DT))


# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_IP_RATE_TYPE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
PRODUCT_PLAN_NAME           VARCHAR(255) NOT NULL,
VERSIONNUMBER               INT NOT NULL,
RATE_TYPE_CODE              VARCHAR(50) NOT NULL,
BRANCH_NUMBER               VARCHAR(20) NOT NULL,
RATE_CD                     VARCHAR(50) NOT NULL,
PRODUCT_PLAN_TYPE_CODE      VARCHAR(20) NOT NULL,
RATE_BASIS_CD               VARCHAR(20) NOT NULL,
START_DT                    VARCHAR(25) NOT NULL,
END_DT                      VARCHAR(10),
RATE_PCT                    DECIMAL(38,2),
SUPPLIER_PLANT_CD           VARCHAR(20) NOT NULL,
INSERT_TIMSTM               TIMESTAMP,
UPDATE_TIMSTM               TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='IP_RATE_TYPE_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.IP_RATE_TYPE_ST as TGT USING TEMP_IP_RATE_TYPE_SIL as SRC ON 
# MAGIC TGT.PRODUCT_PLAN_NAME = SRC.PRODUCT_PLAN_NAME AND
# MAGIC TGT.RATE_CD = SRC.RATE_CD  AND
# MAGIC TGT.RATE_BASIS_CD =  SRC.RATE_BASIS_CD AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD AND
# MAGIC TGT.START_DT = SRC.START_DT AND
# MAGIC TGT.END_DT = SRC.END_DT AND
# MAGIC TGT.RATE_PCT = SRC.RATE_PCT 
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.VERSIONNUMBER = SRC.VERSIONNUMBER,
# MAGIC TGT.RATE_TYPE_CODE = SRC.RATE_TYPE_CODE,
# MAGIC TGT.PRODUCT_PLAN_TYPE_CODE = SRC.PRODUCT_PLAN_TYPE_CODE,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC (PRODUCT_PLAN_NAME,VERSIONNUMBER,RATE_TYPE_CODE,BRANCH_NUMBER,RATE_CD,PRODUCT_PLAN_TYPE_CODE,RATE_BASIS_CD,START_DT,END_DT,RATE_PCT,SUPPLIER_PLANT_CD,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.PRODUCT_PLAN_NAME,SRC.VERSIONNUMBER,SRC.RATE_TYPE_CODE,SRC.BRANCH_NUMBER,SRC.RATE_CD,SRC.PRODUCT_PLAN_TYPE_CODE,SRC.RATE_BASIS_CD,SRC.START_DT,SRC.END_DT,SRC.RATE_PCT,SRC.SUPPLIER_PLANT_CD,current_timestamp())