# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-06-04'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Security_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

    df=df.withColumn("start_dt", when(df.start_dt.isNull(),"1900-01-01 00:00:00") \
    .when(df.start_dt=="","1900-01-01 00:00:00") \
    .otherwise(df.start_dt))
df=df.withColumn("expiration_dt", when(df.expiration_dt.isNull(),"1900-01-01 00:00:00") \
    .when(df.expiration_dt=="","1900-01-01 00:00:00") \
    .otherwise(df.expiration_dt))
df=df.withColumn("comment_txt", when(df.comment_txt.isNull(),"NA") \
    .when(df.comment_txt=="","NA") \
    .otherwise(df.comment_txt))
df = df.withColumn("security_type_desc", when(df.security_type_desc == 'true', 'DELETED') \
.when(df.security_type_desc == 'false', 'ACTIVE') \
.otherwise(df.security_type_desc))

# COMMAND ----------

df.createOrReplaceTempView("TEMP_Security_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
RESOURCE_ITEM_TYPE_CD   VARCHAR(50),
BRANCH_NUMBER          VARCHAR(20),
CLIENT_ID                VARCHAR(20),
SECURITY_TYPE_CD      VARCHAR(50),
SECURITY_TYPE_DESC         VARCHAR(255),
ASSET_AMT                    Integer,
START_DT                    VARCHAR(10),
EXPIRATION_DT              VARCHAR(10),
WHOLESALE_SUPPORT_IND        Integer,
LOAN_SUPPORT_IND              Integer,
COMMENT_TXT                 VARCHAR(4000),
SECURITY_NBR                    Integer,
ISDELETED_IND                 VARCHAR(255),
CANCELLATION_DT             VARCHAR(10),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP

"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_Security_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.WS_Security_ST AS TGT
# MAGIC USING TEMP_Security_SIL AS SRC
# MAGIC ON 
# MAGIC   TGT.RESOURCE_ITEM_TYPE_CD = SRC.resource_item_type_cd AND
# MAGIC   TGT.BRANCH_NUMBER = SRC.branch_number AND
# MAGIC   TGT.CLIENT_ID = SRC.client_id AND
# MAGIC   TGT.SECURITY_TYPE_CD = SRC.security_type_cd AND
# MAGIC   TGT.SECURITY_TYPE_DESC = SRC.security_type_desc AND
# MAGIC   TGT.ASSET_AMT = SRC.asset_amt AND
# MAGIC   TGT.START_DT = SRC.start_dt AND
# MAGIC   TGT.EXPIRATION_DT = SRC.expiration_dt AND
# MAGIC   TGT.WHOLESALE_SUPPORT_IND = SRC.wholesale_support_ind AND
# MAGIC   TGT.LOAN_SUPPORT_IND = SRC.loan_support_ind AND
# MAGIC   TGT.COMMENT_TXT = SRC.comment_txt AND 
# MAGIC   TGT.SECURITY_NBR = SRC.security_nbr AND
# MAGIC   TGT.ISDELETED_IND = SRC.security_removed AND
# MAGIC   TGT.CANCELLATION_DT = SRC.cancelled_date
# MAGIC   
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC   TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (RESOURCE_ITEM_TYPE_CD, BRANCH_NUMBER, CLIENT_ID, SECURITY_TYPE_CD, SECURITY_TYPE_DESC, ASSET_AMT, START_DT, EXPIRATION_DT, WHOLESALE_SUPPORT_IND, LOAN_SUPPORT_IND, COMMENT_TXT, SECURITY_NBR, ISDELETED_IND, CANCELLATION_DT, INSERT_TIMSTM)
# MAGIC   VALUES (SRC.resource_item_type_cd, SRC.branch_number, SRC.client_id, SRC.security_type_cd, SRC.security_type_desc, SRC.asset_amt, SRC.start_dt, SRC.expiration_dt, SRC.wholesale_support_ind, SRC.loan_support_ind, SRC.comment_txt, SRC.security_nbr, SRC.security_removed, SRC.cancelled_date, current_timestamp());
# MAGIC

# COMMAND ----------

