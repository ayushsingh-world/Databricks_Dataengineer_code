# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Financial_Resource_Item_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df = df.withColumn("financial_ri_dt", 
                   when((df.financial_ri_dt.isNotNull()) & (df.financial_ri_dt != ""), df.financial_ri_dt)
                   .otherwise('1900-01-01'))
df = df.withColumn("financial_statement_type", 
                   when((df.financial_statement_type.isNotNull()) & (df.financial_statement_type != ""), df.financial_statement_type)
                   .otherwise('NA'))
df = df.withColumn("involved_party_number",when(trim(df.involved_party_number) != "",             
     trim(df.involved_party_number)).otherwise("NA"))
df = df.withColumn("involved_party_branch_number",when(trim(df.involved_party_branch_number) != "",             
     trim(df.involved_party_branch_number)).otherwise("NA"))

# COMMAND ----------

df.withColumnRenamed("adjustedamount","ADJUSTEDAMOUNT")\
  .withColumnRenamed("amount","AMOUNT")\
  .withColumnRenamed("code","DESC_CODE")\
  .withColumnRenamed("financial_ri_dt","FINANCIAL_RI_DT")\
  .withColumnRenamed("financial_ri_status_cd","FINANCIAL_RI_STATUS_CD")\
  .withColumnRenamed("financial_ri_type_cd","FINANCIAL_RI_TYPE_CD")\
  .withColumnRenamed("financial_statement_type","FINANCIAL_RI_STMT_CD")\
  .withColumnRenamed("financialstatementid","FINANCIAL_RI_REPORT_PERIOD_ID")\
  .withColumnRenamed("involved_party_branch_number","BRANCHNUMBER")\
  .withColumnRenamed("involved_party_number","GSWID")\
  .withColumnRenamed("involved_party_type_cd","CODE")\
  .withColumnRenamed("lineitem_description","LINE_ITEM_DESCRIPTION")\
  .withColumnRenamed("monthsinstatement","MONTH_ACCUMULATION_NBR")\
  .withColumnRenamed("resource_item_type_cd","RESOURCE_ITEM_TYPE_CD")\
  .withColumnRenamed("typecode","TypeCode")

# COMMAND ----------

df.createOrReplaceTempView("TMP_FINANCIAL_RESOURCE_ITEM_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ADJUSTEDAMOUNT                      DECIMAL(38,4),
AMOUNT					      DECIMAL(38,4),
DESC_CODE							  VARCHAR(255),
FINANCIAL_RI_DT					  DATE,
FINANCIAL_RI_STATUS_CD						  VARCHAR(255),
FINANCIAL_RI_TYPE_CD			  VARCHAR(255),
FINANCIAL_RI_STMT_CD     VARCHAR(255),
FINANCIAL_RI_REPORT_PERIOD_ID			  DECIMAL,
BRANCHNUMBER			  VARCHAR(255),
GSWID				      VARCHAR(255),
CODE				      VARCHAR(255),
LINE_ITEM_DESCRIPTION				      VARCHAR(255),
MONTH_ACCUMULATION_NBR				      DECIMAL,
RESOURCE_ITEM_TYPE_CD				      VARCHAR(255),
TypeCode				      VARCHAR(255),
INSERT_TIMSTM                     TIMESTAMP,
UPDATE_TIMSTM                     TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='ws_FINANCIAL_RESOURCE_ITEM_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_FINANCIAL_RESOURCE_ITEM_st AS TGT USING TMP_FINANCIAL_RESOURCE_ITEM_SIL AS SRC ON
# MAGIC (TGT.ADJUSTEDAMOUNT = SRC.adjustedamount AND
# MAGIC TGT.AMOUNT = SRC.amount AND
# MAGIC TGT.DESC_CODE = SRC.code AND
# MAGIC TGT.FINANCIAL_RI_DT = SRC.financial_ri_dt AND
# MAGIC TGT.FINANCIAL_RI_STATUS_CD = SRC.financial_ri_status_cd AND
# MAGIC TGT.FINANCIAL_RI_TYPE_CD = SRC.financial_ri_type_cd AND
# MAGIC TGT.FINANCIAL_RI_STMT_CD = SRC.financial_statement_type AND
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.financialstatementid AND
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number AND
# MAGIC TGT.GSWID = SRC.involved_party_number AND
# MAGIC TGT.CODE = SRC.involved_party_type_cd AND
# MAGIC TGT.LINE_ITEM_DESCRIPTION = SRC.lineitem_description AND
# MAGIC TGT.MONTH_ACCUMULATION_NBR = SRC.monthsinstatement AND
# MAGIC TGT.RESOURCE_ITEM_TYPE_CD = SRC.resource_item_type_cd AND
# MAGIC TGT.TypeCode = SRC.typecode)
# MAGIC WHEN MATCHED THEN 
# MAGIC UPDATE SET
# MAGIC TGT.ADJUSTEDAMOUNT = SRC.adjustedamount,
# MAGIC TGT.AMOUNT = SRC.amount, 
# MAGIC TGT.DESC_CODE = SRC.code,
# MAGIC TGT.FINANCIAL_RI_DT = SRC.financial_ri_dt,
# MAGIC TGT.FINANCIAL_RI_STATUS_CD = SRC.financial_ri_status_cd,
# MAGIC TGT.FINANCIAL_RI_TYPE_CD = SRC.financial_ri_type_cd,
# MAGIC TGT.FINANCIAL_RI_STMT_CD = SRC.financial_statement_type,
# MAGIC TGT.FINANCIAL_RI_REPORT_PERIOD_ID = SRC.financialstatementid,
# MAGIC TGT.BRANCHNUMBER = SRC.involved_party_branch_number,
# MAGIC TGT.GSWID = SRC.involved_party_number,
# MAGIC TGT.CODE = SRC.involved_party_type_cd,
# MAGIC TGT.LINE_ITEM_DESCRIPTION = SRC.lineitem_description,
# MAGIC TGT.MONTH_ACCUMULATION_NBR = SRC.monthsinstatement,
# MAGIC TGT.RESOURCE_ITEM_TYPE_CD = SRC.resource_item_type_cd,
# MAGIC TGT.TypeCode = SRC.typecode,
# MAGIC TGT.UPDATE_TIMSTM = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT (TGT.ADJUSTEDAMOUNT ,TGT.AMOUNT,TGT.DESC_CODE,TGT.FINANCIAL_RI_DT,TGT.FINANCIAL_RI_STATUS_CD,TGT.FINANCIAL_RI_TYPE_CD,TGT.FINANCIAL_RI_STMT_CD,
# MAGIC   TGT.FINANCIAL_RI_REPORT_PERIOD_ID,TGT.BRANCHNUMBER,TGT.GSWID,TGT.CODE,TGT.LINE_ITEM_DESCRIPTION,TGT.MONTH_ACCUMULATION_NBR,TGT.RESOURCE_ITEM_TYPE_CD,TGT.TypeCode,TGT.INSERT_TIMSTM)
# MAGIC 	    VALUES (SRC.adjustedamount ,SRC.amount,SRC.code,SRC.financial_ri_dt,SRC.financial_ri_status_cd,SRC.financial_ri_type_cd,SRC.financial_statement_type,
# MAGIC       SRC.financialstatementid,SRC.involved_party_branch_number,SRC.involved_party_number,SRC.involved_party_type_cd,SRC.lineitem_description,SRC.monthsinstatement,SRC.resource_item_type_cd,SRC.typecode,CURRENT_TIMESTAMP());

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_FINANCIAL_RESOURCE_ITEM_st;