# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Financial_Statement_Count_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when,expr
from pyspark.sql.types import DecimalType

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import when
df = df.withColumn("COUNTRY_CD", when(df['involved_party_branch_number'] == "797", "CL") \
				   .when(df['involved_party_branch_number'] == "795", "CO") \
				   .when(df['involved_party_branch_number'] == "840", "MX") \
				   .when(df['involved_party_branch_number'] == "853", "BR") \
				   .when(df['involved_party_branch_number'] == "821", "PE") \
                    .otherwise("NA"))


# COMMAND ----------

from pyspark.sql.functions import when
df=df.withColumn("DELETED_IND ", when(df['deletedind']== "true",1) \
    .otherwise(0))

# COMMAND ----------

from pyspark.sql.functions import to_date, col
from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format

# Assuming df is your DataFrame
df = df.withColumn("statementdate",to_date(col("statementdate"),"dd/MM/yyyy"))

# COMMAND ----------

display(df)

# COMMAND ----------

df=df.drop(df.deletedind)

# COMMAND ----------

df.createOrReplaceTempView("TEMP_FIN_STMT_CNT")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRANCHNUMBER  VARCHAR(50),
BRANCH_NM       VARCHAR(255),
FIN_STMT_TYPE_CD  VARCHAR(255),
ISDELETED         DECIMAL(38,0),
FIN_STMT_CNT      DECIMAL(38,0),
FIN_STMT_DT      Date,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH


# COMMAND ----------

TBL_NAME='ws_Financial_Statement_Count_st' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS  itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO  itda_io_dev.io_cml_brz.ws_Financial_Statement_Count_st AS TGT
# MAGIC USING TEMP_FIN_STMT_CNT AS SRC
# MAGIC ON 
# MAGIC   TGT.BRANCHNUMBER = SRC.involved_party_branch_number AND
# MAGIC   TGT.BRANCH_NM = SRC.branch AND
# MAGIC   TGT.FIN_STMT_TYPE_CD = SRC.financialstatementattributevalue AND
# MAGIC   TGT.ISDELETED = SRC.`DELETED_IND ` AND  -- Note the backticks around DELETED_IND
# MAGIC   TGT.FIN_STMT_CNT = SRC.numberofstatements AND
# MAGIC   TGT.FIN_STMT_DT = SRC.statementdate
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC   TGT.BRANCHNUMBER = SRC.involved_party_branch_number,
# MAGIC   TGT.BRANCH_NM = SRC.branch,
# MAGIC   TGT.FIN_STMT_TYPE_CD = SRC.financialstatementattributevalue,
# MAGIC   TGT.ISDELETED = SRC.`DELETED_IND ` , -- Note the backticks around DELETED_IND
# MAGIC   TGT.FIN_STMT_CNT = SRC.numberofstatements,
# MAGIC   TGT.FIN_STMT_DT = SRC.statementdate,
# MAGIC     TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (BRANCHNUMBER, BRANCH_NM, FIN_STMT_TYPE_CD, ISDELETED, FIN_STMT_CNT, FIN_STMT_DT, INSERT_TIMSTM)
# MAGIC   VALUES (SRC.involved_party_branch_number, SRC.branch, SRC.financialstatementattributevalue, SRC.`DELETED_IND `, SRC.numberofstatements, SRC.statementdate, current_timestamp())
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_Financial_Statement_Count_st;