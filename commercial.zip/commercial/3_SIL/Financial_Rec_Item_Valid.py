# Databricks notebook source
# MAGIC %sql
# MAGIC --drop table if exists itda_io_dev.io_cml_brz.ws_Financial_Statement_Amount_Validation_st
# MAGIC

# COMMAND ----------

from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.ws_Financial_Statement_Amount_Validation_bt where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
df = df.withColumn("COUNTRY_CD", when(df['gswbranchid'] == "797", "CL") \
				   .when(df['gswbranchid'] == "795", "CO") \
				   .when(df['gswbranchid'] == "840", "MX") \
				   .when(df['gswbranchid'] == "853", "BR") \
				   .when(df['gswbranchid'] == "821", "PE") \
                    .otherwise("NA"))

# COMMAND ----------

from pyspark.sql.functions import to_date, col
from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format

# Assuming df is your DataFrame
df = df.withColumn("perioddate",to_date(col("perioddate"),"dd/MM/yyyy"))

# COMMAND ----------

df.createOrReplaceTempView("TEMP_Financial_Rec_Item_Valid")

# COMMAND ----------

display(df)

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRANCHNUMBER   VARCHAR(50) Not Null,
FIN_STMT_DT    Date Not Null,
FIN_STMT_TYPE_CD    VARCHAR(255) Not Null,
FIN_STMT_TYPE_DESC      VARCHAR(255) Not Null,
ISDELETED_IND         VARCHAR(255) Not Null,
FIN_LINE_ITEM_TYPE_CD    VARCHAR(255) Not Null,
FIN_LINE_ITEM_TYPE_DESC   VARCHAR(255) Not Null,
FIN_LINE_ITEM_TYPE_PRES_DESC   VARCHAR(255) Not Null,
VALIDATION_TYPE_DESC     VARCHAR(255) Not Null,
FIN_LINE_ITEM_TOT_AMT     DECIMAL(38,0) Not Null,
FIN_LINE_ITEM_TOT_ADJ_AMT   DECIMAL(38,0) Not Null,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='WS_Financial_Statement_Amount_Validation_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

###dbutils.fs.ls("abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_Financial_Statement_Amount_Validation_ST")

# COMMAND ----------

###%fs
##rm -r abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz/WS_Financial_Statement_Amount_Validation_ST

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.ws_Financial_Statement_Amount_Validation_st AS TGT
# MAGIC USING TEMP_Financial_Rec_Item_Valid AS SRC
# MAGIC ON 
# MAGIC   TGT.BRANCHNUMBER = SRC.gswbranchid AND
# MAGIC   TGT.FIN_STMT_DT = SRC.perioddate AND
# MAGIC   TGT.FIN_STMT_TYPE_CD = SRC.fstypeid AND
# MAGIC   TGT.FIN_STMT_TYPE_DESC = SRC.fs_type AND
# MAGIC   TGT.ISDELETED_IND = SRC.isdeleted AND
# MAGIC     TGT.FIN_LINE_ITEM_TYPE_CD = SRC.ccoaid AND
# MAGIC 	  TGT.FIN_LINE_ITEM_TYPE_DESC = SRC.code AND
# MAGIC 	    TGT.FIN_LINE_ITEM_TYPE_PRES_DESC = SRC.description AND
# MAGIC 	    TGT.VALIDATION_TYPE_DESC = SRC.validationtype AND
# MAGIC 		TGT.FIN_LINE_ITEM_TOT_AMT = SRC.amount AND
# MAGIC   TGT.FIN_LINE_ITEM_TOT_ADJ_AMT = SRC.adjustedamount
# MAGIC WHEN MATCHED THEN 
# MAGIC   UPDATE SET 
# MAGIC   TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC WHEN NOT MATCHED THEN 
# MAGIC   INSERT (BRANCHNUMBER,FIN_STMT_DT,FIN_STMT_TYPE_CD,FIN_STMT_TYPE_DESC,ISDELETED_IND,FIN_LINE_ITEM_TYPE_CD,FIN_LINE_ITEM_TYPE_DESC,FIN_LINE_ITEM_TYPE_PRES_DESC,VALIDATION_TYPE_DESC,
# MAGIC FIN_LINE_ITEM_TOT_AMT,FIN_LINE_ITEM_TOT_ADJ_AMT,INSERT_TIMSTM)
# MAGIC   VALUES (SRC.gswbranchid, SRC.perioddate, SRC.fstypeid, SRC.fs_type, SRC.isdeleted, SRC.ccoaid, SRC.code, SRC.description, SRC.validationtype, SRC.amount, SRC.adjustedamount, current_timestamp())
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.ws_Financial_Statement_Amount_Validation_st;

# COMMAND ----------

# MAGIC %sql
# MAGIC --delete from itda_io_dev.io_cml_brz.ws_Financial_Statement_Amount_Validation_st 