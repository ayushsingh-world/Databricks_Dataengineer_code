# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_INVOLVED_PARTY_POST_ADDRESS_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 


# COMMAND ----------

string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
        df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("AccountStatusDescription", when(df.AccountStatusDescription.isNull(),"NA") \
    .when(df.AccountStatusDescription=="","NA") \
    .otherwise(df.AccountStatusDescription))
df=df.withColumn("Address1", when(df.Address1.isNull(),"NA") \
    .when(df.Address1=="","NA") \
    .otherwise(df.Address1))
df=df.withColumn("Address2", when(df.Address2.isNull(),"NA") \
    .when(df.Address2=="","NA") \
    .otherwise(df.Address2))
df=df.withColumn("CityName", when(df.CityName.isNull(),"NA") \
    .when(df.CityName=="","NA") \
    .otherwise(df.CityName))
df=df.withColumn("StateName", when(df.StateName.isNull(),"NA") \
    .when(df.StateName=="","NA") \
    .otherwise(df.StateName))
df=df.withColumn("PostalCode", when(df.PostalCode.isNull(),"NA") \
    .when(df.PostalCode=="","NA") \
    .otherwise(df.PostalCode))
df=df.withColumn("StartDate", when(df.StartDate.isNull(),"1900-01-01 00:00:00") \
    .when(df.StartDate=="","1900-01-01 00:00:00") \
    .otherwise(df.StartDate))
df=df.withColumn("EndDate", when(df.EndDate.isNull(),"1900-01-01 00:00:00") \
    .when(df.EndDate=="","1900-01-01 00:00:00") \
    .otherwise(df.EndDate))
df=df.withColumn("CountyName", when(df.CountyName.isNull(),"NA") \
    .when(df.CountyName=="","NA") \
    .otherwise(df.CountyName))
df=df.withColumn("CountryName", when(df.CountryName.isNull(),"NA") \
    .when(df.CountryName=="","NA") \
    .otherwise(df.CountryName))
df=df.withColumn("UnionCountryName", when(df.UnionCountryName.isNull(),"NA") \
    .when(df.UnionCountryName=="","NA") \
    .otherwise(df.UnionCountryName))
df=df.withColumn("Address_Line_3", when(df.Address_Line_3.isNull(),"NA") \
    .when(df.Address_Line_3=="","NA") \
    .otherwise(df.Address_Line_3))
df=df.withColumn("Address_Line_4", when(df.Address_Line_4.isNull(),"NA") \
    .when(df.Address_Line_4=="","NA") \
    .otherwise(df.Address_Line_4))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_INVOLVED_PARTY_POST_ADDRESS_SIL")

# COMMAND ----------

# MAGIC %sql
# MAGIC desc TEMP_INVOLVED_PARTY_POST_ADDRESS_SIL

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
AccountNumber               VARCHAR(20),
ProductTypeId               VARCHAR(20),
Customer_ID                 VARCHAR(255) ,
AccountStatusDescription    VARCHAR(50),
Address1                    VARCHAR(50),
Address2                    VARCHAR(50),
CityName                    VARCHAR(50) ,
StateName                   VARCHAR(50) ,
BarrioName                  VARCHAR(50),
PostalCode                  VARCHAR(20),
TypeOfAddress               VARCHAR(20) ,
StartDate                   VARCHAR(38),
EndDate                     VARCHAR(38),
HomeValueAmount             VARCHAR(20),
MonthlyPaymentAmount         VARCHAR(20),
DurationMonthsCount        VARCHAR(20),
DurationYearsCount         VARCHAR(20),
AddressTypeCode             VARCHAR(25),
OccupancyTypeCode           VARCHAR(50),
CountyName                  VARCHAR(50) ,
CountryName                 VARCHAR(50) ,
UnionCountryName            VARCHAR(50) ,
BranchNumber                VARCHAR(20),
Address_Line_3              VARCHAR(255),
Address_Line_4              VARCHAR(255),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='INVOLVED_PARTY_POST_ADDRESS_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+'/'+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.INVOLVED_PARTY_POST_ADDRESS_ST as TGT USING TEMP_INVOLVED_PARTY_POST_ADDRESS_SIL as SRC ON 
# MAGIC TGT.AddressTypeCode = SRC.AddressTypeCode AND
# MAGIC TGT.Address1 = SRC.Address1 AND
# MAGIC TGT.Address2 = SRC.Address2 AND
# MAGIC TGT.Address_Line_3 = SRC.Address_Line_3 AND
# MAGIC TGT.Address_Line_4 = SRC.Address_Line_4 AND
# MAGIC TGT.PostalCode = SRC.PostalCode AND
# MAGIC TGT.StateName = SRC.StateName AND
# MAGIC TGT.CityName = SRC.CityName AND
# MAGIC TGT.CountyName = SRC.CountyName AND
# MAGIC TGT.CountryName = SRC.CountryName AND
# MAGIC TGT.UnionCountryName = SRC.UnionCountryName AND
# MAGIC TGT.Customer_ID = SRC.Customer_ID AND
# MAGIC TGT.TypeOfAddress = SRC.TypeOfAddress AND
# MAGIC TGT.BranchNumber = SRC.BranchNumber
# MAGIC WHEN MATCHED THEN  UPDATE SET 
# MAGIC TGT.AccountNumber=SRC.AccountNumber,
# MAGIC TGT.ProductTypeId=SRC.ProductTypeId,
# MAGIC TGT.Customer_ID=SRC.Customer_ID,
# MAGIC TGT.AccountStatusDescription = SRC.AccountStatusDescription,
# MAGIC TGT.Address1 = SRC.Address1 ,
# MAGIC TGT.Address2 = SRC.Address2 ,
# MAGIC TGT.CityName = SRC.CityName ,
# MAGIC TGT.StateName = SRC.StateName ,
# MAGIC TGT.BarrioName = SRC.BarrioName,
# MAGIC TGT.PostalCode = SRC.PostalCode ,
# MAGIC TGT.TypeOfAddress = SRC.TypeOfAddress ,
# MAGIC TGT.StartDate = SRC.StartDate ,
# MAGIC TGT.EndDate = SRC.EndDate,
# MAGIC TGT.HomeValueAmount = SRC.HomeValueAmount ,
# MAGIC TGT.MonthlyPaymentAmount = SRC.MonthlyPaymentAmount,
# MAGIC TGT.DurationMonthsCount = SRC.DurationMonthsCount,
# MAGIC TGT.DurationYearsCount = SRC.DurationYearsCount,
# MAGIC TGT.AddressTypeCode = SRC.AddressTypeCode ,
# MAGIC TGT.OccupancyTypeCode = SRC.OccupancyTypeCode ,
# MAGIC TGT.CountyName = SRC.CountyName ,
# MAGIC TGT.CountryName = SRC.CountryName ,
# MAGIC TGT.UnionCountryName = SRC.UnionCountryName ,
# MAGIC TGT.BranchNumber = SRC.BranchNumber ,
# MAGIC TGT.Address_Line_3 = SRC.Address_Line_3 ,
# MAGIC TGT.Address_Line_4 = SRC.Address_Line_4 , 
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC  WHEN NOT MATCHED  THEN INSERT (AccountNumber,ProductTypeId,Customer_ID,AccountStatusDescription,Address1,Address2,CityName,StateName,BarrioName,PostalCode,TypeOfAddress,StartDate,EndDate,HomeValueAmount,MonthlyPaymentAmount,DurationMonthsCount,DurationYearsCount,AddressTypeCode,OccupancyTypeCode,CountyName,CountryName,UnionCountryName,BranchNumber,Address_Line_3,Address_Line_4,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.AccountNumber,SRC.ProductTypeId,SRC.Customer_ID,SRC.AccountStatusDescription,SRC.Address1,
# MAGIC SRC.Address2,SRC.CityName,SRC.StateName,SRC.BarrioName,SRC.PostalCode,SRC.TypeOfAddress,SRC.StartDate,SRC.EndDate,SRC.HomeValueAmount,SRC.MonthlyPaymentAmount,SRC.DurationMonthsCount,SRC.DurationYearsCount,SRC.AddressTypeCode,SRC.OccupancyTypeCode,SRC.CountyName,SRC.CountryName,SRC.UnionCountryName,SRC.BranchNumber,SRC.Address_Line_3,SRC.Address_Line_4,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  itda_io_dev.io_cml_brz.involved_party_post_address_st;