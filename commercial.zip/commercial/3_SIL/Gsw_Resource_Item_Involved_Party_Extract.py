# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_resource_item_involved_party_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("Customer_Id", when(df.Customer_Id.isNull(),"NA") \
    .when(df.Customer_Id=="","NA") \
    .otherwise(df.Customer_Id))
df=df.withColumn("VIN", when(df.VIN.isNull(),"NA") \
    .when(df.VIN=="","NA") \
    .otherwise(df.VIN))
df=df.withColumn("Code", when(df.Code.isNull(),"NA") \
    .when(df.Code=="","NA") \
    .otherwise(df.Code))
df=df.withColumn("Type_Code", when(df.Type_Code.isNull(),"NA") \
    .when(df.Type_Code=="","NA") \
    .otherwise(df.Type_Code))
df=df.withColumn("VehicleTypeCode", when(df.VehicleTypeCode.isNull(),"NA") \
    .when(df.VehicleTypeCode=="","NA") \
    .otherwise(df.VehicleTypeCode))


# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_RESOURCE_ITEM_INVOLVED_PARTY_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
CUSTOMER_ID		VARCHAR	(255),
VIN				VARCHAR	(20),
CODE			VARCHAR	(50),
TYPE_CODE		VARCHAR	(50),
BRANCH_NUMBER	VARCHAR	(20),
VEHICLETYPECODE	VARCHAR	(50),
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='RESOURCE_ITEM_INVOLVED_PARTY_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.RESOURCE_ITEM_INVOLVED_PARTY_ST as TGT USING TEMP_RESOURCE_ITEM_INVOLVED_PARTY_SIL as SRC ON 
# MAGIC TGT.CUSTOMER_ID = SRC.CUSTOMER_ID AND
# MAGIC TGT.VIN = SRC.VIN AND
# MAGIC TGT.CODE = SRC.CODE AND
# MAGIC TGT.TYPE_CODE = SRC.TYPE_CODE AND
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER AND
# MAGIC TGT.VEHICLETYPECODE = SRC.VEHICLETYPECODE
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (CUSTOMER_ID,VIN,CODE,TYPE_CODE,BRANCH_NUMBER,VEHICLETYPECODE,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.CUSTOMER_ID,SRC.VIN,SRC.CODE,SRC.TYPE_CODE,SRC.BRANCH_NUMBER,SRC.VEHICLETYPECODE,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.RESOURCE_ITEM_INVOLVED_PARTY_ST;

# COMMAND ----------

