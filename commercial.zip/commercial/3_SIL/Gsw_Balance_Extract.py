# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.GSW_BALANCE_EXTRACT_BT where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import *


# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.withColumn("ORGANIZATION_UNIT_NBR", when(df.ORGANIZATION_UNIT_NBR.isNull(),"NA") \
    .when(df.ORGANIZATION_UNIT_NBR=="","NA") \
    .otherwise(df.ORGANIZATION_UNIT_NBR))
df=df.withColumn("SNAPSHOT_DT", when(df.SNAPSHOT_DT.isNull(),"NA") \
    .when(df.SNAPSHOT_DT=="","NA") \
    .otherwise(df.SNAPSHOT_DT))
df=df.withColumn("WS_BAL_CT", when(df.WS_BAL_CT.isNull(),"NA") \
    .when(df.WS_BAL_CT=="","NA") \
    .otherwise(df.WS_BAL_CT))
df=df.withColumn("WS_CURR_BAL", when(df.WS_CURR_BAL.isNull(),"NA") \
    .when(df.WS_CURR_BAL=="","NA") \
    .otherwise(df.WS_CURR_BAL))
df=df.withColumn("WS_ORIG_BAL", when(df.WS_ORIG_BAL.isNull(),"NA") \
    .when(df.WS_ORIG_BAL=="","NA") \
    .otherwise(df.WS_ORIG_BAL))
df=df.withColumn("WS_PIF_CT", when(df.WS_PIF_CT.isNull(),"NA") \
    .when(df.WS_PIF_CT=="","NA") \
    .otherwise(df.WS_PIF_CT))
df=df.withColumn("WS_PIF_AMT", when(df.WS_PIF_AMT.isNull(),"NA") \
    .when(df.WS_PIF_AMT=="","NA") \
    .otherwise(df.WS_PIF_AMT))
df=df.withColumn("RLOC_CNT", when(df.RLOC_CNT.isNull(),"NA") \
    .when(df.RLOC_CNT=="","NA") \
    .otherwise(df.RLOC_CNT))
df=df.withColumn("RLOC_AMT", when(df.RLOC_AMT.isNull(),"NA") \
    .when(df.RLOC_AMT=="","NA") \
    .otherwise(df.RLOC_AMT))
df=df.withColumn("DL_CT", when(df.DL_CT.isNull(),"NA") \
    .when(df.DL_CT=="","NA") \
    .otherwise(df.DL_CT))
df=df.withColumn("DL_AMT", when(df.DL_AMT.isNull(),"NA") \
    .when(df.DL_AMT=="","NA") \
    .otherwise(df.DL_AMT))
df=df.withColumn("CHG_CT", when(df.CHG_CT.isNull(),"NA") \
    .when(df.CHG_CT=="","NA") \
    .otherwise(df.CHG_CT))
df=df.withColumn("CHG_BAL", when(df.CHG_BAL.isNull(),"NA") \
    .when(df.CHG_BAL=="","NA") \
    .otherwise(df.CHG_BAL))
df=df.withColumn("WS_INT_AMT", when(df.WS_INT_AMT.isNull(),"NA") \
    .when(df.WS_INT_AMT=="","NA") \
    .otherwise(df.WS_INT_AMT))
df=df.withColumn("WS_CHG_AMT", when(df.WS_CHG_AMT.isNull(),"NA") \
    .when(df.WS_CHG_AMT=="","NA") \
    .otherwise(df.WS_CHG_AMT))
df=df.withColumn("DL_INT_AMT", when(df.DL_INT_AMT.isNull(),"NA") \
    .when(df.DL_INT_AMT=="","NA") \
    .otherwise(df.DL_INT_AMT))
df=df.withColumn("CHG_INT_AMT", when(df.CHG_INT_AMT.isNull(),"NA") \
    .when(df.CHG_INT_AMT=="","NA") \
    .otherwise(df.CHG_INT_AMT))

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format
df = df.withColumn("SNAPSHOT_DT",to_date(col("SNAPSHOT_DT"),"yyyy-MM-dd"))

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType

# COMMAND ----------

df = df.withColumn("WS_BAL_CT", df["WS_BAL_CT"].cast(DecimalType(38,2))) \
        .withColumn("WS_CURR_BAL", df["WS_CURR_BAL"].cast(DecimalType(38,2))) \
        .withColumn("WS_ORIG_BAL", df["WS_ORIG_BAL"].cast(DecimalType(38,2))) \
        .withColumn("WS_PIF_CT", df["WS_PIF_CT"].cast(DecimalType(38,2))) \
        .withColumn("WS_PIF_AMT", df["WS_PIF_AMT"].cast(DecimalType(38,2))) \
        .withColumn("RLOC_CNT", df["RLOC_CNT"].cast(DecimalType(38,2))) \
        .withColumn("RLOC_AMT", df["RLOC_AMT"].cast(DecimalType(38,2))) \
        .withColumn("DL_CT", df["DL_CT"].cast(DecimalType(38,2))) \
        .withColumn("DL_AMT", df["DL_AMT"].cast(DecimalType(38,2))) \
        .withColumn("CHG_CT", df["CHG_CT"].cast(DecimalType(38,2))) \
        .withColumn("CHG_BAL", df["CHG_BAL"].cast(DecimalType(38,2))) \
        .withColumn("WS_INT_AMT", df["WS_INT_AMT"].cast(DecimalType(38,2))) \
        .withColumn("WS_CHG_AMT", df["WS_CHG_AMT"].cast(DecimalType(38,2))) \
        .withColumn("DL_INT_AMT", df["DL_INT_AMT"].cast(DecimalType(38,2))) \
        .withColumn("CHG_INT_AMT", df["CHG_INT_AMT"].cast(DecimalType(38,2)))
         

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_BALANCE_SIL")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from TEMP_BALANCE_SIL;

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
ORGANIZATION_UNIT_NBR 			VARCHAR(50) NOT NULL,
SNAPSHOT_DT 			        DATE NOT NULL,
WS_BAL_CT				        DECIMAL(38,2) NOT NULL,
WS_CURR_BAL 			        DECIMAL(38,2) NOT NULL,
WS_ORIG_BAL 			        DECIMAL(38,2) NOT NULL,
WS_PIF_CT 				        DECIMAL(38,2) NOT NULL,
WS_PIF_AMT 				        DECIMAL(38,2) NOT NULL,
RLOC_CNT 				        DECIMAL(38,2) NOT NULL,
RLOC_AMT 				        DECIMAL(38,2) NOT NULL,
DL_CT 					        DECIMAL(38,2) NOT NULL,
DL_AMT 					        DECIMAL(38,2) NOT NULL,
CHG_CT 					        DECIMAL(38,2) NOT NULL,
CHG_BAL 				        DECIMAL(38,2) NOT NULL,
WS_INT_AMT 				        DECIMAL(38,2) NOT NULL,
WS_CHG_AMT 				        DECIMAL(38,2) NOT NULL,
DL_INT_AMT 				        DECIMAL(38,2) NOT NULL,
CHG_INT_AMT 			        DECIMAL(38,2) NOT NULL,
INSERT_TIMSTM                   TIMESTAMP,
UPDATE_TIMSTM                   TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='GSW_BALANCE_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.GSW_BALANCE_ST USING TEMP_BALANCE_SIL ON 
# MAGIC GSW_BALANCE_ST.ORGANIZATION_UNIT_NBR=TEMP_BALANCE_SIL.ORGANIZATION_UNIT_NBR AND
# MAGIC GSW_BALANCE_ST.SNAPSHOT_DT=TEMP_BALANCE_SIL.SNAPSHOT_DT AND
# MAGIC GSW_BALANCE_ST.WS_BAL_CT=TEMP_BALANCE_SIL.WS_BAL_CT AND
# MAGIC GSW_BALANCE_ST.WS_CURR_BAL=TEMP_BALANCE_SIL.WS_CURR_BAL AND
# MAGIC GSW_BALANCE_ST.WS_ORIG_BAL=TEMP_BALANCE_SIL.WS_ORIG_BAL AND
# MAGIC GSW_BALANCE_ST.WS_PIF_CT=TEMP_BALANCE_SIL.WS_PIF_CT  AND
# MAGIC GSW_BALANCE_ST.WS_PIF_AMT=TEMP_BALANCE_SIL.WS_PIF_AMT AND
# MAGIC GSW_BALANCE_ST.RLOC_CNT=TEMP_BALANCE_SIL.RLOC_CNT AND
# MAGIC GSW_BALANCE_ST.RLOC_AMT=TEMP_BALANCE_SIL.RLOC_AMT AND
# MAGIC GSW_BALANCE_ST.DL_CT=TEMP_BALANCE_SIL.DL_CT AND
# MAGIC GSW_BALANCE_ST.DL_AMT=TEMP_BALANCE_SIL.DL_AMT AND
# MAGIC GSW_BALANCE_ST.CHG_CT=TEMP_BALANCE_SIL.CHG_CT AND
# MAGIC GSW_BALANCE_ST.CHG_BAL=TEMP_BALANCE_SIL.CHG_BAL AND
# MAGIC GSW_BALANCE_ST.WS_INT_AMT=TEMP_BALANCE_SIL.WS_INT_AMT AND
# MAGIC GSW_BALANCE_ST.WS_CHG_AMT=TEMP_BALANCE_SIL.WS_CHG_AMT AND
# MAGIC GSW_BALANCE_ST.DL_INT_AMT=TEMP_BALANCE_SIL.DL_INT_AMT AND
# MAGIC GSW_BALANCE_ST.CHG_INT_AMT=TEMP_BALANCE_SIL.CHG_INT_AMT
# MAGIC WHEN MATCHED THEN  UPDATE SET    
# MAGIC GSW_BALANCE_ST.ORGANIZATION_UNIT_NBR=TEMP_BALANCE_SIL.ORGANIZATION_UNIT_NBR,
# MAGIC GSW_BALANCE_ST.SNAPSHOT_DT=TEMP_BALANCE_SIL.SNAPSHOT_DT,
# MAGIC GSW_BALANCE_ST.WS_BAL_CT=TEMP_BALANCE_SIL.WS_BAL_CT,
# MAGIC GSW_BALANCE_ST.WS_CURR_BAL=TEMP_BALANCE_SIL.WS_CURR_BAL,
# MAGIC GSW_BALANCE_ST.WS_ORIG_BAL=TEMP_BALANCE_SIL.WS_ORIG_BAL,
# MAGIC GSW_BALANCE_ST.WS_PIF_CT=TEMP_BALANCE_SIL.WS_PIF_CT,
# MAGIC GSW_BALANCE_ST.WS_PIF_AMT=TEMP_BALANCE_SIL.WS_PIF_AMT,
# MAGIC GSW_BALANCE_ST.RLOC_CNT=TEMP_BALANCE_SIL.RLOC_CNT,
# MAGIC GSW_BALANCE_ST.RLOC_AMT=TEMP_BALANCE_SIL.RLOC_AMT,
# MAGIC GSW_BALANCE_ST.DL_CT=TEMP_BALANCE_SIL.DL_CT,
# MAGIC GSW_BALANCE_ST.DL_AMT=TEMP_BALANCE_SIL.DL_AMT,
# MAGIC GSW_BALANCE_ST.CHG_CT=TEMP_BALANCE_SIL.CHG_CT,
# MAGIC GSW_BALANCE_ST.CHG_BAL=TEMP_BALANCE_SIL.CHG_BAL,
# MAGIC GSW_BALANCE_ST.WS_INT_AMT=TEMP_BALANCE_SIL.WS_INT_AMT,
# MAGIC GSW_BALANCE_ST.WS_CHG_AMT=TEMP_BALANCE_SIL.WS_CHG_AMT,
# MAGIC GSW_BALANCE_ST.DL_INT_AMT=TEMP_BALANCE_SIL.DL_INT_AMT,
# MAGIC GSW_BALANCE_ST.CHG_INT_AMT=TEMP_BALANCE_SIL.CHG_INT_AMT,
# MAGIC GSW_BALANCE_ST.UPDATE_TIMSTM=current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (ORGANIZATION_UNIT_NBR,SNAPSHOT_DT,WS_BAL_CT,WS_CURR_BAL,WS_ORIG_BAL,WS_PIF_CT,WS_PIF_AMT,RLOC_CNT,RLOC_AMT,DL_CT,DL_AMT,CHG_CT,CHG_BAL,WS_INT_AMT,WS_CHG_AMT,DL_INT_AMT,CHG_INT_AMT,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (TEMP_BALANCE_SIL.ORGANIZATION_UNIT_NBR,TEMP_BALANCE_SIL.SNAPSHOT_DT,TEMP_BALANCE_SIL.WS_BAL_CT,TEMP_BALANCE_SIL.WS_CURR_BAL,TEMP_BALANCE_SIL.WS_ORIG_BAL,TEMP_BALANCE_SIL.WS_PIF_CT,TEMP_BALANCE_SIL.WS_PIF_AMT,TEMP_BALANCE_SIL.RLOC_CNT,TEMP_BALANCE_SIL.RLOC_AMT,TEMP_BALANCE_SIL.DL_CT,TEMP_BALANCE_SIL.DL_AMT,TEMP_BALANCE_SIL.CHG_CT,TEMP_BALANCE_SIL.CHG_BAL,TEMP_BALANCE_SIL.WS_INT_AMT,TEMP_BALANCE_SIL.WS_CHG_AMT,TEMP_BALANCE_SIL.DL_INT_AMT,TEMP_BALANCE_SIL.CHG_INT_AMT,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC  select * from itda_io_dev.io_cml_brz.GSW_BALANCE_ST

# COMMAND ----------

