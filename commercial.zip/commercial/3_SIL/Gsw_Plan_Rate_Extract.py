# Databricks notebook source
dbutils.widgets.text('FIL_DATE',"2024-04-30") #FILE_DATE
FIL_DATE=dbutils.widgets.get('FIL_DATE')

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_plan_rate_extract_bt where file_date='{0}';""".format(FIL_DATE)
df=spark.sql(df)

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import trim 	
 
string_cols = [c for c, t in df.dtypes if t =='string']
for colname in string_cols :
  df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_PLAN_RATE_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
BRANCH_NUMBER       VARCHAR(20) NOT NULL,
PRODUCT_PLAN_CD     VARCHAR(20) NOT NULL,
SUPPLIER_PLANT_CD   VARCHAR(20) NOT NULL,
RATE_CD             VARCHAR(20) NOT NULL,
RATE_NM             VARCHAR(255) NOT NULL,
INTEREST_RATE_TP    VARCHAR(20) NOT NULL,
WHSL_LOAN_IND       VARCHAR(20) NOT NULL,
INSERT_TIMSTM       TIMESTAMP,
UPDATE_TIMSTM       TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='PLAN_RATE_ST' ## Changes for a new table
PATH=dbutils.widgets.get('PATH')
SIL_PATH=PATH+"/"+TBL_NAME

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.PLAN_RATE_ST as TGT USING TEMP_PLAN_RATE_SIL as SRC ON 
# MAGIC TGT.BRANCH_NUMBER = SRC.BRANCH_NUMBER AND
# MAGIC TGT.PRODUCT_PLAN_CD = SRC.PRODUCT_PLAN_CD AND
# MAGIC TGT.SUPPLIER_PLANT_CD = SRC.SUPPLIER_PLANT_CD AND
# MAGIC TGT.RATE_CD = SRC.RATE_CD AND
# MAGIC TGT.RATE_NM = SRC.RATE_NM AND
# MAGIC TGT.INTEREST_RATE_TP = SRC.INTEREST_RATE_TP AND
# MAGIC TGT.WHSL_LOAN_IND = SRC.WHSL_LOAN_IND
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC  (BRANCH_NUMBER,PRODUCT_PLAN_CD,SUPPLIER_PLANT_CD,RATE_CD,RATE_NM,INTEREST_RATE_TP,WHSL_LOAN_IND,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.BRANCH_NUMBER,SRC.PRODUCT_PLAN_CD,SRC.SUPPLIER_PLANT_CD,SRC.RATE_CD,SRC.RATE_NM,SRC.INTEREST_RATE_TP,SRC.WHSL_LOAN_IND,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.PLAN_RATE_ST;