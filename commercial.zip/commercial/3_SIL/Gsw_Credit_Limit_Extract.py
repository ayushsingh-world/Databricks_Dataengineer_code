# Databricks notebook source
from datetime import datetime
#BUS_DT=datetime.today().strftime('%Y-%m-%d')
BUS_DT='2024-04-30'

# COMMAND ----------

df="""select * from itda_io_dev.io_cml_brz.gsw_credit_limit_extract_bt  where file_date='{0}';""".format(BUS_DT)
df=spark.sql(df)

# COMMAND ----------

from pyspark.sql.functions import trim 
from pyspark.sql import functions as fun

for colname in df.columns:
  df = df.withColumn(colname, fun.trim(fun.col(colname)))

# COMMAND ----------

	string_cols = [c for c, t in df.dtypes if t =='string']
	for colname in string_cols :
    df= df.withColumn(colname, trim(colname))

# COMMAND ----------

from pyspark.sql.functions import when
df=df.withColumn("LIMIT_TYPE_CD ", when(df.LIMIT_TYPE_CD .isNull(),"NA") \
    .when(df.LIMIT_TYPE_CD =="","NA") \
    .otherwise(df.LIMIT_TYPE_CD ))
df=df.withColumn("LIMIT_AMT", when(df.LIMIT_AMT.isNull(),"NA") \
    .when(df.LIMIT_AMT=="","NA") \
    .otherwise(df.LIMIT_AMT))
df=df.withColumn("TEMPORARY_LIMIT_AMT", when(df.TEMPORARY_LIMIT_AMT.isNull(),"NA") \
    .when(df.TEMPORARY_LIMIT_AMT=="","NA") \
    .otherwise(df.TEMPORARY_LIMIT_AMT))
df=df.withColumn("LIMIT_EDIT_TYPE_CD ", when(df.LIMIT_EDIT_TYPE_CD .isNull(),"NA") \
    .when(df.LIMIT_EDIT_TYPE_CD =="","NA") \
    .otherwise(df.LIMIT_EDIT_TYPE_CD ))
df=df.withColumn("SEC_CREDIT_LIMIT_TYPE_CD", when(df.SEC_CREDIT_LIMIT_TYPE_CD.isNull(),"NA") \
    .when(df.SEC_CREDIT_LIMIT_TYPE_CD=="","NA") \
    .otherwise(df.SEC_CREDIT_LIMIT_TYPE_CD))

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import *
from pyspark.sql.functions  import date_format
df = df.withColumn("LIMIT_START_DATE",to_date(col("LIMIT_START_DATE"),"yyyy-MM-dd")) \
       .withColumn("LIMIT_END_DT",to_date(col("LIMIT_END_DT"),"yyyy-MM-dd")) \
       .withColumn("TEMP_LIMIT_START_DT",to_date(col("TEMP_LIMIT_START_DT"),"yyyy-MM-dd")) \
       .withColumn("TEMP_LIMIT_END_DT",to_date(col("TEMP_LIMIT_END_DT"),"yyyy-MM-dd"))

# COMMAND ----------

from pyspark.sql.types import DecimalType
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.types import DateType

# COMMAND ----------

df = df.withColumn("LIMIT_AMT", df["LIMIT_AMT"].cast(DecimalType(38,2))) \
        .withColumn("TEMPORARY_LIMIT_AMT", df["TEMPORARY_LIMIT_AMT"].cast(DecimalType(38,2)))

# COMMAND ----------

df=df.dropDuplicates()
df.createOrReplaceTempView("TEMP_CREDIT_LIMIT_SIL")

# COMMAND ----------

# In Silver Table, Please do not include additional columns: ROW_NUM and COUNTRY_CD
TBL_LAYT="""
DEALER_NBR                      VARCHAR(255) NOT NULL,
LIMIT_TYPE_CD                   VARCHAR(20) NOT NULL,
LIMIT_START_DATE                DATE,
LIMIT_END_DT                    DATE,
LIMIT_AMT                       DECIMAL(38,2) NOT NULL,
TEMP_LIMIT_START_DT             DATE,
TEMP_LIMIT_END_DT               DATE,
TEMPORARY_LIMIT_AMT             DECIMAL(38,2) NOT NULL,
UOM_CD                          VARCHAR(20) NOT NULL,
AMT_QTY_IDENTIFIER              VARCHAR(20) NOT NULL,
BRANCH_NBR                      VARCHAR(20) NOT NULL,
TYPE_CD                         VARCHAR(50) NOT NULL,
SHADOW_CREDIT_LIMIT_AMT         VARCHAR(40),
LIMIT_EDIT_TYPE_CD              VARCHAR(20) NOT NULL,
SEC_CREDIT_LIMIT_TYPE_CD        VARCHAR(20) NOT NULL,
INSERT_TIMSTM                   TIMESTAMP,
UPDATE_TIMSTM                   TIMESTAMP
"""

# COMMAND ----------

dbutils.widgets.text('SIL_PATH',"abfss://io-cml-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_cml_brz") #SILVER PATH

# COMMAND ----------

TBL_NAME='CREDIT_LIMIT_ST' ## Changes for a new table
SIL_PATH=dbutils.widgets.get('SIL_PATH')

# COMMAND ----------

str_query_create="""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_cml_brz.{0} (
{1}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{2}/{0}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)

# COMMAND ----------

spark.sql(str_query_create)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_cml_brz.CREDIT_LIMIT_ST as TGT USING TEMP_CREDIT_LIMIT_SIL as SRC ON 
# MAGIC TGT.DEALER_NBR = SRC.DEALERNUMBER AND
# MAGIC TGT.LIMIT_TYPE_CD = SRC.LIMIT_TYPE_CD AND
# MAGIC TGT.UOM_CD = SRC.UOM_CD AND
# MAGIC TGT.AMT_QTY_IDENTIFIER = SRC.AMT_QTY_IDENTIFIER AND
# MAGIC TGT.BRANCH_NBR = SRC.BRANCH_NUMBER AND
# MAGIC TGT.TYPE_CD = SRC.TYPE_CD AND
# MAGIC TGT.LIMIT_EDIT_TYPE_CD = SRC.LIMIT_EDIT_TYPE_CD AND
# MAGIC TGT.SEC_CREDIT_LIMIT_TYPE_CD = SRC.SEC_CREDIT_LIMIT_TYPE_CD
# MAGIC WHEN MATCHED THEN  UPDATE SET   
# MAGIC TGT.LIMIT_START_DATE = SRC.LIMIT_START_DATE ,
# MAGIC TGT.LIMIT_END_DT = SRC.LIMIT_END_DT ,
# MAGIC TGT.LIMIT_AMT = SRC.LIMIT_AMT ,
# MAGIC TGT.TEMP_LIMIT_START_DT = SRC.TEMP_LIMIT_START_DT ,
# MAGIC TGT.TEMP_LIMIT_END_DT = SRC.TEMP_LIMIT_END_DT ,
# MAGIC TGT.TEMPORARY_LIMIT_AMT = SRC.TEMPORARY_LIMIT_AMT ,
# MAGIC TGT.SHADOW_CREDIT_LIMIT_AMT = SRC.SHADOW_CREDIT_LIMIT_AMT ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp()
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC (DEALER_NBR,LIMIT_TYPE_CD,LIMIT_START_DATE,LIMIT_END_DT,LIMIT_AMT,TEMP_LIMIT_START_DT,TEMP_LIMIT_END_DT,TEMPORARY_LIMIT_AMT,UOM_CD,AMT_QTY_IDENTIFIER,BRANCH_NBR,TYPE_CD,SHADOW_CREDIT_LIMIT_AMT,LIMIT_EDIT_TYPE_CD,SEC_CREDIT_LIMIT_TYPE_CD,INSERT_TIMSTM) 
# MAGIC VALUES  
# MAGIC (SRC.DEALERNUMBER,SRC.LIMIT_TYPE_CD,SRC.LIMIT_START_DATE,SRC.LIMIT_END_DT,SRC.LIMIT_AMT,SRC.TEMP_LIMIT_START_DT,SRC.TEMP_LIMIT_END_DT,SRC.TEMPORARY_LIMIT_AMT,SRC.UOM_CD,SRC.AMT_QTY_IDENTIFIER,SRC.BRANCH_NUMBER,SRC.TYPE_CD,SRC.SHADOW_CREDIT_LIMIT_AMT,SRC.LIMIT_EDIT_TYPE_CD,SRC.SEC_CREDIT_LIMIT_TYPE_CD,current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_cml_brz.credit_limit_st;