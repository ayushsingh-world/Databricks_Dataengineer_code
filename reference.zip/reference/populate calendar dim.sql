-- Databricks notebook source
-- MAGIC %python
-- MAGIC begindate = '1900-01-01'
-- MAGIC enddate = '2199-12-31'
-- MAGIC
-- MAGIC (
-- MAGIC   spark.sql(f"select explode(sequence(to_date('{begindate}'), to_date('{enddate}'), interval 1 day)) as calendardate")
-- MAGIC     .createOrReplaceTempView('dates')
-- MAGIC )

-- COMMAND ----------

create or replace table itda_io_dev.io_ref_brz.calendar_dim 
using delta 
location 'abfss://io-ref-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_ref_brz/calendar_dim' 
as select
  year(calendardate) * 10000 + month(calendardate) * 100 + day(calendardate) as calendar_id,
  calendardate as calendar_dt,
  year(calendardate) AS year_nbr,
  year(calendardate) * 100 + month(calendardate) as year_month_nbr,
  quarter(calendardate) as quarter_nbr,
  month(calendardate) as month_nbr,
  date_format(calendardate, 'MMMM') as month_nm,
  dayofmonth(calendardate) as day_of_month_nbr,
  weekofyear(calendardate) as week_nbr,
  dayofweek(calendardate) as day_of_week_nbr,
  weekday(calendardate) + 1 as day_of_week_start_monday_nbr,
  date_format(calendardate, 'EEEE') as day_of_week_nm,
  case
    when weekday(calendardate) < 5 then 'Y'
    else 'N'
  end as is_weekday_flag,
  case
    when calendardate = last_day(calendardate) then 'Y'
    else 'N'
  end as is_last_day_of_month_flag,
  dayofyear(calendardate) as day_of_year_nbr,
  weekofyear(calendardate) as week_of_year_nbr
from
  dates;

-- COMMAND ----------
  -- DBTITLE 1,Optimize
  optimize itda_io_dev.io_ref_brz.calendar_dim zorder by (calendar_id);

-- COMMAND ----------
  -- DBTITLE 1,Examine the Calendar Dimension
--   select * from itda_io_dev.io_ref_brz.calendar_dim;

-- COMMAND ----------
  -- DBTITLE 1,populate gold table
insert into itda_io_dev.io_ref_gld.calendar_dim
select
  year(calendardate) * 10000 + month(calendardate) * 100 + day(calendardate) ,
  calendardate,
  year(calendardate),
  year(calendardate) * 100 + month(calendardate),
  quarter(calendardate) ,
  month(calendardate),
  date_format(calendardate, 'MMMM'),
  dayofmonth(calendardate),
  weekofyear(calendardate),
  dayofweek(calendardate),
  --weekday(calendardate) + 1,
  date_format(calendardate, 'EEEE'),
  quarter(calendardate),
  current_timestamp,
  NULL
from
  dates;

 -- COMMAND ----------
  -- DBTITLE 1,Optimize
  optimize itda_io_dev.io_ref_gld.calendar_dim zorder by (calendar_id);

-- COMMAND ----------

--drop table itda_io_dev.io_ref_brz.calendar;
--delete from itda_io_dev.io_ref_gld.calendar_dim;