# Databricks notebook source
# MAGIC %sql
# MAGIC select * from itda_io_dev.io_rtl_brz.slv_branch_country

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG itda_io_dev;
# MAGIC use schema io_rtl_brz

# COMMAND ----------

# MAGIC %sql
# MAGIC select contract_status_cd,country_cd,
# MAGIC case when contract_status_cd='X' then 'CANCELLED'
# MAGIC      when contract_status_cd='C' then 'CLOSED'
# MAGIC      ELSE 'ACTIVE' END AS CONTRACT_STATUS_DEC  
# MAGIC from slv_contract where country_cd='CL'
# MAGIC