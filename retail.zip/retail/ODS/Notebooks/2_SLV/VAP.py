# Databricks notebook source
# MAGIC %md
# MAGIC ### CANCELLATION SILVER NB

# COMMAND ----------

###
dbutils.widgets.text('SIL_PATH',"abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz") #SILVER PATH
dbutils.widgets.text('FIL_DATE',"2024-03-17") #FILE_DATE
dbutils.widgets.text('COUNTRY','CL') #COUNTRY_CODE
dbutils.widgets.text('TBL_NAME','slv_cancellation') #TBL_NAME
###
SIL_PATH=dbutils.widgets.get('SIL_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
COUNTRY=dbutils.widgets.get('COUNTRY')
TBL_NAME=dbutils.widgets.get('TBL_NAME')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### SQLs

# COMMAND ----------

wrk_sql=f"""
select
TRIM(BRANCH_NUMBER) as BRANCH_NUMBER,
TRIM(COUNTRY_CODE) as COUNTRY_CODE, 
TRIM(ACCOUNT_NUMBER) as ACCOUNT_NUMBER,
TRIM(CANCEL_DT) as CANCEL_DT,
TRIM(REASON_FOR_CANCELLATION) as REASON_FOR_CANCELLATION,
TRIM(CANCELLATION_USER_ID) as CANCELLATION_USER_ID,
TRIM(CLAW_BACK_AMOUNT) as CLAW_BACK_AMOUNT, 
TRIM(FLAT_CANCEL_IND) as FLAT_CANCEL_IND,
ROW_NUMBER() OVER (ORDER BY 'A') as INPUT_ROW_NBR
from itda_io_dev.io_rtl_brz.brz_contract_master_stg  
WHERE CANCEL_DT IS NOT NULL AND COUNTRY_CODE='{COUNTRY}' AND file_date = '{FIL_DATE}'"""

# COMMAND ----------

cleansed_sql = f"""
select 
    NVL(cast(BRANCH_NUMBER as INT),0) as BRANCH_NBR,
    COUNTRY_CODE as COUNTRY_CD,
    NVL(ACCOUNT_NUMBER,0) as ACCOUNT_NBR,
    NVL(to_date(CANCEL_DT,'dd-MMM-yyyy'),to_date(NULL,'dd-MMM-yyyy')) as CANCELLATION_DT,
    REASON_FOR_CANCELLATION as CANCELLATION_REASON,
    CANCELLATION_USER_ID as CANCELLATION_USER_ID,
    NVL(cast(CLAW_BACK_AMOUNT as decimal(16,2)),NULL) as CLAWBACK_AMT,
    CASE WHEN FLAT_CANCEL_IND IS NULL OR FLAT_CANCEL_IND = 'N' THEN 0 WHEN FLAT_CANCEL_IND = 'Y' THEN 1 ELSE 0 END AS FLAT_CANCEL_IND,
    'IORLOD036_01' as ETL_JOB_NM,
    INPUT_ROW_NBR
FROM 
itda_io_dev.io_rtl_brz.cancellation_wrk
WHERE COUNTRY_CODE='{COUNTRY}'"""

# COMMAND ----------

keyed_sql = f"""
select 
CW.BRANCH_NBR,
CW.COUNTRY_CD,
CW.ACCOUNT_NBR,
CW.CANCELLATION_DT,
CW.CANCELLATION_REASON,
CW.CANCELLATION_USER_ID,
CW.CLAWBACK_AMT,
CW.FLAT_CANCEL_IND,
CW.ETL_JOB_NM,
CW.INPUT_ROW_NBR
FROM
itda_io_dev.io_rtl_brz.cancellation_cleansed_wrk CW INNER JOIN itda_io_dev.io_rtl_brz.slv_branch_country BC
on CW.BRANCH_NBR = BC.BRANCH_NBR AND CW.COUNTRY_CD = BC.COUNTRY_CD
INNER JOIN itda_io_dev.io_rtl_brz.slv_JOB JOB
on CW.ETL_JOB_NM = JOB.JOB_NM
INNER JOIN itda_io_dev.io_rtl_brz.slv_CONTRACT CNT
on CW.BRANCH_NBR = CNT.BRANCH_NBR AND CW.COUNTRY_CD = CNT.COUNTRY_CD AND CW.ACCOUNT_NBR = CNT.ACCOUNT_NBR
WHERE  CW.COUNTRY_CD='{COUNTRY}'"""

# COMMAND ----------

#target ODS table layout
TBL_LAYT="""
BRANCH_NBR	            INT	NOT NULL,
COUNTRY_CD	            VARCHAR(3)	NOT NULL,
ACCOUNT_NBR	            VARCHAR(20)	NOT NULL,
CANCELLATION_DT    	    DATE	NOT NULL,
CANCELLATION_REASON	    VARCHAR(100),
CANCELLATION_USER_ID	VARCHAR(30),
CLAWBACK_AMT	        DECIMAL(16,2),
FLAT_CANCEL_IND	        INT	NOT NULL,
INSERT_TIMSTM           TIMESTAMP,
UPDATE_TIMSTM           TIMESTAMP
"""

# COMMAND ----------

trg_create_ddl=f"""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_rtl_brz.{TBL_NAME} (
{TBL_LAYT}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{SIL_PATH}/{TBL_NAME}'"""
spark.sql(trg_create_ddl)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Transformations (wrk, cleansed, keyed)

# COMMAND ----------

df_wrk=spark.sql(wrk_sql)
df_wrk.write.mode('overwrite').option('path','abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/cancellation_wrk').saveAsTable('itda_io_dev.io_rtl_brz.cancellation_wrk')

# COMMAND ----------

df_cleansed = spark.sql(cleansed_sql)
df_cleansed.write.mode('overwrite').option('path','abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/cancellation_cleansed_wrk').saveAsTable('itda_io_dev.io_rtl_brz.cancellation_cleansed_wrk')

# COMMAND ----------

df_keyed = spark.sql(keyed_sql)
df_keyed.write.mode('overwrite').option('path','abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/cancellation_keyed_wrk').saveAsTable('itda_io_dev.io_rtl_brz.cancellation_keyed_wrk')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Merge (Insert & Update)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO itda_io_dev.io_rtl_brz.slv_cancellation as TGT 
# MAGIC USING itda_io_dev.io_rtl_brz.cancellation_keyed_wrk as SRC 
# MAGIC on 
# MAGIC TGT.BRANCH_NBR = SRC.BRANCH_NBR AND
# MAGIC TGT.COUNTRY_CD = SRC.COUNTRY_CD AND
# MAGIC TGT.ACCOUNT_NBR = SRC.ACCOUNT_NBR AND
# MAGIC TGT.CANCELLATION_DT = SRC.CANCELLATION_DT
# MAGIC WHEN MATCHED THEN  UPDATE 
# MAGIC SET   
# MAGIC TGT.CANCELLATION_REASON = SRC.CANCELLATION_REASON ,
# MAGIC TGT.CANCELLATION_USER_ID = SRC.CANCELLATION_USER_ID,
# MAGIC TGT.CLAWBACK_AMT = SRC.CLAWBACK_AMT,
# MAGIC TGT.FLAT_CANCEL_IND = SRC.FLAT_CANCEL_IND,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC  WHEN NOT MATCHED  THEN INSERT 
# MAGIC (BRANCH_NBR,COUNTRY_CD,ACCOUNT_NBR,CANCELLATION_DT,CANCELLATION_REASON,CANCELLATION_USER_ID,CLAWBACK_AMT,FLAT_CANCEL_IND,INSERT_TIMSTM) 
# MAGIC VALUES  
# MAGIC (SRC.BRANCH_NBR,SRC.COUNTRY_CD,SRC.ACCOUNT_NBR,SRC.CANCELLATION_DT,SRC.CANCELLATION_REASON,SRC.CANCELLATION_USER_ID,SRC.CLAWBACK_AMT,SRC.FLAT_CANCEL_IND,current_timestamp)