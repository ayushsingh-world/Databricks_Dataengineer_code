# Databricks notebook source
# MAGIC %md
# MAGIC ### BRANCH_COUNTRY SILVER Notebook

# COMMAND ----------

###
dbutils.widgets.text('SIL_PATH',"abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz") #SILVER PATH
dbutils.widgets.text('FIL_DATE',"2024-03-15") #FILE_DATE
dbutils.widgets.text('COUNTRY','CL') #COUNTRY_CODE
dbutils.widgets.text('TBL_NAME','slv_branch_country') #TBL_NAME
###
SIL_PATH=dbutils.widgets.get('SIL_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
COUNTRY=dbutils.widgets.get('COUNTRY')
TBL_NAME=dbutils.widgets.get('TBL_NAME')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### SQLs

# COMMAND ----------

wrk_sql=f"""
select
BRANCH_NUMBER,
COUNTRY_CODE,
BUSINESS_DATE,
ROW_NUMBER() OVER (ORDER BY 'A') as INPUT_ROW_NBR
from itda_io_dev.io_rtl_brz.brz_reconciliation_stg
WHERE COUNTRY_CODE='{COUNTRY}' AND file_date = '{FIL_DATE}'"""

# COMMAND ----------

cleansed_sql = f"""
select 
    NVL(cast(BRANCH_NUMBER as INT),0) as BRANCH_NBR,
    COUNTRY_CODE as COUNTRY_CD,
    to_date(BUSINESS_DATE,'dd-MMM-yyyy') as BUSINESS_DT,
    'IORLOD092_01' as ETL_JOB_NM,
    INPUT_ROW_NBR
FROM 
itda_io_dev.io_rtl_brz.branch_country_wrk
WHERE COUNTRY_CODE='{COUNTRY}'"""

# COMMAND ----------

keyed_sql = f"""
select 
BC.BRANCH_NBR,
BC.COUNTRY_CD,
BC.BUSINESS_DT,
BC.ETL_JOB_NM,
BC.INPUT_ROW_NBR
FROM
itda_io_dev.io_rtl_brz.branch_country_cleansed_wrk BC INNER JOIN itda_io_dev.io_rtl_brz.slv_branch B
on BC.BRANCH_NBR=B.BRANCH_NBR
INNER JOIN itda_io_dev.io_rtl_brz.slv_country C
on BC.COUNTRY_CD=C.COUNTRY_CD
INNER JOIN itda_io_dev.io_rtl_brz.slv_job JOB
on BC.ETL_JOB_NM=JOB.JOB_NM
WHERE BC.COUNTRY_CD='{COUNTRY}'"""

# COMMAND ----------

#target ODS table layout
TBL_LAYT="""
BRANCH_NBR          INT NOT NULL,
COUNTRY_CD          VARCHAR (3) NOT NULL,
BUSINESS_DT         DATE NOT NULL,
INSERT_TIMSTM       TIMESTAMP,
UPDATE_TIMSTM       TIMESTAMP
"""

# COMMAND ----------

trg_create_ddl=f"""
CREATE TABLE IF NOT EXISTS itda_io_dev.io_rtl_brz.{TBL_NAME} (
{TBL_LAYT}
) using delta tblproperties (
delta.autooptimize.optimizewrite = TRUE,
delta.autooptimize.autocompact = TRUE
)
location '{SIL_PATH}/{TBL_NAME}';""".format(TBL_NAME,TBL_LAYT,SIL_PATH)
spark.sql(trg_create_ddl)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Transformations (wrk, cleansed, keyed)

# COMMAND ----------

df_wrk=spark.sql(wrk_sql)
df_wrk.write.mode('overwrite').option('path','abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/branch_country_wrk').saveAsTable('itda_io_dev.io_rtl_brz.branch_country_wrk')

# COMMAND ----------

df_cleansed = spark.sql(cleansed_sql)
df_cleansed.write.mode('overwrite').option('path','abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/branch_country_cleansed_wrk').saveAsTable('itda_io_dev.io_rtl_brz.branch_country_cleansed_wrk')

# COMMAND ----------

df_keyed = spark.sql(keyed_sql)
df_keyed.write.mode('overwrite').option('path','abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/branch_country_keyed_wrk').saveAsTable('itda_io_dev.io_rtl_brz.branch_country_keyed_wrk')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Merge (Insert & Update)

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into itda_io_dev.io_rtl_brz.slv_branch_country as TGT
# MAGIC using itda_io_dev.io_rtl_brz.branch_country_keyed_wrk as SRC
# MAGIC on 
# MAGIC TGT.BRANCH_NBR = SRC.BRANCH_NBR AND
# MAGIC TGT.COUNTRY_CD = SRC.COUNTRY_CD
# MAGIC when matched then update set 
# MAGIC TGT.BUSINESS_DT = SRC.BUSINESS_DT ,
# MAGIC TGT.UPDATE_TIMSTM = current_timestamp
# MAGIC when not matched then insert 
# MAGIC  (BRANCH_NBR,COUNTRY_CD,BUSINESS_DT,INSERT_TIMSTM)   
# MAGIC  VALUES  
# MAGIC (SRC.BRANCH_NBR,SRC.COUNTRY_CD,
# MAGIC SRC.BUSINESS_DT,current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from itda_io_dev.io_rtl_brz.slv_branch_country