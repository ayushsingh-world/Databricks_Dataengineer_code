# Databricks notebook source
# MAGIC %md ##### THIS IS A GENERIC NOTEBOOK THAT CAN BE USED TO INGEST DATA INTO BRONZE (\*_brz) AND BRONZE HIST(\*_hist_brz) schema

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import current_timestamp, to_utc_timestamp, from_utc_timestamp
import time

# COMMAND ----------

start_time = time.time()

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.functions import *

dbutils.widgets.text('ATL_PATH',"dbfs:/Volumes/itda_io_dev/io_rtl_lnd/atl") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-11-08") #FILE_DATE
dbutils.widgets.text('COUNTRY','Chile') #COUNTRY_CODE
dbutils.widgets.text('FIL_PTRN','Contract') #FIL_PTRN
dbutils.widgets.text('TBL_NAME','brz_contract_master_stg') #TBL_NAME

# COMMAND ----------

ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
COUNTRY=dbutils.widgets.get('COUNTRY')
FIL_PTRN=dbutils.widgets.get('FIL_PTRN')
TBL_NAME=dbutils.widgets.get('TBL_NAME')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
CATALOG="itda_io_dev"
SCHEMA="io_rtl_brz"

# COMMAND ----------

FIL_DATE_REFORMAT=FIL_DATE[-2:]+FIL_DATE[5:-3]+FIL_DATE[0:-6]
print(FIL_DATE_REFORMAT)

# COMMAND ----------

FIL_NAME= FIL_PTRN+"_"+FIL_DATE_REFORMAT+".csv"
print(FIL_NAME)

# COMMAND ----------

FIL_DIR_NAME = FIL_PTRN
print(FIL_DIR_NAME)

# COMMAND ----------

try:
    if COUNTRY == 'Brazil':
        COUNTRY_CD = 'BR'
    elif COUNTRY == 'Chile':
        COUNTRY_CD = 'CL'
    elif COUNTRY == 'Colombia':
        COUNTRY_CD = 'CO'
    elif COUNTRY == 'Mexico':
        COUNTRY_CD = 'MX'
    elif COUNTRY == 'Peru':
        COUNTRY_CD = 'PE'        
    else:
        raise ValueError("Error determining the country code")
except ValueError as e:
    dbutils.notebook.exit(f"Notebook failed: {e}")

# COMMAND ----------

try:
    # List tables in the specified database
    db_name=CATALOG+"."+SCHEMA
    tables_collection = spark.catalog.listTables(db_name)
    table_names_in_db = [table.name for table in tables_collection]

    # Check if the table exists
    table_exists = TBL_NAME in table_names_in_db

    if not table_exists:
        raise ValueError(f"Table '{TBL_NAME}' not found in database '{db_name}'.")

except Exception as e:
    # Fail the notebook with the exception message
    dbutils.notebook.exit(f"Notebook failed: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_DIR_NAME)
#!perl -p -i -e 's/\r\n$/\n/g' dbfs:/FileStore/data/lakehouse/SRS/Landing+'/'+COUNTRY_CD
dbutils.fs.mv('dbfs:/Volumes/itda_io_dev/io_rtl_lnd/srs'+'/'+COUNTRY+'/'+FIL_NAME,ATL_PATH+"/"+FIL_DIR_NAME+"/"+COUNTRY_CD+"_"+FIL_NAME)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Implementing the logic to build the schema from bronze table

# COMMAND ----------

# MAGIC %md ###### Need to confirm on the bronze archive tables, bronze target table structure and the process that loads latest file_date data into bronze target table and parameterize the below cell

# COMMAND ----------

schema=spark.sql(f"select * from {CATALOG}.{SCHEMA}.{TBL_NAME} limit 1").drop('file_nm','recrd_nbr','recrd_insert_ts').schema

# COMMAND ----------

df = spark.readStream.format("cloudFiles").schema(schema)\
.option("cloudFiles.format", "csv")\
.option("delimiter","^")\
.option("header","true")\
.option("multiLine", 'true')\
.option("encoding","ISO-8859-1")\
.option("cloudFiles.inferColumnTypes", "false")\
.option("cloudFiles.schemaLocation",SCM_PATH)\
.load(ATL_PATH+'/'+FIL_DIR_NAME+"/*.csv")

# COMMAND ----------

dbutils.fs.rm('abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/SCM/contract_master',True)
#dbutils.fs.rm('dbfs:/Volumes/itda_io_dev/io_rtl_lnd/atl/Contract',True)
#dbutils.fs.ls('dbfs:/Volumes/itda_io_dev/io_rtl_lnd/atl/Contract')

# COMMAND ----------

ts_gmt=current_timestamp()
ts_cst = from_utc_timestamp(ts_gmt, 'CST')
df = df.withColumn("file_nm", lit(FIL_NAME))
# Add a unique identifier to each row
#df = df.withColumn("unique_id", monotonically_increasing_id())
# Define a window specification
#window_spec = Window.orderBy("hfi")
# Add a sequentially incremental column
#df = df.withColumn("recrd_nbr",lit(2))
df=df.withColumn("recrd_insert_ts",ts_cst)

# COMMAND ----------

str_query_delete=f"""delete from itda_io_dev.io_rtl_brz.{TBL_NAME} where country_code='{COUNTRY_CD}'"""
spark.sql(str_query_delete)

# COMMAND ----------

autoload = df.writeStream.format('delta')\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("overwrite","true")\
    .table("itda_io_dev.io_rtl_brz."+TBL_NAME)

autoload.awaitTermination()

# COMMAND ----------

df_with_recrd_nbr=spark.sql(f"SELECT * except (recrd_nbr),ROW_NUMBER() OVER (ORDER BY 'A') as recrd_nbr FROM itda_io_dev.io_rtl_brz.{TBL_NAME} where country_code='{COUNTRY_CD}'")
df_with_recrd_nbr.write.mode("append").saveAsTable(f"itda_io_dev.io_rtl_brz.{TBL_NAME}")

# COMMAND ----------

print(f"Notebook Elapsed Time: {(time.time() - start_time)}")

# COMMAND ----------

dbutils.notebook.exit(0)