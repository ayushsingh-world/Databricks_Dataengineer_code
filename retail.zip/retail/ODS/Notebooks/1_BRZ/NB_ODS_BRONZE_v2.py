# Databricks notebook source
# MAGIC %md ##### THIS IS A GENERIC NOTEBOOK THAT CAN BE USED TO INGEST DATA INTO BRONZE (\*_brz) AND BRONZE HIST(\*_hist_brz) schema

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.functions import *

dbutils.widgets.text('ATL_PATH',"dbfs:/Volumes/itda_io_dev/io_rtl_lnd/atl") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-11-08") #FILE_DATE
dbutils.widgets.text('COUNTRY','Chile') #COUNTRY_CODE
dbutils.widgets.text('FIL_PTRN','Contract') #FIL_PTRN
dbutils.widgets.text('TBL_NAME','brz_contract_master_stg') #TBL_NAME

# COMMAND ----------

ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
COUNTRY=dbutils.widgets.get('COUNTRY')
FIL_PTRN=dbutils.widgets.get('FIL_PTRN')
TBL_NAME=dbutils.widgets.get('TBL_NAME')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"
CATALOG="itda_io_dev"
SCHEMA="io_rtl_brz"

# COMMAND ----------

FIL_DATE_REFORMAT=FIL_DATE[-2:]+FIL_DATE[5:-3]+FIL_DATE[0:-6]
print(FIL_DATE_REFORMAT)

# COMMAND ----------

FIL_NAME= FIL_PTRN+"_"+FIL_DATE_REFORMAT+".csv"
print(FIL_NAME)

# COMMAND ----------

FIL_DIR_NAME = FIL_PTRN
print(FIL_DIR_NAME)

# COMMAND ----------

try:
    if COUNTRY == 'Brazil':
        COUNTRY_CD = 'BR'
    elif COUNTRY == 'Chile':
        COUNTRY_CD = 'CL'
    elif COUNTRY == 'Colombia':
        COUNTRY_CD = 'CO'
    elif COUNTRY == 'Mexico':
        COUNTRY_CD = 'MX'
    elif COUNTRY == 'Peru':
        COUNTRY_CD = 'PE'        
    else:
        raise ValueError("Error determining the country code")
except ValueError as e:
    dbutils.notebook.exit(f"Notebook failed: {e}")

# COMMAND ----------

try:
    # List tables in the specified database
    db_name=CATALOG+"."+SCHEMA
    tables_collection = spark.catalog.listTables(db_name)
    table_names_in_db = [table.name for table in tables_collection]

    # Check if the table exists
    table_exists = TBL_NAME in table_names_in_db

    if not table_exists:
        raise ValueError(f"Table '{TBL_NAME}' not found in database '{db_name}'.")

except Exception as e:
    # Fail the notebook with the exception message
    dbutils.notebook.exit(f"Notebook failed: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_DIR_NAME)
#!perl -p -i -e 's/\r\n$/\n/g' dbfs:/FileStore/data/lakehouse/SRS/Landing+'/'+COUNTRY_CD
dbutils.fs.mv('dbfs:/Volumes/itda_io_dev/io_rtl_lnd/srs'+'/'+COUNTRY+'/'+FIL_NAME,ATL_PATH+"/"+FIL_DIR_NAME)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Implementing the logic to build the schema from bronze table

# COMMAND ----------

# MAGIC %md ###### Need to confirm on the bronze archive tables, bronze target table structure and the process that loads latest file_date data into bronze target table and parameterize the below cell

# COMMAND ----------

schema=spark.sql("select *,'placeholder' country_cd,'placeholder' file_date,'placeholder' _rescued_data from itda_io_dev.io_rtl_brz.repayment_details_resch_stg limit 1").drop('file_nm','recrd_nbr','recrd_insert_ts').schema
schema['country_cd'].nullable=True
schema['file_date'].nullable=True
schema['_rescued_data'].nullable=True

# COMMAND ----------

 df = spark.readStream.format("cloudFiles").schema(schema)\
.option("cloudFiles.format", "csv")\
.option("delimiter","^")\
.option("header","true")\
.option("multiLine", 'true')\
.option("encoding","ISO-8859-1")\
.option("cloudFiles.inferColumnTypes", "false")\
.option("cloudFiles.partitionColumns","country_cd,file_date")\
.option("cloudFiles.schemaLocation",SCM_PATH)\
.load(ATL_PATH+'/'+FIL_DIR_NAME+"/*.csv")

# COMMAND ----------

#for i in range(0, len(df_stage_cols_list)):
    #print('Renaming '+df.columns[i]+' as '+df_stage_cols_list[i]+' in the next step')
    #df=df.withColumnRenamed(df.columns[i],'c_'+str(i))
#for i in range(0, len(df_stage_cols_list)):
    #df=df.withColumnRenamed('c_'+str(i),df_stage_cols_list[i])

# COMMAND ----------

if 'COUNTRY_CODE' in df_stage_cols_list:
    PRTN_CNTRY_COL='COUNTRY_CODE'
elif 'COUNTRYCODE' in df_stage_cols_list:
    PRTN_CNTRY_COL='COUNTRYCODE'
else:
    print("Unable to determine the country code column")
    dbutils.notebook.exit(1)


# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd")).drop(PRTN_CNTRY_COL)
df=df.withColumnRenamed('country_cd',PRTN_CNTRY_COL)

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy(PRTN_CNTRY_COL,'file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("append","false")\
    .table("itda_io_dev.io_rtl_brz."+TBL_NAME)