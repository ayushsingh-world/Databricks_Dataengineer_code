# Databricks notebook source
#dbutils.widgets.removeAll()

# COMMAND ----------

from pyspark.sql import *
from pyspark.sql.functions import *

dbutils.widgets.text('ATL_PATH',"dbfs:/Volumes/itda_io_dev/io_rtl_lnd/atl") #AUTOLOADER PATH
dbutils.widgets.text('BRZ_PATH',"abfss://io-rtl-stc@gmfcusdevitdaiobrz01sa.dfs.core.windows.net/itda_io_dev/io_rtl_brz/") #BRONZE PATH
dbutils.widgets.text('FIL_DATE',"2024-11-08") #FILE_DATE
dbutils.widgets.text('COUNTRY','Chile') #COUNTRY_CODE
dbutils.widgets.text('FIL_PTRN','Contract') #FIL_PTRN
dbutils.widgets.text('TBL_NAME','brz_contract_master_stg') #TBL_NAME

# COMMAND ----------

ATL_PATH=dbutils.widgets.get('ATL_PATH')
BRZ_PATH=dbutils.widgets.get('BRZ_PATH')
FIL_DATE=dbutils.widgets.get('FIL_DATE')
COUNTRY=dbutils.widgets.get('COUNTRY')
FIL_PTRN=dbutils.widgets.get('FIL_PTRN')
TBL_NAME=dbutils.widgets.get('TBL_NAME')
SCM_PATH=dbutils.widgets.get('BRZ_PATH')+'/SCM/'+TBL_NAME
CPN_PATH=dbutils.widgets.get('BRZ_PATH')+'/CPN/'+TBL_NAME
TBL_PATH=BRZ_PATH+"/"+TBL_NAME+"/"

# COMMAND ----------

FIL_DATE_REFORMAT=FIL_DATE[-2:]+FIL_DATE[5:-3]+FIL_DATE[0:-6]
print(FIL_DATE_REFORMAT)

# COMMAND ----------

FIL_NAME= FIL_PTRN+"_"+FIL_DATE_REFORMAT+".csv"
print(FIL_NAME)

# COMMAND ----------

FIL_DIR_NAME = FIL_PTRN
print(FIL_DIR_NAME)

# COMMAND ----------

if (COUNTRY == 'Brazil'):
    COUNTRY_CD = 'BR'
elif (COUNTRY == 'Chile'):
    COUNTRY_CD = 'CL'
elif (COUNTRY == 'Colombia'):
    COUNTRY_CD = 'CO'
elif (COUNTRY == 'Mexico'):
    COUNTRY_CD = 'MX'
else:
    print("Error determining the country code")

# COMMAND ----------

# MAGIC %md
# MAGIC ###### The below cell will move the file from LANDING to ATL_PATH. We also move our file to today's directory under it so that Auto Loader attempts to infer partition columns from the underlying directory structure of the data if the data is laid out in Hive style partitioning

# COMMAND ----------

dbutils.fs.mkdirs(ATL_PATH+"/"+FIL_DIR_NAME+"/country_cd="+COUNTRY_CD+"/file_date="+FIL_DATE)
#!perl -p -i -e 's/\r\n$/\n/g' dbfs:/FileStore/data/lakehouse/SRS/Landing+'/'+COUNTRY_CD
dbutils.fs.mv('dbfs:/Volumes/itda_io_dev/io_rtl_lnd/srs'+'/'+COUNTRY+'/'+FIL_NAME,ATL_PATH+"/"+FIL_DIR_NAME+"/country_cd="+COUNTRY_CD+"/file_date="+FIL_DATE)

# COMMAND ----------

df_stage_cols=spark.sql("""select COLUMN_NAME from itda_io_dev.io_de_central.onprem_table_meta where lower(TABLE_NAME)=regexp_replace(lower('{0}'),'^brz_','') order by cast(COLUMN_ID as int);""".format(TBL_NAME))

# COMMAND ----------

#df_stage_cols=spark.sql("""select COLUMN_NAME from itda_io_dev.io_de_central.onprem_table_meta where lower(TABLE_NAME)=regexp_replace(lower('{0}'),'^brz_','') order by cast(COLUMN_ID as int);""".format(TBL_NAME+'_stg'))

# COMMAND ----------

#NOOFCOLS_FILE=len(df.columns)
#NOOFCOLS_OTM=df_stage_cols.count()+3 # Need to do + 3 to account for COUNTRY_CD,FILE_DATE,_rescued_data
#if (NOOFCOLS_FILE==NOOFCOLS_OTM):
#    print("MATCH in no. of columns in file [{0}]  vs no. of columns in default.onprem_table_meta [{1}] for {2}".format(NOOFCOLS_FILE,NOOFCOLS_OTM,FIL_NAME))
#else:
#    print("MISMATCH in no. of columns in file [{0}]  vs no. of columns in default.onprem_table_meta [{1}] for {2}".format(NOOFCOLS_FILE,NOOFCOLS_OTM,FIL_NAME))
#    dbutils.notebook.exit(1)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Implementing the logic to build the schema from df_stage_cols

# COMMAND ----------

#List of column names from spark.readStream
#df_stream_cols_list=df.columns
#List of column names from df_stage_cols
df_stage_cols_list=[]
for row in df_stage_cols.collect():
    df_stage_cols_list.append(row[0])
df_stage_cols_list.append('country_cd')
df_stage_cols_list.append('file_date')
df_stage_cols_list.append('_rescued_data')

# COMMAND ----------

schema_str = ' string,'.join(df_stage_cols_list)
schema_str=schema_str+' string'
print(schema_str)

# COMMAND ----------

# Import method _parse_datatype_string
from pyspark.sql.types import _parse_datatype_string# Create new Schema for data
schema = _parse_datatype_string(schema_str)
print(schema)

# COMMAND ----------

 df = spark.readStream.format("cloudFiles").schema(schema)\
.option("cloudFiles.format", "csv")\
.option("delimiter","^")\
.option("header","true")\
.option("multiLine", 'true')\
.option("encoding","ISO-8859-1")\
.option("cloudFiles.inferColumnTypes", "false")\
.option("cloudFiles.partitionColumns","country_cd,file_date")\
.option("cloudFiles.schemaLocation",SCM_PATH)\
.load(ATL_PATH+'/'+FIL_DIR_NAME+"/*.csv")

# COMMAND ----------

#for i in range(0, len(df_stage_cols_list)):
    #print('Renaming '+df.columns[i]+' as '+df_stage_cols_list[i]+' in the next step')
    #df=df.withColumnRenamed(df.columns[i],'c_'+str(i))
#for i in range(0, len(df_stage_cols_list)):
    #df=df.withColumnRenamed('c_'+str(i),df_stage_cols_list[i])

# COMMAND ----------

if 'COUNTRY_CODE' in df_stage_cols_list:
    PRTN_CNTRY_COL='COUNTRY_CODE'
elif 'COUNTRYCODE' in df_stage_cols_list:
    PRTN_CNTRY_COL='COUNTRYCODE'
else:
    print("Unable to determine the country code column")
    dbutils.notebook.exit(1)


# COMMAND ----------

df=df.withColumn("file_date",to_date(col('file_date'),"yyyy-MM-dd")).drop(PRTN_CNTRY_COL)
df=df.withColumnRenamed('country_cd',PRTN_CNTRY_COL)

# COMMAND ----------

df.writeStream.format('delta')\
    .option("mergeSchema", "true")\
    .partitionBy(PRTN_CNTRY_COL,'file_date')\
    .option("path",TBL_PATH)\
    .trigger(once=True)\
    .option("checkpointLocation", CPN_PATH)\
    .option("append","false")\
    .table("itda_io_dev.io_rtl_brz."+TBL_NAME)